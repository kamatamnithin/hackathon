
  # Add Future Scope Section

  This is a code bundle for Add Future Scope Section. The original project is available at https://www.figma.com/design/0WnaIX9G22gthWPf1zaadm/Add-Future-Scope-Section.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  