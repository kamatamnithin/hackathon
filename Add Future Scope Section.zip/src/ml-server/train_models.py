"""
Train ML models for HealthAI platform
Creates models for: Heart Disease, Diabetes, Cancer prediction
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import os
from sklearn.datasets import load_breast_cancer

# Create models directory
os.makedirs('models', exist_ok=True)

def train_heart_disease_model():
    """Train Random Forest model for heart disease prediction"""
    print("\n🫀 Training Heart Disease Model...")
    print("=" * 50)
    
    # Create synthetic dataset (or load from UCI Heart Disease dataset)
    # For demo, creating synthetic data. Replace with real dataset in production.
    np.random.seed(42)
    n_samples = 1000
    
    # Features: age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal
    data = {
        'age': np.random.randint(29, 80, n_samples),
        'sex': np.random.randint(0, 2, n_samples),
        'cp': np.random.randint(0, 4, n_samples),
        'trestbps': np.random.randint(94, 200, n_samples),
        'chol': np.random.randint(126, 565, n_samples),
        'fbs': np.random.randint(0, 2, n_samples),
        'restecg': np.random.randint(0, 3, n_samples),
        'thalach': np.random.randint(71, 202, n_samples),
        'exang': np.random.randint(0, 2, n_samples),
        'oldpeak': np.random.uniform(0, 6.2, n_samples),
        'slope': np.random.randint(0, 3, n_samples),
        'ca': np.random.randint(0, 4, n_samples),
        'thal': np.random.randint(0, 4, n_samples)
    }
    
    df = pd.DataFrame(data)
    
    # Create target based on risk factors (rule-based for demo)
    df['target'] = ((df['age'] > 55).astype(int) + 
                    (df['chol'] > 240).astype(int) + 
                    (df['trestbps'] > 140).astype(int) +
                    (df['cp'] >= 2).astype(int) +
                    (df['thalach'] < 120).astype(int)) >= 2
    
    X = df.drop('target', axis=1)
    y = df['target'].astype(int)
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Train model
    model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
    model.fit(X_train, y_train)
    
    # Evaluate
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"✅ Model trained successfully!")
    print(f"📊 Accuracy: {accuracy * 100:.2f}%")
    print(f"📈 Cross-validation score: {cross_val_score(model, X, y, cv=5).mean() * 100:.2f}%")
    
    # Save model
    joblib.dump(model, 'models/heart_disease_model.pkl')
    print("💾 Model saved: models/heart_disease_model.pkl")
    
    return model, accuracy

def train_diabetes_model():
    """Train Gradient Boosting model for diabetes prediction"""
    print("\n🩺 Training Diabetes Model...")
    print("=" * 50)
    
    # Create synthetic Pima Indians Diabetes-like dataset
    np.random.seed(42)
    n_samples = 800
    
    data = {
        'pregnancies': np.random.randint(0, 15, n_samples),
        'glucose': np.random.randint(44, 200, n_samples),
        'blood_pressure': np.random.randint(24, 122, n_samples),
        'skin_thickness': np.random.randint(7, 99, n_samples),
        'insulin': np.random.randint(14, 846, n_samples),
        'bmi': np.random.uniform(18, 67, n_samples),
        'diabetes_pedigree': np.random.uniform(0.078, 2.42, n_samples),
        'age': np.random.randint(21, 81, n_samples)
    }
    
    df = pd.DataFrame(data)
    
    # Create target based on risk factors
    df['target'] = ((df['glucose'] > 140).astype(int) + 
                    (df['bmi'] > 30).astype(int) + 
                    (df['age'] > 45).astype(int) +
                    (df['diabetes_pedigree'] > 0.5).astype(int)) >= 2
    
    X = df.drop('target', axis=1)
    y = df['target'].astype(int)
    
    # Split and scale
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train model
    model = GradientBoostingClassifier(n_estimators=100, max_depth=5, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # Evaluate
    y_pred = model.predict(X_test_scaled)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"✅ Model trained successfully!")
    print(f"📊 Accuracy: {accuracy * 100:.2f}%")
    print(f"📈 Cross-validation score: {cross_val_score(model, X_train_scaled, y_train, cv=5).mean() * 100:.2f}%")
    
    # Save model and scaler
    joblib.dump(model, 'models/diabetes_model.pkl')
    joblib.dump(scaler, 'models/diabetes_scaler.pkl')
    print("💾 Model saved: models/diabetes_model.pkl")
    print("💾 Scaler saved: models/diabetes_scaler.pkl")
    
    return model, accuracy

def train_cancer_model():
    """Train SVM model for breast cancer prediction"""
    print("\n🎗️  Training Cancer Prediction Model...")
    print("=" * 50)
    
    # Load real breast cancer dataset from sklearn
    cancer_data = load_breast_cancer()
    X = pd.DataFrame(cancer_data.data[:, :10])  # Use first 10 features for simplicity
    y = cancer_data.target
    
    # Split and scale
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train model
    model = SVC(kernel='rbf', probability=True, random_state=42)
    model.fit(X_train_scaled, y_train)
    
    # Evaluate
    y_pred = model.predict(X_test_scaled)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"✅ Model trained successfully!")
    print(f"📊 Accuracy: {accuracy * 100:.2f}%")
    print(f"📈 Cross-validation score: {cross_val_score(model, X_train_scaled, y_train, cv=5).mean() * 100:.2f}%")
    
    # Save model and scaler
    joblib.dump(model, 'models/cancer_model.pkl')
    joblib.dump(scaler, 'models/cancer_scaler.pkl')
    print("💾 Model saved: models/cancer_model.pkl")
    print("💾 Scaler saved: models/cancer_scaler.pkl")
    
    return model, accuracy

def main():
    """Train all models"""
    print("\n" + "=" * 60)
    print("🤖 HealthAI ML Model Training Pipeline")
    print("=" * 60)
    
    results = {}
    
    # Train all models
    try:
        model1, acc1 = train_heart_disease_model()
        results['heart_disease'] = acc1
    except Exception as e:
        print(f"❌ Error training heart disease model: {e}")
    
    try:
        model2, acc2 = train_diabetes_model()
        results['diabetes'] = acc2
    except Exception as e:
        print(f"❌ Error training diabetes model: {e}")
    
    try:
        model3, acc3 = train_cancer_model()
        results['cancer'] = acc3
    except Exception as e:
        print(f"❌ Error training cancer model: {e}")
    
    # Summary
    print("\n" + "=" * 60)
    print("📋 Training Summary")
    print("=" * 60)
    for model_name, accuracy in results.items():
        print(f"✅ {model_name.replace('_', ' ').title()}: {accuracy * 100:.2f}% accuracy")
    
    print("\n🎉 All models trained successfully!")
    print("💡 Models are ready to use in the ML server")
    print("🚀 Start the server with: python app.py")
    print("=" * 60 + "\n")

if __name__ == '__main__':
    main()
