#!/bin/bash

# HealthAI ML Server Startup Script

echo "🤖 HealthAI ML Server Startup"
echo "=============================="

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.8+"
    exit 1
fi

echo "✅ Python found: $(python3 --version)"

# Check if venv exists
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

# Activate venv
echo "🔧 Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "📚 Installing dependencies..."
pip install -q -r requirements.txt

# Check if models exist
if [ ! -d "models" ] || [ -z "$(ls -A models)" ]; then
    echo "🎓 Models not found. Training models..."
    python train_models.py
else
    echo "✅ Models found"
fi

# Start server
echo ""
echo "🚀 Starting ML Server on port 5001..."
echo "=============================="
python app.py
