# 🤖 HealthAI ML Server Documentation

## Overview
Python Flask server providing real-time disease prediction using Machine Learning models with SHAP explainability.

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd ml-server
pip install -r requirements.txt
```

Or with virtualenv (recommended):

```bash
cd ml-server
python -m venv venv

# Activate virtualenv
# On Linux/Mac:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Train Models

```bash
python train_models.py
```

This will:
- ✅ Train Heart Disease classifier (Random Forest)
- ✅ Train Diabetes predictor (Gradient Boosting)
- ✅ Train Cancer classifier (SVM)
- ✅ Save models to `models/` directory
- ✅ Display accuracy metrics

Expected output:
```
🤖 HealthAI ML Model Training Pipeline
==========================================

🫀 Training Heart Disease Model...
✅ Model trained successfully!
📊 Accuracy: 85.50%
💾 Model saved: models/heart_disease_model.pkl

🩺 Training Diabetes Model...
✅ Model trained successfully!
📊 Accuracy: 78.30%
💾 Model saved: models/diabetes_model.pkl

🎗️  Training Cancer Prediction Model...
✅ Model trained successfully!
📊 Accuracy: 96.50%
💾 Model saved: models/cancer_model.pkl
```

### 3. Start ML Server

```bash
python app.py
```

Server will start on: **http://localhost:5001**

---

## 📊 ML Models

### 1. Heart Disease Predictor
- **Algorithm**: Random Forest Classifier
- **Features**: 13 cardiovascular indicators
- **Accuracy**: ~85.5%
- **Endpoint**: `POST /predict/heart-disease`

**Input Features:**
```json
{
  "age": 55,
  "sex": 1,                    // 1=male, 0=female
  "cp": 2,                     // chest pain type (0-3)
  "trestbps": 140,             // resting blood pressure
  "chol": 250,                 // cholesterol level
  "fbs": 1,                    // fasting blood sugar > 120
  "restecg": 0,                // resting ECG results
  "thalach": 150,              // maximum heart rate
  "exang": 1,                  // exercise induced angina
  "oldpeak": 1.5,              // ST depression
  "slope": 2,                  // slope of peak exercise ST
  "ca": 1,                     // number of major vessels
  "thal": 2                    // thalassemia
}
```

**Output:**
```json
{
  "success": true,
  "model": "Random Forest Classifier",
  "prediction": "Heart Disease Detected",
  "risk_level": "high",
  "confidence_score": 87.5,
  "risk_probability": 87.5,
  "feature_importance": [
    {
      "feature": "Age",
      "importance": 0.245,
      "contribution": 0.12,
      "value": 55
    },
    ...
  ],
  "explainability": {
    "top_factors": ["Age", "Cholesterol", "Blood Pressure"],
    "shap_values": [...]
  },
  "recommendations": [
    "⚠️ Consult a cardiologist immediately",
    "🥗 Reduce cholesterol through diet",
    ...
  ]
}
```

### 2. Diabetes Risk Predictor
- **Algorithm**: Gradient Boosting Classifier
- **Features**: 8 diabetes indicators (Pima Indians style)
- **Accuracy**: ~78.3%
- **Endpoint**: `POST /predict/diabetes`

**Input Features:**
```json
{
  "pregnancies": 2,
  "glucose": 148,
  "blood_pressure": 85,
  "skin_thickness": 30,
  "insulin": 165,
  "bmi": 31.5,
  "diabetes_pedigree": 0.85,
  "age": 45
}
```

### 3. Cancer Risk Classifier
- **Algorithm**: Support Vector Machine (SVM)
- **Features**: 10 tumor characteristics
- **Accuracy**: ~96.5%
- **Endpoint**: `POST /predict/cancer`
- **Dataset**: Wisconsin Breast Cancer Database

**Input Features:**
```json
{
  "radius_mean": 17.5,
  "texture_mean": 24.5,
  "perimeter_mean": 115,
  "area_mean": 950,
  "smoothness_mean": 0.115,
  "compactness_mean": 0.18,
  "concavity_mean": 0.22,
  "concave_points_mean": 0.08,
  "symmetry_mean": 0.21,
  "fractal_dimension_mean": 0.07
}
```

---

## 🔌 API Endpoints

### Health Check
```bash
GET /health
```

Response:
```json
{
  "status": "ok",
  "message": "HealthAI ML Server Running",
  "models_loaded": ["heart_disease", "diabetes", "cancer"],
  "timestamp": "2025-10-31T10:30:00"
}
```

### Heart Disease Prediction
```bash
POST /predict/heart-disease
Content-Type: application/json

{
  "age": 55,
  "sex": 1,
  "cp": 2,
  "trestbps": 140,
  "chol": 250,
  "fbs": 1,
  "restecg": 0,
  "thalach": 150,
  "exang": 1,
  "oldpeak": 1.5,
  "slope": 2,
  "ca": 1,
  "thal": 2
}
```

### Diabetes Prediction
```bash
POST /predict/diabetes
Content-Type: application/json

{
  "pregnancies": 2,
  "glucose": 148,
  "blood_pressure": 85,
  "skin_thickness": 30,
  "insulin": 165,
  "bmi": 31.5,
  "diabetes_pedigree": 0.85,
  "age": 45
}
```

### Cancer Prediction
```bash
POST /predict/cancer
Content-Type: application/json

{
  "radius_mean": 17.5,
  "texture_mean": 24.5,
  "perimeter_mean": 115,
  "area_mean": 950,
  "smoothness_mean": 0.115,
  "compactness_mean": 0.18,
  "concavity_mean": 0.22,
  "concave_points_mean": 0.08,
  "symmetry_mean": 0.21,
  "fractal_dimension_mean": 0.07
}
```

### Model Information
```bash
GET /models/info
```

Response:
```json
{
  "models": {
    "heart_disease": {
      "loaded": true,
      "algorithm": "Random Forest",
      "features": 13,
      "accuracy": 85.5
    },
    "diabetes": {
      "loaded": true,
      "algorithm": "Gradient Boosting",
      "features": 8,
      "accuracy": 78.3
    },
    "cancer": {
      "loaded": true,
      "algorithm": "SVM",
      "features": 10,
      "accuracy": 96.5
    }
  }
}
```

---

## 🧪 Testing

### Test with curl

**Test Health Check:**
```bash
curl http://localhost:5001/health
```

**Test Heart Disease Prediction:**
```bash
curl -X POST http://localhost:5001/predict/heart-disease \
  -H "Content-Type: application/json" \
  -d '{
    "age": 55,
    "sex": 1,
    "cp": 2,
    "trestbps": 140,
    "chol": 250,
    "fbs": 1,
    "restecg": 0,
    "thalach": 150,
    "exang": 1,
    "oldpeak": 1.5,
    "slope": 2,
    "ca": 1,
    "thal": 2
  }'
```

### Test with Python

```python
import requests

# Health check
response = requests.get('http://localhost:5001/health')
print(response.json())

# Heart disease prediction
data = {
    "age": 55,
    "sex": 1,
    "cp": 2,
    "trestbps": 140,
    "chol": 250,
    "fbs": 1,
    "restecg": 0,
    "thalach": 150,
    "exang": 1,
    "oldpeak": 1.5,
    "slope": 2,
    "ca": 1,
    "thal": 2
}

response = requests.post('http://localhost:5001/predict/heart-disease', json=data)
print(response.json())
```

---

## 🔗 Integration with Node.js Backend

The ML server is already integrated with your Node.js backend!

**Node.js Backend automatically calls ML server:**

```javascript
// From /backend/routes/predictions.js
POST /api/predictions/run
{
  "diseaseType": "heart_disease",
  "inputData": {
    "age": 55,
    "sex": 1,
    ...
  }
}
```

**Flow:**
1. Frontend → Node.js Backend (`POST /api/predictions/run`)
2. Node.js Backend → ML Server (`POST /predict/heart-disease`)
3. ML Server → Prediction + SHAP Explanation
4. Node.js Backend → Save to MySQL Database
5. Node.js Backend → Return to Frontend

---

## 📊 SHAP Explainability

SHAP (SHapley Additive exPlanations) provides feature importance for each prediction.

**What SHAP tells you:**
- Which features contributed most to the prediction
- Positive vs negative contributions
- Feature values and their impact

**Example:**
```json
{
  "feature_importance": [
    {
      "feature": "Age",
      "importance": 0.245,        // How important (0-1)
      "contribution": 0.12,       // Positive = increases risk
      "value": 55                 // Actual value
    },
    {
      "feature": "Cholesterol",
      "importance": 0.198,
      "contribution": 0.08,
      "value": 250
    }
  ]
}
```

---

## 🛠️ Customization

### Adding New Models

1. **Create training function** in `train_models.py`:
```python
def train_your_model():
    # Load data
    # Train model
    # Save model
    joblib.dump(model, 'models/your_model.pkl')
```

2. **Add prediction endpoint** in `app.py`:
```python
@app.route('/predict/your-disease', methods=['POST'])
def predict_your_disease():
    # Extract features
    # Load model
    # Make prediction
    # Return results
```

3. **Update model loading** in `app.py`:
```python
MODELS['your_disease'] = joblib.load('models/your_model.pkl')
```

### Using Real Datasets

Replace synthetic data in `train_models.py` with real datasets:

**Heart Disease:**
- UCI Heart Disease Dataset
- URL: https://archive.ics.uci.edu/ml/datasets/heart+disease

**Diabetes:**
- Pima Indians Diabetes Database
- Available in sklearn: `from sklearn.datasets import load_diabetes`

**Cancer:**
- Already using sklearn's breast cancer dataset
- For custom data: load from CSV

---

## 🔒 Production Deployment

### 1. Use Production WSGI Server

Don't use Flask's development server in production. Use Gunicorn:

```bash
pip install gunicorn

# Start with Gunicorn
gunicorn -w 4 -b 0.0.0.0:5001 app:app
```

### 2. Environment Variables

Create `.env` file:
```env
FLASK_ENV=production
ML_SERVER_PORT=5001
MODEL_PATH=./models
```

### 3. Docker Deployment

Create `Dockerfile`:
```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

# Train models on build
RUN python train_models.py

EXPOSE 5001

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5001", "app:app"]
```

Build and run:
```bash
docker build -t healthai-ml .
docker run -p 5001:5001 healthai-ml
```

---

## 📈 Performance Optimization

### 1. Model Caching
Models are loaded once on startup and kept in memory.

### 2. Async Processing
For high load, consider:
- Celery for background tasks
- Redis for queue management
- Load balancing with multiple workers

### 3. Model Optimization
```python
# Quantize models for faster inference
from sklearn.externals import joblib
import pickle

# Use pickle protocol 5 for faster loading
joblib.dump(model, 'model.pkl', protocol=5)
```

---

## 🐛 Troubleshooting

### Issue: Models not loading

**Solution:**
```bash
# Make sure models directory exists
ls -la models/

# If empty, train models
python train_models.py
```

### Issue: SHAP errors

**Solution:**
```bash
# Reinstall SHAP
pip uninstall shap
pip install shap==0.42.1
```

### Issue: Port already in use

**Solution:**
```bash
# Change port in app.py
app.run(port=5002)  # Use different port
```

### Issue: Slow predictions

**Solution:**
- Reduce model complexity
- Use model compression
- Deploy with Gunicorn workers
- Consider GPU acceleration for deep learning models

---

## 📚 Dependencies

- **Flask**: Web framework
- **scikit-learn**: ML algorithms
- **SHAP**: Model explainability
- **pandas**: Data manipulation
- **numpy**: Numerical computing
- **joblib**: Model serialization

---

## 🎓 Further Improvements

1. **Deep Learning Models**
   - Add TensorFlow/PyTorch models
   - CNN for medical image analysis
   - LSTM for time-series health data

2. **More Diseases**
   - Lung disease prediction
   - Kidney disease detection
   - Stroke risk assessment

3. **Real-time Learning**
   - Online learning from new data
   - Model retraining pipeline
   - A/B testing for models

4. **Advanced Explainability**
   - LIME integration
   - Attention visualization
   - Counterfactual explanations

---

## 📞 Support

**Common Issues:**
- Check Python version (3.8+)
- Verify all dependencies installed
- Ensure models are trained
- Check port availability

**Logs:**
```bash
# View server logs
python app.py 2>&1 | tee ml-server.log
```

---

**ML Server Ready! 🚀**

*For integration with frontend, see `/documentation/ML-Integration-Guide.md`*
