// ============================================
// HealthAI Platform - Frontend API Service
// ============================================
// This service handles all API calls to the backend

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Get auth token from localStorage
const getAuthToken = (): string | null => {
  return localStorage.getItem('authToken');
};

// Set auth token in localStorage
const setAuthToken = (token: string): void => {
  localStorage.setItem('authToken');
};

// Remove auth token from localStorage
const removeAuthToken = (): void => {
  localStorage.removeItem('authToken');
};

// Generic API request function
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<{ success: boolean; data?: T; message?: string; error?: string }> {
  const token = getAuthToken();
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'API request failed');
    }

    return data;
  } catch (error) {
    console.error('API Error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
}

// ============================================
// AUTHENTICATION APIs
// ============================================

export const authAPI = {
  // Register new user
  register: async (userData: {
    email: string;
    password: string;
    userType: 'patient' | 'doctor';
    fullName: string;
    phone?: string;
    dateOfBirth?: string;
    bloodGroup?: string;
    emergencyContact?: string;
    medicalLicense?: string;
    specialization?: string;
    hospitalName?: string;
    experience?: number;
    address?: string;
  }) => {
    const response = await apiRequest('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });

    if (response.success && response.data?.token) {
      setAuthToken(response.data.token);
    }

    return response;
  },

  // Login user
  login: async (email: string, password: string) => {
    const response = await apiRequest('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    if (response.success && response.data?.token) {
      setAuthToken(response.data.token);
    }

    return response;
  },

  // Verify token
  verifyToken: async () => {
    return await apiRequest('/auth/verify');
  },

  // Logout
  logout: () => {
    removeAuthToken();
  },
};

// ============================================
// PATIENT APIs
// ============================================

export const patientAPI = {
  // Get patient profile
  getProfile: async () => {
    return await apiRequest('/patients/profile');
  },

  // Update patient profile
  updateProfile: async (profileData: any) => {
    return await apiRequest('/patients/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    });
  },

  // Get dashboard stats
  getDashboard: async () => {
    return await apiRequest('/patients/dashboard');
  },
};

// ============================================
// DOCTOR APIs
// ============================================

export const doctorAPI = {
  // Get doctor profile
  getProfile: async () => {
    return await apiRequest('/doctors/profile');
  },

  // Update doctor profile
  updateProfile: async (profileData: any) => {
    return await apiRequest('/doctors/profile', {
      method: 'PUT',
      body: JSON.stringify(profileData),
    });
  },

  // Get doctor's patients
  getPatients: async () => {
    return await apiRequest('/doctors/patients');
  },
};

// ============================================
// AI PREDICTIONS APIs
// ============================================

export const predictionAPI = {
  // Create new prediction
  create: async (predictionData: {
    modelName: string;
    diseaseType: string;
    riskLevel: string;
    confidenceScore: number;
    predictionResult: string;
    inputParameters: any;
    explainabilityData?: any;
    recommendations?: string;
  }) => {
    return await apiRequest('/predictions', {
      method: 'POST',
      body: JSON.stringify(predictionData),
    });
  },

  // Get patient's predictions
  getPatientPredictions: async () => {
    return await apiRequest('/predictions/patient');
  },

  // Get prediction by ID
  getById: async (id: number) => {
    return await apiRequest(`/predictions/${id}`);
  },
};

// ============================================
// EHR (Electronic Health Records) APIs
// ============================================

export const ehrAPI = {
  // Get health records
  getRecords: async () => {
    return await apiRequest('/ehr');
  },

  // Create health record
  createRecord: async (recordData: {
    recordType: string;
    recordTitle: string;
    recordDescription?: string;
    recordDate: string;
    fileUrl?: string;
  }) => {
    return await apiRequest('/ehr', {
      method: 'POST',
      body: JSON.stringify(recordData),
    });
  },
};

// ============================================
// PRESCRIPTION APIs
// ============================================

export const prescriptionAPI = {
  // Get prescriptions
  getPrescriptions: async () => {
    return await apiRequest('/prescriptions');
  },

  // Get prescription medications
  getMedications: async (prescriptionId: number) => {
    return await apiRequest(`/prescriptions/${prescriptionId}/medications`);
  },
};

// ============================================
// APPOINTMENT APIs
// ============================================

export const appointmentAPI = {
  // Get appointments
  getAppointments: async () => {
    return await apiRequest('/appointments');
  },

  // Create appointment
  createAppointment: async (appointmentData: {
    doctorId: number;
    appointmentDate: string;
    appointmentTime: string;
    appointmentType: string;
    chiefComplaint?: string;
  }) => {
    return await apiRequest('/appointments', {
      method: 'POST',
      body: JSON.stringify(appointmentData),
    });
  },
};

// ============================================
// IoT WEARABLE DEVICES APIs
// ============================================

export const iotAPI = {
  // Get devices
  getDevices: async () => {
    return await apiRequest('/iot/devices');
  },

  // Get readings
  getReadings: async (limit: number = 100) => {
    return await apiRequest(`/iot/readings?limit=${limit}`);
  },

  // Add reading
  addReading: async (readingData: {
    deviceId: number;
    readingType: string;
    readingValue: number;
    unit: string;
  }) => {
    return await apiRequest('/iot/readings', {
      method: 'POST',
      body: JSON.stringify(readingData),
    });
  },
};

// ============================================
// INSURANCE CLAIMS APIs
// ============================================

export const insuranceAPI = {
  // Get claims
  getClaims: async () => {
    return await apiRequest('/insurance');
  },

  // Submit claim
  submitClaim: async (claimData: {
    policyNumber: string;
    insuranceProvider: string;
    claimType: string;
    claimAmount: number;
    treatmentDate: string;
    diagnosis: string;
  }) => {
    return await apiRequest('/insurance', {
      method: 'POST',
      body: JSON.stringify(claimData),
    });
  },
};

// ============================================
// ABDM INTEGRATION APIs
// ============================================

export const abdmAPI = {
  // Get consents
  getConsents: async () => {
    return await apiRequest('/abdm/consents');
  },

  // Link health ID
  linkHealthId: async (healthId: string) => {
    return await apiRequest('/abdm/link-health-id', {
      method: 'POST',
      body: JSON.stringify({ healthId }),
    });
  },
};

// ============================================
// NOTIFICATION APIs
// ============================================

export const notificationAPI = {
  // Get notifications
  getNotifications: async () => {
    return await apiRequest('/notifications');
  },

  // Mark as read
  markAsRead: async (notificationId: number) => {
    return await apiRequest(`/notifications/${notificationId}/read`, {
      method: 'PUT',
    });
  },
};

// ============================================
// EMERGENCY APIs
// ============================================

export const emergencyAPI = {
  // Send emergency alert
  sendAlert: async (alertData: {
    latitude?: number;
    longitude?: number;
    address?: string;
    alertType: string;
  }) => {
    return await apiRequest('/emergency/alert', {
      method: 'POST',
      body: JSON.stringify(alertData),
    });
  },

  // Get alerts
  getAlerts: async () => {
    return await apiRequest('/emergency/alerts');
  },
};

// ============================================
// ANALYTICS APIs
// ============================================

export const analyticsAPI = {
  // Get disease trends
  getDiseaseTrends: async () => {
    return await apiRequest('/analytics/disease-trends');
  },

  // Get predictions summary
  getPredictionsSummary: async () => {
    return await apiRequest('/analytics/predictions-summary');
  },
};

// Export all APIs
export default {
  auth: authAPI,
  patient: patientAPI,
  doctor: doctorAPI,
  prediction: predictionAPI,
  ehr: ehrAPI,
  prescription: prescriptionAPI,
  appointment: appointmentAPI,
  iot: iotAPI,
  insurance: insuranceAPI,
  abdm: abdmAPI,
  notification: notificationAPI,
  emergency: emergencyAPI,
  analytics: analyticsAPI,
};
