# Authentication System Documentation

## Overview
The HealthAI platform now features a comprehensive authentication system with separate sign-in and sign-up flows for both Patient and Doctor portals.

## Features

### 🔐 Dual Portal Authentication
- **Patient Portal**: Tailored registration for patients with health-specific fields
- **Doctor Portal**: Professional registration with medical credentials

### 📋 Registration Fields

#### Patient Registration
- Full Name
- Email Address
- Password (with show/hide toggle)
- Phone Number
- Date of Birth
- Blood Group (dropdown)
- Emergency Contact
- Address

#### Doctor Registration
- Full Name
- Email Address
- Password (with show/hide toggle)
- Phone Number
- Date of Birth
- Medical License Number
- Specialization (dropdown with 8+ specialties)
- Hospital/Clinic Name
- Years of Experience
- Address

### 🎨 Design Features
- **Beautiful Modal UI**: Glassmorphism design with gradient headers
- **Portal-Specific Colors**: Blue gradient for patients, Purple gradient for doctors
- **Smooth Animations**: Motion animations for form transitions
- **Responsive**: Optimized for all screen sizes
- **Multi-language Support**: English, Hindi, and Telugu

### 🔄 User Flow

1. **Landing Page**: User sees beautiful 3D animated interface
2. **Portal Selection**: User clicks on "Patient Portal" or "Doctor Portal" card
3. **Authentication Modal**: Modal appears with portal-specific branding
4. **Toggle**: User can switch between "Sign In" and "Create Account"
5. **Form Submission**: Demo mode allows any credentials for testing
6. **Dashboard Access**: Upon successful login, user enters their dashboard

### 🛡️ Security Features
- Password visibility toggle
- ABDM (Ayushman Bharat Digital Mission) integration reference
- Secure credential handling (demo mode)
- Form validation ready

### 🌐 Internationalization
All authentication screens support three languages:
- English (🇬🇧)
- Hindi (🇮🇳)
- Telugu (🇮🇳)

### 💡 Demo Mode
Currently in demo mode for presentation purposes:
- Any email/password combination works
- All fields are optional
- Instant authentication for testing
- "Demo Mode" badge displayed for transparency

### 🎯 Real-World Ready
The authentication system is structured to easily integrate:
- Backend API endpoints
- JWT token management
- Form validation
- Email verification
- Password recovery
- Two-factor authentication
- ABDM health ID integration

## Components

### `AuthModal` Component
Location: `/components/auth-modal.tsx`

**Props:**
- `portalType`: 'patient' | 'doctor'
- `onLogin`: Callback function with user data
- `onClose`: Modal close handler
- `language`: Current selected language

**Key Features:**
- Dynamic form fields based on portal type
- Animated form transitions
- Real-time form state management
- Accessible form design

## Integration

The authentication modal is seamlessly integrated into the landing page:

```typescript
// Click handler on portal cards
const handlePortalClick = (portal: 'patient' | 'doctor') => {
  setSelectedPortal(portal);
  setShowAuthModal(true);
};

// Login handler
const handleLogin = (type: 'patient' | 'doctor', userData: any) => {
  setUserType(type);
  setShowAuthModal(false);
};
```

## Future Enhancements

- Backend API integration
- Email verification flow
- Password strength indicator
- Social authentication (Google, Apple)
- Biometric authentication
- Session management
- Remember me functionality
- Account recovery
- Profile picture upload
- Terms & conditions acceptance

---

**Note**: This is currently a demo implementation. For production use, implement proper backend authentication, validation, and security measures.
