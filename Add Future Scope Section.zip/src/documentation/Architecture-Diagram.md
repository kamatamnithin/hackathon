# 🏗️ HealthAI Platform Architecture

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                      FRONTEND (React + Tailwind)                 │
│                     Beautiful 3D Animated UI                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   Patient    │  │    Doctor    │  │    Admin     │          │
│  │  Dashboard   │  │  Dashboard   │  │  Dashboard   │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │         Authentication Modal (auth-modal.tsx)            │   │
│  │    - Sign In / Sign Up Forms                             │   │
│  │    - Patient & Doctor Portal Selection                   │   │
│  │    - Real-time Form Validation                           │   │
│  └─────────────────────────────────────────────────────────┘   │
│                              ▼                                    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │         API Service Layer (/services/api.ts)             │   │
│  │    - authAPI, patientAPI, doctorAPI                      │   │
│  │    - predictionAPI, ehrAPI, prescriptionAPI              │   │
│  │    - appointmentAPI, iotAPI, insuranceAPI                │   │
│  │    - abdmAPI, notificationAPI, emergencyAPI              │   │
│  └───────────────────────────────────────────���─────────────┘   │
└───────────────────────────────┬─────────────────────────────────┘
                                 │
                          HTTP/HTTPS
                      (REST API Calls)
                         JWT Token Auth
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│               BACKEND (Node.js + Express + MySQL)                │
│                    Running on Port 5000                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                  Express Server (server.js)              │   │
│  │    - CORS Middleware                                      │   │
│  │    - JWT Authentication                                   │   │
│  │    - Rate Limiting                                        │   │
│  │    - Request Logging                                      │   │
│  │    - Error Handling                                       │   │
│  └─────────────────────────────────────────────────────────┘   │
│                              ▼                                    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │         Authentication Middleware (middleware/auth.js)    │   │
│  │    - Verify JWT Tokens                                    │   │
│  │    - Check User Permissions                               │   │
│  │    - Attach User Info to Requests                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                              ▼                                    │
│  ┌────────────��────────────────────────────────────────────┐   │
│  │                   API Routes (13 modules)                 │   │
│  ├─────────────────────────────────────────────────────────┤   │
│  │  /api/auth          - Registration, Login, Verify         │   │
│  │  /api/patients      - Profile, Dashboard, Stats          │   │
│  │  /api/doctors       - Profile, Patients List             │   │
│  │  /api/predictions   - AI Model Predictions               │   │
│  │  /api/ehr           - Electronic Health Records          │   │
│  │  /api/prescriptions - Prescription Management            │   │
│  │  /api/appointments  - Telemedicine Bookings              │   │
│  │  /api/iot           - Wearable Device Data               │   │
│  │  /api/insurance     - Insurance Claims                   │   │
│  │  /api/abdm          - ABDM Integration                   │   │
│  │  /api/notifications - User Notifications                 │   │
│  │  /api/emergency     - Emergency SOS Alerts               │   │
│  │  /api/analytics     - Disease Trends & Analytics         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                              ▼                                    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │         Database Connection Pool (config/database.js)     │   │
│  │    - MySQL2 with Promise Support                          │   │
│  │    - Connection Pooling (10 connections)                  │   │
│  │    - Transaction Support                                  │   │
│  │    - Error Handling & Retry Logic                         │   │
│  └─────────────────────────────────────────────────────────┘   │
└───────────────────────────────┬─────────────────────────────────┘
                                 │
                           SQL Queries
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                   MySQL DATABASE (healthcare)                    │
│              Host: localhost  User: UDHAY  Port: 3306            │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    Core Authentication Tables             │   │
│  │    • users (email, password, user_type)                   │   │
│  │    • patient_profiles (demographics, health info)         │   │
│  │    • doctor_profiles (credentials, specialization)        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    Health Data Tables                     │   │
│  │    • health_records (EHR, lab reports, imaging)           │   │
│  │    • ai_predictions (model results, confidence scores)    │   │
│  │    • prescriptions (doctor prescriptions)                 │   │
│  │    • prescription_medications (medication details)        │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              Appointments & Communication Tables          │   │
│  ���    • appointments (telemedicine bookings)                 │   │
│  │    • notifications (user alerts)                          │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    IoT & Monitoring Tables                │   │
│  │    • iot_devices (wearable devices)                       │   │
│  │    • iot_readings (heart rate, BP, glucose, etc.)         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │               Insurance & ABDM Integration Tables         │   │
│  │    • insurance_claims (claim submissions & status)        │   │
│  │    • abdm_consents (consent management)                   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                Emergency & Analytics Tables               │   │
│  │    • emergency_alerts (SOS alerts, location)              │   │
│  │    • disease_statistics (trends, demographics)            │   │
│  │    • audit_logs (security audit trail)                    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow Example: User Registration

```
1. USER ACTION
   ↓
   User clicks "Patient Portal" → Auth Modal Opens

2. FRONTEND (auth-modal.tsx)
   ↓
   User fills registration form and clicks "Create Account"

3. API SERVICE LAYER (/services/api.ts)
   ↓
   api.auth.register({
     email, password, userType, fullName, phone, etc.
   })
   ↓
   POST http://localhost:5000/api/auth/register
   Headers: { "Content-Type": "application/json" }
   Body: { user registration data }

4. BACKEND (routes/auth.js)
   ↓
   • Validate input data
   • Check if email already exists
   • Hash password with bcrypt (10 rounds)
   • Begin MySQL transaction

5. DATABASE (MySQL)
   ↓
   • INSERT INTO users (email, password_hash, user_type)
   • Get inserted user_id
   • INSERT INTO patient_profiles (user_id, full_name, phone, ...)
   • Commit transaction

6. BACKEND RESPONSE
   ↓
   • Generate JWT token (user_id, email, user_type)
   • Return { success: true, token, user: {...} }

7. FRONTEND RECEIVES RESPONSE
   ↓
   • Store JWT token in localStorage
   • Call onLogin(userType, userData)
   • Redirect to dashboard

8. USER DASHBOARD LOADS
   ↓
   • Fetch data using stored JWT token
   • GET /api/patients/profile (with Authorization header)
   • GET /api/predictions/patient
   • GET /api/appointments
   • Display user data in beautiful UI
```

## Authentication Flow

```
���────────────┐                 ┌────────────┐                 ┌────────────┐
│  Frontend  │                 │   Backend  │                 │  Database  │
└────────────┘                 └────────────┘                 └────────────┘
      │                               │                               │
      │  1. POST /api/auth/login      │                               │
      │  { email, password }           │                               │
      │──────────────────────────────>│                               │
      │                               │  2. SELECT user WHERE email   │
      │                               │──────────────────────────────>│
      │                               │                               │
      │                               │  3. Return user data          │
      │                               │<──────────────────────────────│
      │                               │                               │
      │                               ���  4. Verify password (bcrypt)  │
      │                               │                               │
      │                               │  5. Generate JWT token        │
      │                               │  (userId, email, userType)    │
      │                               │                               │
      │  6. Return token & user data  │                               │
      │<──────────────────────────────│                               │
      │                               │                               │
      │  7. Store token in localStorage                               │
      │                               │                               │
      │  8. GET /api/patients/profile │                               │
      │  Authorization: Bearer TOKEN  │                               │
      │──────────────────────────────>│                               │
      │                               │  9. Verify JWT token          │
      │                               │                               │
      │                               │  10. Decode token             │
      │                               │  Extract userId               │
      ��                               │                               │
      │                               │  11. Query patient profile    │
      │                               │──────────────────────────────>│
      │                               │                               │
      │                               │  12. Return profile data      │
      │                               │<──────────────────────────────│
      │                               │                               │
      │  13. Return profile to user   │                               │
      │<──────────────────────────────│                               │
      │                               │                               │
      │  14. Display in dashboard     │                               │
      │                               │                               │
```

## Security Layers

```
┌─────────────────────────────────────────────────────────────────┐
│                         Security Layers                          ��
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  Layer 1: HTTPS/TLS Encryption                                   │
│  └─ All traffic encrypted in production                          │
│                                                                   │
│  Layer 2: CORS (Cross-Origin Resource Sharing)                   │
│  └─ Only allowed origins can access API                          │
│                                                                   │
│  Layer 3: Rate Limiting                                          │
│  └─ Max 100 requests per 15 minutes per IP                       │
│                                                                   │
│  Layer 4: Helmet (HTTP Headers Security)                         │
│  └─ Protects against common web vulnerabilities                  │
│                                                                   │
│  Layer 5: Input Validation (express-validator)                   │
│  └─ Validates and sanitizes all user inputs                      │
│                                                                   │
│  Layer 6: JWT Authentication                                     │
│  └─ Stateless token-based authentication                         │
│  └─ Tokens expire after 7 days                                   │
│                                                                   │
│  Layer 7: Password Hashing (bcryptjs)                            │
│  └─ 10 rounds of salting                                         │
│  └─ One-way hashing (cannot be reversed)                         │
│                                                                   │
│  Layer 8: SQL Injection Prevention                               │
│  └─ Prepared statements with parameterized queries               │
│                                                                   │
│  Layer 9: Role-Based Access Control (RBAC)                       │
│  └─ Patient vs Doctor permissions                                │
│  └─ Middleware checks user roles                                 │
│                                                                   │
│  Layer 10: Audit Logging                                         │
│  └─ All database operations logged                               │
│  └─ IP address and user agent tracking                           │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

## Technology Stack

```
┌─────────────────────────────────────────────────────────────────┐
│                         Frontend Stack                           │
├─────────────────────────────────────────────────────────────────┤
│  • React 18 - UI Framework                                       │
│  • TypeScript - Type Safety                                      │
│  • Tailwind CSS - Styling                                        │
│  • Motion/React - Animations                                     │
│  • Lucide React - Icons                                          │
│  • Recharts - Data Visualization                                 │
│  • ShadCN UI - Component Library                                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                         Backend Stack                            │
├─────────────────────────────────────────────────────────────────┤
│  • Node.js 16+ - Runtime Environment                             │
│  • Express 4.18 - Web Framework                                  │
│  • MySQL2 - Database Driver (Promise-based)                      │
│  • bcryptjs - Password Hashing                                   │
│  • jsonwebtoken - JWT Authentication                             │
│  • express-validator - Input Validation                          │
│  • helmet - Security Headers                                     │
│  • cors - Cross-Origin Resource Sharing                          │
│  • express-rate-limit - API Rate Limiting                        │
│  • morgan - Request Logging                                      │
│  • compression - Response Compression                            │
│  • dotenv - Environment Variables                                │
��─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                         Database Stack                           │
├─────────────────────────────────────────────────────────────────┤
│  • MySQL 8.0+ - Relational Database                              │
│  • InnoDB Engine - ACID Transactions                             │
│  • UTF8MB4 Character Set - Full Unicode Support                  │
│  • Connection Pooling - Performance Optimization                 │
│  • Indexes - Query Performance                                   │
│  • Foreign Keys - Referential Integrity                          │
└─────────────────────────────────────────────────────────────────┘
```

## Deployment Architecture (Future)

```
                              ┌��─────────────┐
                              │   End Users  │
                              └──────────────┘
                                      │
                                   HTTPS
                                      │
                              ┌──────────────┐
                              │  CloudFlare  │
                              │     CDN      │
                              └──────────────┘
                                      │
                  ┌───────────────────┴───────────────────┐
                  │                                       │
          ┌──────────────┐                      ┌──────────────┐
          │   Vercel /   │                      │   Railway /  │
          │   Netlify    │                      │     VPS      │
          │   (Frontend) │                      │   (Backend)  │
          └──────────────┘                      └──────────────┘
                                                        │
                                                 ┌────���─────────┐
                                                 │    MySQL     │
                                                 │   Database   │
                                                 │  (Managed)   │
                                                 └──────────────┘
```

---

This architecture provides a **secure, scalable, and maintainable** healthcare platform! 🚀
