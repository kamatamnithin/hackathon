# 🤖 HealthAI ML Integration - Complete Guide

## 🎯 System Architecture

```
┌─────────────────┐      ┌──────────────────┐      ┌─────────────────┐
│   React         │      │   Node.js        │      │   Python        │
│   Frontend      │─────▶│   Backend        │─────▶│   ML Server     │
│   (Port 5173)   │      │   (Port 5000)    │      │   (Port 5001)   │
└─────────────────┘      └──────────────────┘      └─────────────────┘
         │                        │                          │
         │                        │                          │
         │                        ▼                          ▼
         │               ┌──────────────┐          ┌──────────────┐
         │               │    MySQL     │          │  ML Models   │
         └──────────────▶│   Database   │          │   (.pkl)     │
                         └──────────────┘          └──────────────┘
```

---

## 🚀 Complete Setup (3 Servers)

### Server 1: ML Server (Python)

```bash
# Terminal 1
cd ml-server

# Install dependencies
pip install -r requirements.txt

# Train models (first time only)
python train_models.py

# Start ML server
python app.py
```

✅ ML Server running on: **http://localhost:5001**

### Server 2: Backend API (Node.js)

```bash
# Terminal 2
cd backend

# Install dependencies
npm install

# Setup database (first time only)
npm run setup-db

# Start backend
npm run dev
```

✅ Backend API running on: **http://localhost:5000**

### Server 3: Frontend (React)

```bash
# Terminal 3
cd ..

# Install dependencies (if not done)
npm install

# Start frontend
npm run dev
```

✅ Frontend running on: **http://localhost:5173**

---

## 📊 How It Works

### Flow 1: Heart Disease Prediction

**Step 1: User Input (Frontend)**
```typescript
// User fills form with health data
const formData = {
  age: 55,
  sex: 1,
  cp: 2,
  trestbps: 140,
  chol: 250,
  // ... other fields
};
```

**Step 2: API Call to Backend**
```typescript
// From frontend
import api from '../services/api';

const response = await api.prediction.runPrediction({
  diseaseType: 'heart_disease',
  inputData: formData
});
```

**Step 3: Backend Routes to ML Server**
```javascript
// /backend/routes/predictions.js
POST /api/predictions/run
↓
Node.js calls ML Server
↓
POST http://localhost:5001/predict/heart-disease
```

**Step 4: ML Server Predicts**
```python
# /ml-server/app.py
1. Load Random Forest model
2. Predict disease probability
3. Calculate SHAP explanations
4. Generate recommendations
5. Return JSON response
```

**Step 5: Backend Saves to Database**
```javascript
// Save prediction to MySQL
INSERT INTO ai_predictions (
  patient_id, model_name, disease_type,
  risk_level, confidence_score, ...
)
```

**Step 6: Frontend Displays Results**
```typescript
// Beautiful UI with:
- Risk level visualization
- Confidence meter
- SHAP explanations
- Recommendations
```

---

## 🔌 Frontend API Integration

### Update API Service

Open `/services/api.ts` and add:

```typescript
// AI Prediction with real ML
export const predictionAPI = {
  // Run ML prediction
  runPrediction: async (data: {
    diseaseType: 'heart_disease' | 'diabetes' | 'cancer';
    inputData: any;
  }) => {
    return await apiRequest('/predictions/run', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  // Check ML server status
  checkMLServer: async () => {
    return await apiRequest('/predictions/ml-server/status');
  },

  // Get ML models info
  getMLModels: async () => {
    return await apiRequest('/predictions/ml-server/models');
  },

  // ... existing methods
};
```

### Create Heart Disease Form Component

Create `/components/heart-disease-form.tsx`:

```typescript
import { useState } from 'react';
import api from '../services/api';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';

export function HeartDiseaseForm() {
  const [formData, setFormData] = useState({
    age: 50,
    sex: 1,
    cp: 0,
    trestbps: 120,
    chol: 200,
    fbs: 0,
    restecg: 0,
    thalach: 150,
    exang: 0,
    oldpeak: 0,
    slope: 0,
    ca: 0,
    thal: 0
  });

  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await api.prediction.runPrediction({
        diseaseType: 'heart_disease',
        inputData: formData
      });

      if (response.success) {
        setPrediction(response.data);
      } else {
        alert('Prediction failed: ' + response.error);
      }
    } catch (error) {
      console.error('Error:', error);
      alert('Failed to run prediction');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h2 className="text-2xl font-bold mb-4">Heart Disease Risk Assessment</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-2">Age</label>
              <Input
                type="number"
                value={formData.age}
                onChange={(e) => setFormData({...formData, age: parseInt(e.target.value)})}
              />
            </div>

            <div>
              <label className="block mb-2">Sex</label>
              <select
                value={formData.sex}
                onChange={(e) => setFormData({...formData, sex: parseInt(e.target.value)})}
                className="w-full p-2 border rounded"
              >
                <option value={1}>Male</option>
                <option value={0}>Female</option>
              </select>
            </div>

            <div>
              <label className="block mb-2">Chest Pain Type (0-3)</label>
              <Input
                type="number"
                min="0"
                max="3"
                value={formData.cp}
                onChange={(e) => setFormData({...formData, cp: parseInt(e.target.value)})}
              />
            </div>

            <div>
              <label className="block mb-2">Blood Pressure</label>
              <Input
                type="number"
                value={formData.trestbps}
                onChange={(e) => setFormData({...formData, trestbps: parseInt(e.target.value)})}
              />
            </div>

            <div>
              <label className="block mb-2">Cholesterol</label>
              <Input
                type="number"
                value={formData.chol}
                onChange={(e) => setFormData({...formData, chol: parseInt(e.target.value)})}
              />
            </div>

            <div>
              <label className="block mb-2">Max Heart Rate</label>
              <Input
                type="number"
                value={formData.thalach}
                onChange={(e) => setFormData({...formData, thalach: parseInt(e.target.value)})}
              />
            </div>
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? 'Analyzing...' : 'Run AI Prediction'}
          </Button>
        </form>
      </Card>

      {prediction && (
        <Card className="p-6 bg-gradient-to-br from-blue-50 to-purple-50">
          <h3 className="text-xl font-bold mb-4">Prediction Results</h3>
          
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-600">Prediction</p>
              <p className="text-2xl font-bold">{prediction.prediction}</p>
            </div>

            <div>
              <p className="text-sm text-gray-600">Risk Level</p>
              <p className={`text-xl font-bold ${
                prediction.risk_level === 'critical' ? 'text-red-600' :
                prediction.risk_level === 'high' ? 'text-orange-600' :
                prediction.risk_level === 'medium' ? 'text-yellow-600' :
                'text-green-600'
              }`}>
                {prediction.risk_level.toUpperCase()}
              </p>
            </div>

            <div>
              <p className="text-sm text-gray-600">Confidence Score</p>
              <p className="text-xl font-bold">{prediction.confidence_score.toFixed(1)}%</p>
            </div>

            <div>
              <p className="text-sm text-gray-600 mb-2">Top Contributing Factors</p>
              {prediction.feature_importance?.slice(0, 5).map((feature: any, idx: number) => (
                <div key={idx} className="flex justify-between items-center mb-2">
                  <span>{feature.feature}</span>
                  <span className="font-mono text-sm">
                    {(feature.importance * 100).toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>

            {prediction.recommendations && (
              <div>
                <p className="text-sm text-gray-600 mb-2">Recommendations</p>
                <ul className="space-y-1">
                  {prediction.recommendations.map((rec: string, idx: number) => (
                    <li key={idx} className="text-sm">• {rec}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
}
```

### Add to Patient Dashboard

Update `/components/patient-dashboard.tsx`:

```typescript
import { HeartDiseaseForm } from './heart-disease-form';

// In your dashboard component:
<Tabs>
  <TabsList>
    <TabsTrigger value="overview">Overview</TabsTrigger>
    <TabsTrigger value="predictions">AI Predictions</TabsTrigger>
    {/* ... other tabs */}
  </TabsList>

  <TabsContent value="predictions">
    <HeartDiseaseForm />
  </TabsContent>
</Tabs>
```

---

## 🧪 Testing the Integration

### Test 1: Check All Servers Running

```bash
# Test ML Server
curl http://localhost:5001/health

# Test Backend
curl http://localhost:5000/health

# Test ML Integration
curl http://localhost:5000/api/predictions/ml-server/status
```

### Test 2: Run Prediction via Backend

```bash
curl -X POST http://localhost:5000/api/predictions/run \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "diseaseType": "heart_disease",
    "inputData": {
      "age": 55,
      "sex": 1,
      "cp": 2,
      "trestbps": 140,
      "chol": 250,
      "fbs": 1,
      "restecg": 0,
      "thalach": 150,
      "exang": 1,
      "oldpeak": 1.5,
      "slope": 2,
      "ca": 1,
      "thal": 2
    }
  }'
```

### Test 3: From Frontend

1. Start all three servers
2. Login to patient portal
3. Go to AI Predictions tab
4. Fill in health data
5. Click "Run AI Prediction"
6. View results with SHAP explanations

---

## 🔧 Configuration

### Backend Environment Variables

Add to `/backend/.env`:

```env
# ML Server Configuration
ML_SERVER_URL=http://localhost:5001
ML_SERVER_TIMEOUT=30000
```

### Frontend Environment Variables

Add to `/.env`:

```env
# API Configuration
VITE_API_URL=http://localhost:5000/api
VITE_ML_ENABLED=true
```

---

## 📊 Database Integration

Predictions are automatically saved to MySQL:

```sql
SELECT 
  p.prediction_id,
  p.disease_type,
  p.risk_level,
  p.confidence_score,
  p.prediction_result,
  p.recommendations,
  p.prediction_date,
  pt.full_name as patient_name
FROM ai_predictions p
JOIN patient_profiles pt ON p.patient_id = pt.patient_id
ORDER BY p.prediction_date DESC;
```

---

## 🚨 Error Handling

### ML Server Offline

Backend automatically handles ML server being offline:

```javascript
// Returns user-friendly error
{
  "success": false,
  "message": "ML prediction service unavailable",
  "note": "Please check if ML server is running on port 5001"
}
```

### Invalid Input

ML server validates all inputs:

```json
{
  "success": false,
  "error": "Invalid input: age must be between 0 and 120"
}
```

---

## 🎨 UI Components

### Confidence Meter

Already created at `/components/ConfidenceMeter.tsx`:

```typescript
<ConfidenceMeter 
  score={prediction.confidence_score} 
  label="Prediction Confidence"
/>
```

### Explainability Chart

Already created at `/components/ExplainableAI.tsx`:

```typescript
<ExplainableAI 
  modelName={prediction.model}
  features={prediction.feature_importance}
  shapValues={prediction.explainability.shap_values}
/>
```

---

## 🔄 Real-time Updates

### Option 1: Polling

```typescript
useEffect(() => {
  const interval = setInterval(async () => {
    const status = await api.prediction.checkMLServer();
    setMLServerStatus(status);
  }, 10000); // Check every 10 seconds

  return () => clearInterval(interval);
}, []);
```

### Option 2: WebSocket (Future)

For real-time prediction updates when running multiple models.

---

## 📈 Performance Optimization

### 1. Cache ML Models

Models are loaded once on ML server startup and kept in memory.

### 2. Async Processing

For batch predictions:

```python
# In ml-server/app.py
@app.route('/predict/batch', methods=['POST'])
def predict_batch():
    # Process multiple predictions at once
    pass
```

### 3. Model Compression

```python
# Reduce model size
from sklearn.externals import joblib

joblib.dump(model, 'model.pkl', compress=3)
```

---

## 🐛 Troubleshooting

### Issue: "ML prediction service unavailable"

**Cause:** ML server not running

**Solution:**
```bash
cd ml-server
python app.py
```

### Issue: "Models not loaded"

**Cause:** Models not trained

**Solution:**
```bash
cd ml-server
python train_models.py
```

### Issue: Slow predictions

**Cause:** Model complexity or server load

**Solution:**
- Use Gunicorn with multiple workers
- Implement prediction caching
- Optimize model complexity

---

## 🚀 Deployment

### Production Setup

1. **ML Server** → Deploy on separate server/container
2. **Backend** → Update ML_SERVER_URL to production URL
3. **Use HTTPS** → Secure communication between services

```env
# Production Backend .env
ML_SERVER_URL=https://ml-server.yourdomain.com
```

### Docker Compose

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  mysql:
    image: mysql:8.0
    environment:
      MYSQL_DATABASE: healthcare
      MYSQL_USER: UDHAY
      MYSQL_PASSWORD: Teja@7586

  ml-server:
    build: ./ml-server
    ports:
      - "5001:5001"

  backend:
    build: ./backend
    ports:
      - "5000:5000"
    environment:
      ML_SERVER_URL: http://ml-server:5001
    depends_on:
      - mysql
      - ml-server

  frontend:
    build: .
    ports:
      - "80:80"
    depends_on:
      - backend
```

Run with:
```bash
docker-compose up -d
```

---

## ✅ Verification Checklist

- [ ] ML Server running on port 5001
- [ ] Backend running on port 5000
- [ ] Frontend running on port 5173
- [ ] MySQL database configured
- [ ] Models trained and loaded
- [ ] ML server health check returns OK
- [ ] Backend can reach ML server
- [ ] Predictions saved to database
- [ ] Frontend displays results correctly
- [ ] SHAP explanations showing
- [ ] Recommendations displaying

---

## 🎓 Next Steps

1. **Add More Models**
   - Kidney disease
   - Stroke risk
   - Mental health assessment

2. **Improve UI**
   - Animated prediction visualization
   - Interactive SHAP charts
   - Trend analysis over time

3. **Advanced Features**
   - Model comparison
   - Ensemble predictions
   - Uncertainty quantification

---

## 📞 Support

**ML Server Issues:**
- Check Python version (3.8+)
- Verify models trained
- Check port 5001 availability

**Integration Issues:**
- Verify all servers running
- Check network connectivity
- Review server logs

**Logs:**
```bash
# ML Server logs
cd ml-server && python app.py 2>&1 | tee ml.log

# Backend logs
cd backend && npm run dev 2>&1 | tee backend.log
```

---

**🎉 Your HealthAI platform now has REAL ML integration!**

*Complete setup time: ~10 minutes*
*Models trained and ready to predict!*
