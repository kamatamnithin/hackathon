import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface ExplainabilityChartProps {
  patientId: string;
}

export function ExplainabilityChart({ patientId }: ExplainabilityChartProps) {
  // SHAP-like feature importance data
  const data = [
    { feature: 'Blood Sugar Level', impact: 0.85, positive: false },
    { feature: 'BMI', impact: 0.72, positive: false },
    { feature: 'Age', impact: 0.54, positive: false },
    { feature: 'Cholesterol', impact: 0.48, positive: false },
    { feature: 'Exercise Frequency', impact: 0.35, positive: true },
    { feature: 'Family History', impact: 0.28, positive: false },
    { feature: 'Blood Pressure', impact: 0.22, positive: false },
    { feature: 'Diet Quality', impact: 0.18, positive: true }
  ];

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="text-blue-900 mb-2">SHAP Feature Importance Analysis</h4>
        <p className="text-blue-700 text-sm">
          This chart shows which health parameters contributed most to the AI's prediction. 
          Red bars indicate risk-increasing factors, green bars show protective factors.
        </p>
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ top: 5, right: 30, left: 120, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis type="number" domain={[0, 1]} stroke="#6b7280" />
            <YAxis type="category" dataKey="feature" stroke="#6b7280" />
            <Tooltip
              contentStyle={{
                backgroundColor: 'white',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                padding: '8px 12px'
              }}
              formatter={(value: number) => [`Impact: ${(value * 100).toFixed(1)}%`, '']}
            />
            <Bar dataKey="impact" radius={[0, 8, 8, 0]}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.positive ? '#10b981' : '#ef4444'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-4 h-4 bg-red-500 rounded"></div>
            <span className="text-red-900">Risk Factors</span>
          </div>
          <p className="text-red-700 text-sm">
            Parameters that increase disease probability
          </p>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-4 h-4 bg-green-500 rounded"></div>
            <span className="text-green-900">Protective Factors</span>
          </div>
          <p className="text-green-700 text-sm">
            Parameters that decrease disease probability
          </p>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="text-gray-900 mb-2">Clinical Recommendations</h4>
        <ul className="space-y-2">
          <li className="text-gray-700 text-sm flex items-start gap-2">
            <span className="text-blue-600 mt-1">•</span>
            <span>Immediate attention needed for blood sugar management - consider medication adjustment</span>
          </li>
          <li className="text-gray-700 text-sm flex items-start gap-2">
            <span className="text-blue-600 mt-1">•</span>
            <span>BMI reduction through structured diet plan recommended</span>
          </li>
          <li className="text-gray-700 text-sm flex items-start gap-2">
            <span className="text-blue-600 mt-1">•</span>
            <span>Increase exercise frequency to 4-5 times per week for protective benefits</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
