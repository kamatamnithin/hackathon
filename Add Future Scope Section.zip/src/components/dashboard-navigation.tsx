import { motion } from 'motion/react';
import { 
  Activity, FileText, Video, Shield, AlertCircle, 
  Watch, DollarSign, Calendar, PieChart
} from 'lucide-react';

interface DashboardNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  userType: 'patient' | 'doctor';
  language: 'en' | 'hi' | 'te';
}

export function DashboardNavigation({ activeTab, onTabChange, userType, language }: DashboardNavigationProps) {
  const translations = {
    en: {
      overview: 'Overview',
      ehr: 'Health Records',
      telemedicine: 'Telemedicine',
      prescriptions: 'Prescriptions',
      sos: 'Emergency SOS',
      wearables: 'IoT Wearables',
      insurance: 'Insurance',
      abdm: 'ABDM',
      analytics: 'Analytics'
    },
    hi: {
      overview: 'अवलोकन',
      ehr: 'स्वास्थ्य रिकॉर्ड',
      telemedicine: 'टेलीमेडिसिन',
      prescriptions: 'प्रिस्क्रिप्शन',
      sos: 'आपातकालीन SOS',
      wearables: 'IoT डिवाइस',
      insurance: 'बीमा',
      abdm: 'ABDM',
      analytics: 'विश्लेषण'
    },
    te: {
      overview: 'అవలోకనం',
      ehr: 'హెల్త్ రికార్డులు',
      telemedicine: 'టెలిమెడిసిన్',
      prescriptions: 'ప్రిస్క్రిప్షన్‌లు',
      sos: 'ఎమర్జెన్సీ SOS',
      wearables: 'IoT డివైజులు',
      insurance: 'బీమా',
      abdm: 'ABDM',
      analytics: 'అనలిటిక్స్'
    }
  };

  const t = translations[language];

  const tabs = [
    { id: 'overview', label: t.overview, icon: Activity },
    { id: 'ehr', label: t.ehr, icon: FileText },
    { id: 'telemedicine', label: t.telemedicine, icon: Video },
    { id: 'prescriptions', label: t.prescriptions, icon: FileText },
    { id: 'wearables', label: t.wearables, icon: Watch },
    { id: 'insurance', label: t.insurance, icon: DollarSign },
    { id: 'abdm', label: t.abdm, icon: Shield },
  ];

  if (userType === 'doctor') {
    tabs.push({ id: 'analytics', label: t.analytics, icon: PieChart });
  }

  return (
    <div className="bg-white/80 backdrop-blur-xl border-b border-gray-200/50 sticky top-[73px] z-40">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex gap-2 overflow-x-auto py-3 scrollbar-hide">
          {tabs.map((tab) => (
            <motion.button
              key={tab.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onTabChange(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              <span>{tab.label}</span>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
