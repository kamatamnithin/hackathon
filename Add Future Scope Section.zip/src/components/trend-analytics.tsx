import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Users, MapPin } from 'lucide-react';

interface TrendAnalyticsProps {
  language: 'en' | 'hi' | 'te';
}

export function TrendAnalytics({ language }: TrendAnalyticsProps) {
  const monthlyData = [
    { month: 'May', diabetes: 45, heart: 32, cancer: 8 },
    { month: 'Jun', diabetes: 52, heart: 38, cancer: 10 },
    { month: 'Jul', diabetes: 58, heart: 42, cancer: 12 },
    { month: 'Aug', diabetes: 65, heart: 48, cancer: 15 },
    { month: 'Sep', diabetes: 72, heart: 55, cancer: 18 },
    { month: 'Oct', diabetes: 78, heart: 62, cancer: 20 }
  ];

  const ageDistribution = [
    { age: '18-30', count: 45 },
    { age: '31-45', count: 78 },
    { age: '46-60', count: 125 },
    { age: '61+', count: 92 }
  ];

  const regionalData = [
    { region: 'Urban', value: 156, color: '#3b82f6' },
    { region: 'Semi-Urban', value: 98, color: '#8b5cf6' },
    { region: 'Rural', value: 86, color: '#ec4899' }
  ];

  const lifestyleCorrelation = [
    { lifestyle: 'Sedentary', risk: 85 },
    { lifestyle: 'Light Activity', risk: 62 },
    { lifestyle: 'Moderate Activity', risk: 38 },
    { lifestyle: 'Active', risk: 22 }
  ];

  const translations = {
    en: {
      title: 'Disease Trend Analytics',
      monthly: 'Monthly Disease Detection Trends',
      age: 'Age-wise Risk Distribution',
      regional: 'Regional Patient Distribution',
      lifestyle: 'Lifestyle vs Disease Risk Correlation',
      insights: 'Key Insights',
      diabetes: 'Diabetes',
      heart: 'Heart Disease',
      cancer: 'Cancer',
      patients: 'Patients'
    },
    hi: {
      title: 'रोग प्रवृत्ति विश्लेषण',
      monthly: 'मासिक रोग पहचान प्रवृत्ति',
      age: 'आयु-वार जोखिम वितरण',
      regional: 'क्षेत्रीय रोगी वितरण',
      lifestyle: 'जीवनशैली बनाम रोग जोखिम संबंध',
      insights: 'मुख्य अंतर्दृष्टि',
      diabetes: 'मधुमेह',
      heart: 'हृदय रोग',
      cancer: 'कैंसर',
      patients: 'मरीज'
    },
    te: {
      title: 'వ్యాధి ట్రెండ్ విశ్లేషణ',
      monthly: 'నెలవారీ వ్యాధి గుర్తింపు ధోరణులు',
      age: 'వయస్సు వారీగా ప్రమాద పంపిణీ',
      regional: 'ప్రాంతీయ రోగుల పంపిణీ',
      lifestyle: 'జీవనశైలి vs వ్యాధి ప్రమాద సహసంబంధం',
      insights: 'ముఖ్య అంతర్దృష్టులు',
      diabetes: 'మధుమేహం',
      heart: 'గుండె వ్యాధి',
      cancer: 'క్యాన్సర్',
      patients: 'రోగులు'
    }
  };

  const t = translations[language];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <TrendingUp className="w-8 h-8 text-blue-600" />
        <h2 className="text-gray-900">{t.title}</h2>
      </div>

      {/* Key Insights Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
          <TrendingUp className="w-8 h-8 mb-3 opacity-80" />
          <div className="text-3xl mb-1">23% ↑</div>
          <p className="text-blue-100">Diabetes cases increase this quarter</p>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white">
          <Users className="w-8 h-8 mb-3 opacity-80" />
          <div className="text-3xl mb-1">46-60</div>
          <p className="text-purple-100">Highest risk age group</p>
        </div>

        <div className="bg-gradient-to-br from-pink-500 to-pink-600 rounded-xl p-6 text-white">
          <MapPin className="w-8 h-8 mb-3 opacity-80" />
          <div className="text-3xl mb-1">Urban</div>
          <p className="text-pink-100">Highest patient concentration</p>
        </div>
      </div>

      {/* Monthly Trends */}
      <div className="bg-white border border-gray-200 rounded-xl p-6">
        <h3 className="text-gray-900 mb-4">{t.monthly}</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line type="monotone" dataKey="diabetes" stroke="#f59e0b" strokeWidth={2} name={t.diabetes} />
              <Line type="monotone" dataKey="heart" stroke="#ef4444" strokeWidth={2} name={t.heart} />
              <Line type="monotone" dataKey="cancer" stroke="#8b5cf6" strokeWidth={2} name={t.cancer} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Age Distribution */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <h3 className="text-gray-900 mb-4">{t.age}</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={ageDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="age" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="count" fill="#3b82f6" radius={[8, 8, 0, 0]} name={t.patients} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Regional Distribution */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <h3 className="text-gray-900 mb-4">{t.regional}</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={regionalData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ region, percent }) => `${region} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {regionalData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Lifestyle Correlation */}
      <div className="bg-white border border-gray-200 rounded-xl p-6">
        <h3 className="text-gray-900 mb-4">{t.lifestyle}</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={lifestyleCorrelation} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis type="number" stroke="#6b7280" />
              <YAxis type="category" dataKey="lifestyle" stroke="#6b7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'white',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="risk" fill="#ef4444" radius={[0, 8, 8, 0]} name="Risk %" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Key Insights */}
      <div className="bg-gradient-to-br from-gray-50 to-gray-100 border border-gray-200 rounded-xl p-6">
        <h3 className="text-gray-900 mb-4">{t.insights}</h3>
        <div className="space-y-3">
          <div className="flex items-start gap-3 bg-white rounded-lg p-4">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
            <div>
              <p className="text-gray-900 mb-1">Increasing Diabetes Trend</p>
              <p className="text-gray-600 text-sm">
                23% increase in diabetes detection over the last quarter, particularly in the 46-60 age group. 
                Preventive intervention programs recommended.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-white rounded-lg p-4">
            <div className="w-2 h-2 bg-purple-600 rounded-full mt-2"></div>
            <div>
              <p className="text-gray-900 mb-1">Lifestyle Impact</p>
              <p className="text-gray-600 text-sm">
                Strong negative correlation between physical activity and disease risk. 
                Active lifestyle shows 74% lower risk compared to sedentary.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3 bg-white rounded-lg p-4">
            <div className="w-2 h-2 bg-pink-600 rounded-full mt-2"></div>
            <div>
              <p className="text-gray-900 mb-1">Regional Healthcare Planning</p>
              <p className="text-gray-600 text-sm">
                Urban areas show highest patient concentration (46%). 
                Government should focus on expanding healthcare infrastructure in semi-urban regions.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
