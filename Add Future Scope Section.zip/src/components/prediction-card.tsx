import { ReactNode } from 'react';
import { motion } from 'motion/react';
import { ConfidenceMeter } from './confidence-meter';
import { ChevronRight, AlertCircle } from 'lucide-react';

interface HealthPrediction {
  disease: string;
  risk: 'Low' | 'Medium' | 'High';
  confidence: number;
  contributingFactors: string[];
  module: string;
}

interface PredictionCardProps {
  prediction: HealthPrediction;
  icon: ReactNode;
  language: 'en' | 'hi' | 'te';
}

export function PredictionCard({ prediction, icon, language }: PredictionCardProps) {
  const getRiskColor = () => {
    switch (prediction.risk) {
      case 'High': return 'from-red-500 to-rose-600';
      case 'Medium': return 'from-orange-500 to-amber-600';
      default: return 'from-green-500 to-emerald-600';
    }
  };

  const getRiskBgColor = () => {
    switch (prediction.risk) {
      case 'High': return 'bg-red-50 border-red-200';
      case 'Medium': return 'bg-orange-50 border-orange-200';
      default: return 'bg-green-50 border-green-200';
    }
  };

  const getRiskTextColor = () => {
    switch (prediction.risk) {
      case 'High': return 'text-red-600';
      case 'Medium': return 'text-orange-600';
      default: return 'text-green-600';
    }
  };

  const translations = {
    en: {
      risk: 'Risk',
      module: 'AI Module',
      factors: 'Key Factors',
      viewMore: 'View Details'
    },
    hi: {
      risk: 'जोखिम',
      module: 'AI मॉड्यूल',
      factors: 'मुख्य कारक',
      viewMore: 'विवरण देखें'
    },
    te: {
      risk: 'ప్రమాదం',
      module: 'AI మాడ్యూల్',
      factors: 'ముఖ్య కారకాలు',
      viewMore: 'వివరాలు చూడండి'
    }
  };

  const t = translations[language];

  return (
    <motion.div
      whileHover={{ y: -8, scale: 1.02 }}
      className="group relative h-full"
    >
      {/* Glow Effect */}
      <div className={`absolute inset-0 bg-gradient-to-br ${getRiskColor()} rounded-2xl opacity-0 group-hover:opacity-20 blur-xl transition-all duration-500`}></div>
      
      {/* Card */}
      <div className={`relative h-full ${getRiskBgColor()} bg-opacity-50 backdrop-blur-sm border-2 rounded-2xl p-6 shadow-lg group-hover:shadow-2xl transition-all duration-300`}>
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <motion.div
            whileHover={{ scale: 1.1, rotate: 10 }}
            className={`p-3 bg-gradient-to-br ${getRiskColor()} rounded-xl shadow-lg`}
          >
            <div className="text-white">
              {icon}
            </div>
          </motion.div>
          <span className={`px-3 py-1 rounded-full text-sm ${getRiskTextColor()} bg-white shadow-sm`}>
            {prediction.risk} {t.risk}
          </span>
        </div>

        {/* Content */}
        <h3 className="text-xl text-gray-900 mb-2">{prediction.disease}</h3>
        <div className="text-gray-600 text-sm mb-4 flex items-center gap-2">
          <span className="w-2 h-2 bg-blue-500 rounded-full block"></span>
          {prediction.module}
        </div>

        {/* Confidence Meter */}
        <div className="mb-4">
          <ConfidenceMeter value={prediction.confidence} />
        </div>

        {/* Contributing Factors */}
        <div className="pt-4 border-t border-gray-200">
          <div className="text-gray-700 text-sm mb-3 flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            {t.factors}:
          </div>
          <ul className="space-y-2">
            {prediction.contributingFactors.slice(0, 2).map((factor, idx) => (
              <motion.li
                key={idx}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="text-gray-600 text-sm flex items-start gap-2"
              >
                <span className={`w-1.5 h-1.5 rounded-full mt-1.5 block ${
                  prediction.risk === 'High' ? 'bg-red-500' :
                  prediction.risk === 'Medium' ? 'bg-orange-500' : 'bg-green-500'
                }`}></span>
                {factor}
              </motion.li>
            ))}
          </ul>
        </div>

        {/* View Details Button */}
        <motion.button
          whileHover={{ x: 5 }}
          className="mt-4 w-full flex items-center justify-center gap-2 py-3 text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-xl transition-all group"
        >
          {t.viewMore}
          <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </motion.button>
      </div>
    </motion.div>
  );
}
