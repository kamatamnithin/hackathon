import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Watch, Heart, Activity, Zap, Droplet, Moon, 
  TrendingUp, TrendingDown, AlertTriangle, Check,
  Wifi, Battery, Settings, Clock, ArrowRight
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface WearableDevice {
  id: string;
  name: string;
  type: 'smartwatch' | 'fitness_band' | 'bp_monitor' | 'glucose_meter';
  brand: string;
  batteryLevel: number;
  lastSync: string;
  isConnected: boolean;
}

interface HealthMetric {
  type: 'heart_rate' | 'blood_pressure' | 'blood_oxygen' | 'steps' | 'sleep' | 'calories';
  current: number;
  unit: string;
  status: 'normal' | 'warning' | 'critical';
  trend: 'up' | 'down' | 'stable';
  icon: any;
  color: string;
}

interface IoTWearablesProps {
  language: 'en' | 'hi' | 'te';
}

export function IoTWearables({ language }: IoTWearablesProps) {
  const [realTimeData, setRealTimeData] = useState({
    heartRate: 72,
    bloodOxygen: 98,
    steps: 8542,
    calories: 420
  });

  const [devices] = useState<WearableDevice[]>([
    {
      id: '1',
      name: 'Apple Watch Series 9',
      type: 'smartwatch',
      brand: 'Apple',
      batteryLevel: 78,
      lastSync: 'Just now',
      isConnected: true
    },
    {
      id: '2',
      name: 'BP Monitor Pro',
      type: 'bp_monitor',
      brand: 'Omron',
      batteryLevel: 45,
      lastSync: '2 hours ago',
      isConnected: true
    },
    {
      id: '3',
      name: 'Glucose Tracker',
      type: 'glucose_meter',
      brand: 'Accu-Chek',
      batteryLevel: 92,
      lastSync: '30 min ago',
      isConnected: true
    }
  ]);

  const heartRateData = [
    { time: '00:00', value: 65 },
    { time: '04:00', value: 58 },
    { time: '08:00', value: 72 },
    { time: '12:00', value: 82 },
    { time: '16:00', value: 75 },
    { time: '20:00', value: 68 },
    { time: 'Now', value: 72 }
  ];

  const stepsData = [
    { day: 'Mon', steps: 8234 },
    { day: 'Tue', steps: 9456 },
    { day: 'Wed', steps: 7821 },
    { day: 'Thu', steps: 10234 },
    { day: 'Fri', steps: 8542 },
    { day: 'Sat', steps: 6789 },
    { day: 'Sun', steps: 7123 }
  ];

  const translations = {
    en: {
      title: 'IoT Wearable Devices',
      subtitle: 'Real-time health monitoring',
      connectedDevices: 'Connected Devices',
      liveMetrics: 'Live Health Metrics',
      heartRate: 'Heart Rate',
      bloodPressure: 'Blood Pressure',
      bloodOxygen: 'Blood Oxygen',
      steps: 'Steps Today',
      sleep: 'Sleep Quality',
      calories: 'Calories Burned',
      bpm: 'BPM',
      syncNow: 'Sync Now',
      viewDetails: 'View Details',
      normal: 'Normal',
      warning: 'Warning',
      critical: 'Critical',
      connected: 'Connected',
      disconnected: 'Disconnected',
      battery: 'Battery',
      lastSync: 'Last Sync',
      weeklyTrend: 'Weekly Trend',
      dailyHeartRate: 'Today\'s Heart Rate',
      aiInsights: 'AI Insights',
      anomalyDetected: 'Anomaly Detected',
      allNormal: 'All metrics within normal range'
    },
    hi: {
      title: 'IoT पहनने योग्य उपकरण',
      subtitle: 'रीयल-टाइम स्वास्थ्य निगरानी',
      connectedDevices: 'कनेक्टेड डिवाइस',
      liveMetrics: 'लाइव स्वास्थ्य मेट्रिक्स',
      heartRate: 'हृदय गति',
      bloodPressure: 'रक्तचाप',
      bloodOxygen: 'रक्त ऑक्सीजन',
      steps: 'आज के कदम',
      sleep: 'नींद की गुणवत्ता',
      calories: 'कैलोरी बर्न',
      bpm: 'BPM',
      syncNow: 'अभी सिंक करें',
      viewDetails: 'विवरण देखें',
      normal: 'सामान्य',
      warning: 'चेतावनी',
      critical: 'गंभीर',
      connected: 'कनेक्टेड',
      disconnected: 'डिस्कनेक्टेड',
      battery: 'बैटरी',
      lastSync: 'अंतिम सिंक',
      weeklyTrend: 'साप्ताहिक ट्रेंड',
      dailyHeartRate: 'आज की हृदय गति',
      aiInsights: 'AI अंतर्दृष्टि',
      anomalyDetected: 'विसंगति का पता चला',
      allNormal: 'सभी मेट्रिक्स सामान्य सीमा में'
    },
    te: {
      title: 'IoT వేర్‌బుల్ పరికరాలు',
      subtitle: 'రియల్-టైమ్ హెల్త్ మానిటరింగ్',
      connectedDevices: 'కనెక్ట్ చేసిన పరికరాలు',
      liveMetrics: 'లైవ్ హెల్త్ మెట్రిక్స్',
      heartRate: 'హృదయ స్పందన రేటు',
      bloodPressure: 'రక్తపోటు',
      bloodOxygen: 'రక్త ఆక్సిజన్',
      steps: 'నేటి స్టెప్స్',
      sleep: 'నిద్ర నాణ్యత',
      calories: 'కాలరీలు బర్న్ చేయబడ్డాయి',
      bpm: 'BPM',
      syncNow: 'ఇప్పుడు సింక్ చేయండి',
      viewDetails: 'వివరాలు చూడండి',
      normal: 'సాధారణం',
      warning: 'హెచ్చరిక',
      critical: 'క్లిష్టమైనది',
      connected: 'కనెక్ట్ చేయబడింది',
      disconnected: 'డిస్‌కనెక్ట్ చేయబడింది',
      battery: 'బ్యాటరీ',
      lastSync: 'చివరి సింక్',
      weeklyTrend: 'వారం ట్రెండ్',
      dailyHeartRate: 'నేటి హృదయ స్పందన రేటు',
      aiInsights: 'AI అంతర్దృష్టులు',
      anomalyDetected: 'అసాధారణత గుర్తించబడింది',
      allNormal: 'అన్ని మెట్రిక్స్ సాధారణ పరిధిలో'
    }
  };

  const t = translations[language];

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeData(prev => ({
        heartRate: prev.heartRate + Math.floor(Math.random() * 6) - 3,
        bloodOxygen: Math.max(95, Math.min(100, prev.bloodOxygen + (Math.random() > 0.5 ? 1 : -1))),
        steps: prev.steps + Math.floor(Math.random() * 50),
        calories: prev.calories + Math.floor(Math.random() * 10)
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const metrics: HealthMetric[] = [
    {
      type: 'heart_rate',
      current: realTimeData.heartRate,
      unit: t.bpm,
      status: realTimeData.heartRate > 100 ? 'warning' : 'normal',
      trend: 'stable',
      icon: Heart,
      color: 'from-red-500 to-pink-500'
    },
    {
      type: 'blood_oxygen',
      current: realTimeData.bloodOxygen,
      unit: '%',
      status: realTimeData.bloodOxygen < 95 ? 'warning' : 'normal',
      trend: 'up',
      icon: Droplet,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      type: 'steps',
      current: realTimeData.steps,
      unit: 'steps',
      status: 'normal',
      trend: 'up',
      icon: Activity,
      color: 'from-green-500 to-emerald-500'
    },
    {
      type: 'calories',
      current: realTimeData.calories,
      unit: 'kcal',
      status: 'normal',
      trend: 'up',
      icon: Zap,
      color: 'from-orange-500 to-amber-500'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'border-green-200 bg-green-50';
      case 'warning': return 'border-yellow-200 bg-yellow-50';
      case 'critical': return 'border-red-200 bg-red-50';
      default: return 'border-gray-200 bg-gray-50';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-600" />;
      default: return <ArrowRight className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
            <Watch className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl text-gray-900">{t.title}</h2>
            <p className="text-gray-600 text-sm">{t.subtitle}</p>
          </div>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl hover:shadow-lg transition-all"
        >
          <Wifi className="w-5 h-5" />
          {t.syncNow}
        </motion.button>
      </div>

      {/* Connected Devices */}
      <div className="bg-white border border-gray-200 rounded-xl p-6">
        <h3 className="text-lg text-gray-900 mb-4">{t.connectedDevices}</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {devices.map((device, idx) => (
            <motion.div
              key={device.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="bg-gradient-to-br from-gray-50 to-blue-50 border border-gray-200 rounded-xl p-4"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="text-gray-900 mb-1">{device.name}</h4>
                  <p className="text-sm text-gray-600">{device.brand}</p>
                </div>
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${
                  device.isConnected ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                }`}>
                  <div className={`w-2 h-2 rounded-full ${device.isConnected ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></div>
                  {device.isConnected ? t.connected : t.disconnected}
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1 text-gray-600">
                    <Battery className="w-4 h-4" />
                    {t.battery}
                  </div>
                  <span className="text-gray-900">{device.batteryLevel}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      device.batteryLevel > 50 ? 'bg-green-500' :
                      device.batteryLevel > 20 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${device.batteryLevel}%` }}
                  ></div>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-600">
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {device.lastSync}
                  </div>
                  <button className="text-blue-600 hover:text-blue-700">
                    <Settings className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Live Metrics */}
      <div>
        <h3 className="text-lg text-gray-900 mb-4">{t.liveMetrics}</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {metrics.map((metric, idx) => (
            <motion.div
              key={metric.type}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
              whileHover={{ scale: 1.05, y: -5 }}
              className={`border-2 rounded-xl p-4 ${getStatusColor(metric.status)}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${metric.color} flex items-center justify-center shadow-lg`}>
                  <metric.icon className="w-6 h-6 text-white" />
                </div>
                {getTrendIcon(metric.trend)}
              </div>
              <p className="text-sm text-gray-600 mb-1">
                {metric.type === 'heart_rate' ? t.heartRate :
                 metric.type === 'blood_oxygen' ? t.bloodOxygen :
                 metric.type === 'steps' ? t.steps : t.calories}
              </p>
              <div className="flex items-baseline gap-2">
                <motion.span
                  key={metric.current}
                  initial={{ scale: 1.2, color: '#3B82F6' }}
                  animate={{ scale: 1, color: '#111827' }}
                  className="text-3xl text-gray-900"
                >
                  {metric.current}
                </motion.span>
                <span className="text-gray-600">{metric.unit}</span>
              </div>
              {metric.status !== 'normal' && (
                <div className="mt-2 flex items-center gap-1 text-xs text-yellow-700">
                  <AlertTriangle className="w-3 h-3" />
                  {t.warning}
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Heart Rate Chart */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <h4 className="text-gray-900 mb-4">{t.dailyHeartRate}</h4>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={heartRateData}>
              <defs>
                <linearGradient id="heartGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#EF4444" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#EF4444" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="time" stroke="#9CA3AF" style={{ fontSize: '12px' }} />
              <YAxis stroke="#9CA3AF" style={{ fontSize: '12px' }} />
              <Tooltip />
              <Area type="monotone" dataKey="value" stroke="#EF4444" fillOpacity={1} fill="url(#heartGradient)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Steps Chart */}
        <div className="bg-white border border-gray-200 rounded-xl p-6">
          <h4 className="text-gray-900 mb-4">{t.weeklyTrend}</h4>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={stepsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="day" stroke="#9CA3AF" style={{ fontSize: '12px' }} />
              <YAxis stroke="#9CA3AF" style={{ fontSize: '12px' }} />
              <Tooltip />
              <Line type="monotone" dataKey="steps" stroke="#10B981" strokeWidth={3} dot={{ fill: '#10B981', r: 5 }} activeDot={{ r: 7 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Insights */}
      <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-xl p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="text-lg text-gray-900 mb-2">{t.aiInsights}</h4>
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <p className="text-gray-700">{t.allNormal}</p>
              </div>
              <div className="flex items-start gap-2">
                <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <p className="text-gray-700">Heart rate variability is excellent, indicating good cardiovascular health</p>
              </div>
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                <p className="text-gray-700">Consider increasing daily steps to reach 10,000 steps goal</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
