import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  AlertCircle, Phone, MapPin, User, Clock, 
  Heart, Activity, X, Check, Navigation
} from 'lucide-react';

interface EmergencySOSProps {
  language: 'en' | 'hi' | 'te';
  onClose: () => void;
}

export function EmergencySOSButton({ language, onClick }: { language: 'en' | 'hi' | 'te', onClick: () => void }) {
  const [isPressed, setIsPressed] = useState(false);
  const [countdown, setCountdown] = useState(0);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPressed && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
    } else if (countdown === 0 && isPressed) {
      onClick();
      setIsPressed(false);
    }
    return () => clearTimeout(timer);
  }, [isPressed, countdown, onClick]);

  const handlePress = () => {
    setIsPressed(true);
    setCountdown(3);
  };

  const handleRelease = () => {
    setIsPressed(false);
    setCountdown(0);
  };

  return (
    <motion.button
      onMouseDown={handlePress}
      onMouseUp={handleRelease}
      onTouchStart={handlePress}
      onTouchEnd={handleRelease}
      whileHover={{ scale: 1.05 }}
      animate={{
        scale: isPressed ? [1, 1.1, 1] : 1,
        boxShadow: isPressed 
          ? ['0 0 0 0 rgba(239, 68, 68, 0.7)', '0 0 0 20px rgba(239, 68, 68, 0)', '0 0 0 0 rgba(239, 68, 68, 0)']
          : '0 10px 30px rgba(239, 68, 68, 0.5)'
      }}
      transition={{
        duration: 0.8,
        repeat: isPressed ? Infinity : 0
      }}
      className="fixed bottom-6 right-6 z-50 w-20 h-20 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center shadow-2xl cursor-pointer"
    >
      <AlertCircle className="w-10 h-10 text-white" />
      {isPressed && countdown > 0 && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute inset-0 flex items-center justify-center bg-red-600 rounded-full"
        >
          <span className="text-3xl text-white">{countdown}</span>
        </motion.div>
      )}
    </motion.button>
  );
}

export function EmergencySOSModal({ language, onClose }: EmergencySOSProps) {
  const [emergencyContacted, setEmergencyContacted] = useState(false);
  const [locationShared, setLocationShared] = useState(false);
  const [responseTime, setResponseTime] = useState(300); // 5 minutes in seconds

  const translations = {
    en: {
      title: 'Emergency SOS Activated',
      calling: 'Calling Emergency Services...',
      contacted: 'Emergency Services Contacted',
      eta: 'Estimated Arrival',
      minutes: 'minutes',
      yourLocation: 'Your Location',
      locationShared: 'Location shared with emergency services',
      vitals: 'Live Vitals Monitoring',
      heartRate: 'Heart Rate',
      bloodPressure: 'Blood Pressure',
      oxygenLevel: 'Oxygen Level',
      emergencyContact: 'Emergency Contact',
      notified: 'Family members notified',
      cancel: 'Cancel SOS',
      nearbyHospitals: 'Nearby Hospitals',
      ambulanceDispatched: 'Ambulance Dispatched'
    },
    hi: {
      title: 'आपातकालीन SOS सक्रिय',
      calling: 'आपातकालीन सेवाओं को कॉल कर रहे हैं...',
      contacted: 'आपातकालीन सेवाओं से संपर्क किया गया',
      eta: 'अनुमानित आगमन',
      minutes: 'मिनट',
      yourLocation: 'आपका स्थान',
      locationShared: 'आपातकालीन सेवाओं के साथ स्थान साझा किया गया',
      vitals: 'लाइव वाइटल मॉनिटरिंग',
      heartRate: 'हृदय गति',
      bloodPressure: 'रक्तचाप',
      oxygenLevel: 'ऑक्सीजन स्तर',
      emergencyContact: 'आपातकालीन संपर्क',
      notified: 'परिवार के सदस्यों को सूचित किया गया',
      cancel: 'SOS रद्द करें',
      nearbyHospitals: 'निकटतम अस्पताल',
      ambulanceDispatched: 'एम्बुलेंस भेजी गई'
    },
    te: {
      title: 'ఎమర్జెన్సీ SOS యాక్టివేట్ చేయబడింది',
      calling: 'ఎమర్జెన్సీ సర్వీసులకు కాల్ చేస్తున్నాం...',
      contacted: 'ఎమర్జెన్సీ సర్వీసులు సంప్రదించారు',
      eta: 'అంచనా రాక సమయం',
      minutes: 'నిమిషాలు',
      yourLocation: 'మీ లొకేషన్',
      locationShared: 'ఎమర్జెన్సీ సర్వీసులతో లొకేషన్ షేర్ చేయబడింది',
      vitals: 'లైవ్ వైటల్స్ మానిటరింగ్',
      heartRate: 'హృదయ స్పందన రేటు',
      bloodPressure: 'రక్తపోటు',
      oxygenLevel: 'ఆక్సిజన్ స్థాయి',
      emergencyContact: 'ఎమర్జెన్సీ కాంటాక్ట్',
      notified: 'కుటుంబ సభ్యులకు తెలియజేయబడింది',
      cancel: 'SOS రద్దు చేయండి',
      nearbyHospitals: 'సమీప ఆసుపత్రులు',
      ambulanceDispatched: 'అంబులెన్స్ పంపబడింది'
    }
  };

  const t = translations[language];

  useEffect(() => {
    // Simulate emergency services being contacted
    const timer = setTimeout(() => {
      setEmergencyContacted(true);
      setLocationShared(true);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setResponseTime(prev => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const nearbyHospitals = [
    { name: 'Apollo Hospital', distance: '2.3 km', time: '5 min' },
    { name: 'Max Healthcare', distance: '3.1 km', time: '7 min' },
    { name: 'Fortis Hospital', distance: '4.5 km', time: '10 min' }
  ];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-6"
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="w-full max-w-4xl bg-white rounded-3xl overflow-hidden shadow-2xl"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-red-500 to-red-600 p-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 1 }}
                  className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center"
                >
                  <AlertCircle className="w-7 h-7" />
                </motion.div>
                <div>
                  <h2 className="text-2xl">{t.title}</h2>
                  {!emergencyContacted ? (
                    <p className="text-red-100">{t.calling}</p>
                  ) : (
                    <div className="flex items-center gap-2 text-red-100">
                      <Check className="w-5 h-5" />
                      {t.contacted}
                    </div>
                  )}
                </div>
              </div>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={onClose}
                className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
              >
                <X className="w-6 h-6" />
              </motion.button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left Column */}
              <div className="space-y-6">
                {/* Ambulance Status */}
                {emergencyContacted && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-green-50 border-2 border-green-500 rounded-xl p-6"
                  >
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                        <Check className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <h3 className="text-lg text-gray-900">{t.ambulanceDispatched}</h3>
                        <p className="text-green-600 text-sm">{t.eta}: {formatTime(responseTime)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Navigation className="w-4 h-4" />
                      <span>Unit #AM-2301 en route</span>
                    </div>
                  </motion.div>
                )}

                {/* Location */}
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                      <MapPin className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-gray-900">{t.yourLocation}</h3>
                      {locationShared && (
                        <div className="flex items-center gap-1 text-sm text-green-600">
                          <Check className="w-4 h-4" />
                          {t.locationShared}
                        </div>
                      )}
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">
                    123 Medical Plaza, Sector 42, Gurgaon, Haryana 122001
                  </p>
                </div>

                {/* Live Vitals */}
                <div className="bg-purple-50 border border-purple-200 rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center">
                      <Activity className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-gray-900">{t.vitals}</h3>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">{t.heartRate}</span>
                      <div className="flex items-center gap-2">
                        <motion.div
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ repeat: Infinity, duration: 1 }}
                        >
                          <Heart className="w-5 h-5 text-red-500" />
                        </motion.div>
                        <span className="text-gray-900">128 BPM</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">{t.bloodPressure}</span>
                      <span className="text-gray-900">142/90 mmHg</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">{t.oxygenLevel}</span>
                      <span className="text-gray-900">94%</span>
                    </div>
                  </div>
                </div>

                {/* Emergency Contact */}
                <div className="bg-orange-50 border border-orange-200 rounded-xl p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-gray-900">{t.emergencyContact}</h3>
                      <div className="flex items-center gap-1 text-sm text-green-600">
                        <Check className="w-4 h-4" />
                        {t.notified}
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Spouse: Mary Doe</span>
                      <Phone className="w-4 h-4 text-gray-400" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Son: James Doe</span>
                      <Phone className="w-4 h-4 text-gray-400" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-6">
                {/* Nearby Hospitals */}
                <div>
                  <h3 className="text-gray-900 mb-4">{t.nearbyHospitals}</h3>
                  <div className="space-y-3">
                    {nearbyHospitals.map((hospital, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        whileHover={{ scale: 1.02 }}
                        className="bg-white border border-gray-200 rounded-xl p-4 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="text-gray-900 mb-1">{hospital.name}</h4>
                            <div className="flex items-center gap-3 text-sm text-gray-600">
                              <div className="flex items-center gap-1">
                                <MapPin className="w-4 h-4" />
                                {hospital.distance}
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="w-4 h-4" />
                                {hospital.time}
                              </div>
                            </div>
                          </div>
                          <Navigation className="w-5 h-5 text-blue-500" />
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>

                {/* Medical History Quick View */}
                <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
                  <h3 className="text-gray-900 mb-4">Medical History Shared</h3>
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-500" />
                      Current medications sent
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-500" />
                      Allergies information sent
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-500" />
                      Recent lab reports sent
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-500" />
                      AI health predictions sent
                    </div>
                  </div>
                </div>

                {/* Cancel Button */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={onClose}
                  className="w-full py-4 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded-xl transition-colors"
                >
                  {t.cancel}
                </motion.button>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
