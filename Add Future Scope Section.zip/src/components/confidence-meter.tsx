interface ConfidenceMeterProps {
  value: number;
  color?: string;
  showLabel?: boolean;
}

export function ConfidenceMeter({ value, color = 'blue', showLabel = true }: ConfidenceMeterProps) {
  const getColorClasses = () => {
    if (color === 'white') {
      return {
        bg: 'bg-white/30',
        fill: 'bg-white',
        text: 'text-white'
      };
    }
    
    if (value >= 70) {
      return {
        bg: 'bg-red-100',
        fill: 'bg-red-500',
        text: 'text-red-600'
      };
    } else if (value >= 40) {
      return {
        bg: 'bg-orange-100',
        fill: 'bg-orange-500',
        text: 'text-orange-600'
      };
    } else {
      return {
        bg: 'bg-green-100',
        fill: 'bg-green-500',
        text: 'text-green-600'
      };
    }
  };

  const colors = getColorClasses();

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        {showLabel && (
          <span className={`text-sm ${colors.text}`}>Confidence Level</span>
        )}
        <span className={`text-sm ${colors.text}`}>{value}%</span>
      </div>
      <div className={`h-2 ${colors.bg} rounded-full overflow-hidden`}>
        <div
          className={`h-full ${colors.fill} transition-all duration-500 ease-out rounded-full`}
          style={{ width: `${value}%` }}
        ></div>
      </div>
    </div>
  );
}
