import { useState } from 'react';
import { Users, TrendingUp, AlertCircle, CheckCircle, Search, Filter } from 'lucide-react';
import { ExplainabilityChart } from './explainability-chart';
import { TrendAnalytics } from './trend-analytics';

interface Patient {
  id: string;
  name: string;
  age: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  lastVisit: string;
  alerts: number;
  diseases: string[];
}

interface DoctorDashboardProps {
  language: 'en' | 'hi' | 'te';
}

export function DoctorDashboard({ language }: DoctorDashboardProps) {
  const [selectedPatient, setSelectedPatient] = useState<string | null>(null);
  const [showAnalytics, setShowAnalytics] = useState(false);

  const patients: Patient[] = [
    {
      id: '1',
      name: 'Rajesh Kumar',
      age: 54,
      riskLevel: 'Critical',
      lastVisit: '2025-10-29',
      alerts: 3,
      diseases: ['Diabetes', 'Heart Disease']
    },
    {
      id: '2',
      name: 'Priya Sharma',
      age: 42,
      riskLevel: 'High',
      lastVisit: '2025-10-28',
      alerts: 2,
      diseases: ['Diabetes']
    },
    {
      id: '3',
      name: 'Amit Patel',
      age: 35,
      riskLevel: 'Medium',
      lastVisit: '2025-10-25',
      alerts: 1,
      diseases: ['Heart Disease']
    },
    {
      id: '4',
      name: 'Sunita Reddy',
      age: 28,
      riskLevel: 'Low',
      lastVisit: '2025-10-20',
      alerts: 0,
      diseases: []
    }
  ];

  const translations = {
    en: {
      title: 'Doctor Dashboard',
      patients: 'Total Patients',
      highRisk: 'High Risk Cases',
      alerts: 'Active Alerts',
      success: 'Success Rate',
      patientList: 'Patient List',
      search: 'Search patients...',
      viewExplainability: 'View AI Explainability',
      viewAnalytics: 'Disease Trend Analytics',
      lastVisit: 'Last Visit',
      riskLevel: 'Risk Level',
      actions: 'Actions'
    },
    hi: {
      title: 'डॉक्टर डैशबोर्ड',
      patients: 'कुल मरीज',
      highRisk: 'उच्च जोखिम मामले',
      alerts: 'सक्रिय चेतावनियां',
      success: 'सफलता दर',
      patientList: 'मरीजों की सूची',
      search: 'मरीज खोजें...',
      viewExplainability: 'AI स्पष्टीकरण देखें',
      viewAnalytics: 'रोग प्रवृत्ति विश्लेषण',
      lastVisit: 'अंतिम यात्रा',
      riskLevel: 'जोखिम स्तर',
      actions: 'कार्रवाई'
    },
    te: {
      title: 'డాక్టర్ డాష్‌బోర్డ్',
      patients: 'మొత్తం రోగులు',
      highRisk: 'అధిక ప్రమాద కేసులు',
      alerts: 'క్రియాశీల హెచ్చరికలు',
      success: 'విజయ రేటు',
      patientList: 'రోగుల జాబితా',
      search: 'రోగులను వెతకండి...',
      viewExplainability: 'AI వివరణను చూడండి',
      viewAnalytics: 'వ్యాధి ట్రెండ్ విశ్లేషణ',
      lastVisit: 'చివరి సందర్శన',
      riskLevel: 'ప్రమాద స్థాయి',
      actions: 'చర్యలు'
    }
  };

  const t = translations[language];

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'Critical': return 'text-red-600 bg-red-50';
      case 'High': return 'text-orange-600 bg-orange-50';
      case 'Medium': return 'text-yellow-600 bg-yellow-50';
      default: return 'text-green-600 bg-green-50';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-gray-900">{t.title}</h1>
        <button
          onClick={() => setShowAnalytics(!showAnalytics)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          {t.viewAnalytics}
        </button>
      </div>

      {showAnalytics ? (
        <div className="space-y-6">
          <button
            onClick={() => setShowAnalytics(false)}
            className="text-blue-600 hover:text-blue-700"
          >
            ← Back to Patients
          </button>
          <TrendAnalytics language={language} />
        </div>
      ) : (
        <>
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white border border-gray-200 rounded-xl p-6">
              <div className="flex items-center justify-between mb-2">
                <Users className="w-8 h-8 text-blue-600" />
                <span className="text-3xl text-gray-900">156</span>
              </div>
              <p className="text-gray-600">{t.patients}</p>
            </div>

            <div className="bg-white border border-gray-200 rounded-xl p-6">
              <div className="flex items-center justify-between mb-2">
                <AlertCircle className="w-8 h-8 text-red-600" />
                <span className="text-3xl text-gray-900">12</span>
              </div>
              <p className="text-gray-600">{t.highRisk}</p>
            </div>

            <div className="bg-white border border-gray-200 rounded-xl p-6">
              <div className="flex items-center justify-between mb-2">
                <TrendingUp className="w-8 h-8 text-orange-600" />
                <span className="text-3xl text-gray-900">6</span>
              </div>
              <p className="text-gray-600">{t.alerts}</p>
            </div>

            <div className="bg-white border border-gray-200 rounded-xl p-6">
              <div className="flex items-center justify-between mb-2">
                <CheckCircle className="w-8 h-8 text-green-600" />
                <span className="text-3xl text-gray-900">94%</span>
              </div>
              <p className="text-gray-600">{t.success}</p>
            </div>
          </div>

          {/* Patient List */}
          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-gray-900">{t.patientList}</h2>
                <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                  <Filter className="w-4 h-4" />
                  Filter
                </button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder={t.search}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-3 text-left text-gray-600">Patient Name</th>
                    <th className="px-6 py-3 text-left text-gray-600">Age</th>
                    <th className="px-6 py-3 text-left text-gray-600">{t.riskLevel}</th>
                    <th className="px-6 py-3 text-left text-gray-600">Diseases</th>
                    <th className="px-6 py-3 text-left text-gray-600">{t.alerts}</th>
                    <th className="px-6 py-3 text-left text-gray-600">{t.lastVisit}</th>
                    <th className="px-6 py-3 text-left text-gray-600">{t.actions}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {patients.map((patient) => (
                    <tr key={patient.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 text-gray-900">{patient.name}</td>
                      <td className="px-6 py-4 text-gray-600">{patient.age}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-sm ${getRiskColor(patient.riskLevel)}`}>
                          {patient.riskLevel}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex flex-wrap gap-1">
                          {patient.diseases.length > 0 ? (
                            patient.diseases.map((disease, idx) => (
                              <span key={idx} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                                {disease}
                              </span>
                            ))
                          ) : (
                            <span className="text-gray-400 text-sm">None</span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {patient.alerts > 0 ? (
                          <span className="flex items-center gap-1 text-red-600">
                            <AlertCircle className="w-4 h-4" />
                            {patient.alerts}
                          </span>
                        ) : (
                          <span className="text-gray-400">0</span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-gray-600">{patient.lastVisit}</td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => setSelectedPatient(patient.id)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* AI Explainability Section */}
          {selectedPatient && (
            <div className="bg-white border border-gray-200 rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-gray-900">{t.viewExplainability}</h2>
                <button
                  onClick={() => setSelectedPatient(null)}
                  className="text-gray-600 hover:text-gray-900"
                >
                  ✕
                </button>
              </div>
              <ExplainabilityChart patientId={selectedPatient} />
            </div>
          )}
        </>
      )}
    </div>
  );
}
