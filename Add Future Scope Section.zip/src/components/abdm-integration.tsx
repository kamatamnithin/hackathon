import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Shield, QrCode, CheckCircle, FileText, Users, 
  Link2, AlertCircle, Download, Share2, Lock,
  Hospital, UserCheck, Key, Settings
} from 'lucide-react';

interface ABDMIntegrationProps {
  language: 'en' | 'hi' | 'te';
}

export function ABDMIntegration({ language }: ABDMIntegrationProps) {
  const [healthId, setHealthId] = useState('john.doe@abdm');
  const [isLinked, setIsLinked] = useState(true);
  const [consentRequests, setConsentRequests] = useState([
    {
      id: '1',
      from: 'Apollo Hospital',
      purpose: 'Treatment',
      dataRequested: ['Medical History', 'Lab Reports', 'Prescriptions'],
      validUntil: '2025-11-30',
      status: 'pending'
    },
    {
      id: '2',
      from: 'Dr. Sarah Johnson',
      purpose: 'Consultation',
      dataRequested: ['Recent Reports', 'Current Medications'],
      validUntil: '2025-11-15',
      status: 'approved'
    }
  ]);

  const linkedFacilities = [
    { name: 'Apollo Hospital', type: 'Hospital', since: '2024-05-20' },
    { name: 'Max Healthcare', type: 'Hospital', since: '2023-12-10' },
    { name: 'Fortis Diagnostics', type: 'Lab', since: '2024-08-15' },
    { name: 'Apollo Pharmacy', type: 'Pharmacy', since: '2024-01-05' }
  ];

  const translations = {
    en: {
      title: 'ABDM Integration',
      subtitle: 'Ayushman Bharat Digital Mission',
      healthId: 'ABDM Health ID',
      createHealthId: 'Create Health ID',
      linkedFacilities: 'Linked Healthcare Facilities',
      consentManagement: 'Consent Management',
      pendingRequests: 'Pending Consent Requests',
      approvedConsents: 'Active Consents',
      shareRecords: 'Share Health Records',
      viewQR: 'View QR Code',
      downloadCard: 'Download Health Card',
      securitySettings: 'Security Settings',
      dataRequested: 'Data Requested',
      purpose: 'Purpose',
      validUntil: 'Valid Until',
      approve: 'Approve',
      reject: 'Reject',
      revoke: 'Revoke',
      linked: 'Linked',
      since: 'Since',
      benefits: 'ABDM Benefits',
      benefit1: 'Universal health records access across India',
      benefit2: 'Secure data sharing with healthcare providers',
      benefit3: 'Insurance claim automation',
      benefit4: 'Telemedicine integration',
      verified: 'Verified by ABDM',
      status: 'Status',
      active: 'Active'
    },
    hi: {
      title: 'ABDM एकीकरण',
      subtitle: 'आयुष्मान भारत डिजिटल मिशन',
      healthId: 'ABDM स्वास्थ्य आईडी',
      createHealthId: 'स्वास्थ्य आईडी बनाएं',
      linkedFacilities: 'जुड़ी स्वास्थ्य सुविधाएं',
      consentManagement: 'सहमति प्रबंधन',
      pendingRequests: 'लंबित सहमति अनुरोध',
      approvedConsents: 'सक्रिय सहमति',
      shareRecords: 'स्वास्थ्य रिकॉर्ड साझा करें',
      viewQR: 'QR कोड देखें',
      downloadCard: 'स्वास्थ्य कार्ड डाउनलोड करें',
      securitySettings: 'सुरक्षा सेटिंग्स',
      dataRequested: 'अनुरोधित डेटा',
      purpose: 'उद्देश्य',
      validUntil: 'तक वैध',
      approve: 'स्वीकृत करें',
      reject: 'अस्वीकार करें',
      revoke: 'रद्द करें',
      linked: 'जुड़ा हुआ',
      since: 'से',
      benefits: 'ABDM लाभ',
      benefit1: 'भारत भर में सार्वभौमिक स्वास्थ्य रिकॉर्ड एक्सेस',
      benefit2: 'स्वास्थ्य सेवा प्रदाताओं के साथ सुरक्षित डेटा साझाकरण',
      benefit3: 'बीमा दावा स्वचालन',
      benefit4: 'टेलीमेडिसिन एकीकरण',
      verified: 'ABDM द्वारा सत्यापित',
      status: 'स्थिति',
      active: 'सक्रिय'
    },
    te: {
      title: 'ABDM ఇంటిగ్రేషన్',
      subtitle: 'ఆయుష్మాన్ భారత్ డిజిటల్ మిషన్',
      healthId: 'ABDM హెల్త్ ID',
      createHealthId: 'హెల్త్ ID సృష్టించండి',
      linkedFacilities: 'లింక్ చేయబడిన ఆరోగ్య సౌకర్యాలు',
      consentManagement: 'సమ్మతి నిర్వహణ',
      pendingRequests: 'పెండింగ్ సమ్మతి అభ్యర్థనలు',
      approvedConsents: 'యాక్టివ్ సమ్మతులు',
      shareRecords: 'హెల్త్ రికార్డులు షేర్ చేయండి',
      viewQR: 'QR కోడ్ చూడండి',
      downloadCard: 'హెల్త్ కార్డ్ డౌన్‌లోడ్ చేయండి',
      securitySettings: 'సెక్యూరిటీ సెట్టింగ్‌లు',
      dataRequested: 'అభ్యర్థించిన డేటా',
      purpose: 'ఉద్దేశం',
      validUntil: 'వరకు చెల్లుబాటు',
      approve: 'ఆమోదించు',
      reject: 'తిరస్కరించు',
      revoke: 'రద్దు చేయండి',
      linked: 'లింక్ చేయబడింది',
      since: 'నుండి',
      benefits: 'ABDM ప్రయోజనాలు',
      benefit1: 'భారతదేశం అంతటా సార్వత్రిక ఆరోగ్య రికార్డుల యాక్సెస్',
      benefit2: 'ఆరోగ్య సంరక్షణ ప్రొవైడర్‌లతో సురక్షిత డేటా షేరింగ్',
      benefit3: 'బీమా క్లెయిమ్ ఆటోమేషన్',
      benefit4: 'టెలిమెడిసిన్ ఇంటిగ్రేషన్',
      verified: 'ABDM ద్వారా ధృవీకరించబడింది',
      status: 'స్థితి',
      active: 'యాక్టివ్'
    }
  };

  const t = translations[language];

  const handleConsent = (id: string, action: 'approve' | 'reject') => {
    setConsentRequests(prev =>
      prev.map(req =>
        req.id === id ? { ...req, status: action === 'approve' ? 'approved' : 'rejected' } : req
      )
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl text-gray-900">{t.title}</h2>
            <p className="text-gray-600 text-sm">{t.subtitle}</p>
          </div>
        </div>
      </div>

      {/* Health ID Card */}
      <div className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-600 rounded-2xl p-6 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-yellow-500/30 rounded-full blur-2xl"></div>
        
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-orange-200" />
                <p className="text-orange-100">{t.healthId}</p>
              </div>
              <h3 className="text-3xl mb-2">{healthId}</h3>
              <div className="flex items-center gap-2 text-orange-100">
                <UserCheck className="w-4 h-4" />
                <span className="text-sm">{t.verified}</span>
              </div>
            </div>
            <div className="bg-white p-3 rounded-xl">
              <QrCode className="w-16 h-16 text-gray-900" />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-white/20 backdrop-blur-xl rounded-xl hover:bg-white/30 transition-colors"
            >
              <QrCode className="w-5 h-5" />
              <span className="text-sm">{t.viewQR}</span>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-white/20 backdrop-blur-xl rounded-xl hover:bg-white/30 transition-colors"
            >
              <Download className="w-5 h-5" />
              <span className="text-sm">{t.downloadCard}</span>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-white/20 backdrop-blur-xl rounded-xl hover:bg-white/30 transition-colors"
            >
              <Share2 className="w-5 h-5" />
              <span className="text-sm">{t.shareRecords}</span>
            </motion.button>
          </div>
        </div>
      </div>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Consent Management */}
        <div className="space-y-4">
          <h3 className="text-lg text-gray-900">{t.consentManagement}</h3>
          
          {consentRequests.filter(req => req.status === 'pending').length > 0 && (
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
              <div className="p-4 bg-yellow-50 border-b border-yellow-200">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-yellow-600" />
                  <h4 className="text-gray-900">{t.pendingRequests}</h4>
                </div>
              </div>
              <div className="p-4 space-y-3">
                {consentRequests.filter(req => req.status === 'pending').map((request) => (
                  <motion.div
                    key={request.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-xl p-4"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h5 className="text-gray-900 mb-1">{request.from}</h5>
                        <p className="text-sm text-gray-600">{t.purpose}: {request.purpose}</p>
                      </div>
                      <Lock className="w-5 h-5 text-orange-500" />
                    </div>
                    
                    <div className="mb-3">
                      <p className="text-sm text-gray-600 mb-1">{t.dataRequested}:</p>
                      <div className="flex flex-wrap gap-2">
                        {request.dataRequested.map((data, idx) => (
                          <span key={idx} className="px-2 py-1 bg-white border border-orange-200 rounded-lg text-xs text-gray-900">
                            {data}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                      <span>{t.validUntil}: {request.validUntil}</span>
                    </div>
                    
                    <div className="flex gap-2">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleConsent(request.id, 'approve')}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                      >
                        <CheckCircle className="w-4 h-4" />
                        {t.approve}
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleConsent(request.id, 'reject')}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                      >
                        <AlertCircle className="w-4 h-4" />
                        {t.reject}
                      </motion.button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Approved Consents */}
          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
            <div className="p-4 bg-green-50 border-b border-green-200">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <h4 className="text-gray-900">{t.approvedConsents}</h4>
              </div>
            </div>
            <div className="p-4 space-y-2">
              {consentRequests.filter(req => req.status === 'approved').map((request) => (
                <div
                  key={request.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Hospital className="w-5 h-5 text-green-600" />
                    <div>
                      <p className="text-gray-900 text-sm">{request.from}</p>
                      <p className="text-xs text-gray-600">{request.purpose}</p>
                    </div>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-3 py-1 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    {t.revoke}
                  </motion.button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Linked Facilities & Benefits */}
        <div className="space-y-4">
          {/* Linked Facilities */}
          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center gap-2">
                <Link2 className="w-5 h-5 text-blue-600" />
                <h4 className="text-gray-900">{t.linkedFacilities}</h4>
              </div>
            </div>
            <div className="p-4 space-y-2">
              {linkedFacilities.map((facility, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Hospital className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="text-gray-900 text-sm">{facility.name}</p>
                      <p className="text-xs text-gray-600">{facility.type}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-xs text-green-600 mb-1">
                      <CheckCircle className="w-3 h-3" />
                      {t.linked}
                    </div>
                    <p className="text-xs text-gray-500">{t.since} {facility.since}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* ABDM Benefits */}
          <div className="bg-gradient-to-br from-orange-50 to-red-50 border border-orange-200 rounded-xl p-6">
            <h4 className="text-lg text-gray-900 mb-4">{t.benefits}</h4>
            <div className="space-y-3">
              {[t.benefit1, t.benefit2, t.benefit3, t.benefit4].map((benefit, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex items-start gap-2"
                >
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-gray-700 text-sm">{benefit}</p>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Security Settings */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors"
          >
            <Settings className="w-5 h-5 text-gray-600" />
            <span className="text-gray-900">{t.securitySettings}</span>
          </motion.button>
        </div>
      </div>
    </div>
  );
}
