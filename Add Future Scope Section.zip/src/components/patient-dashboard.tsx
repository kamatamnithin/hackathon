import { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, Activity, Droplet, AlertTriangle, TrendingUp, Calendar, Bell, Sparkles, Clock, FileText } from 'lucide-react';
import { ConfidenceMeter } from './confidence-meter';
import { PredictionCard } from './prediction-card';

interface HealthPrediction {
  disease: string;
  risk: 'Low' | 'Medium' | 'High';
  confidence: number;
  contributingFactors: string[];
  module: string;
}

interface PatientDashboardProps {
  language: 'en' | 'hi' | 'te';
}

export function PatientDashboard({ language }: PatientDashboardProps) {
  const [predictions] = useState<HealthPrediction[]>([
    {
      disease: 'Heart Disease',
      risk: 'Medium',
      confidence: 68,
      contributingFactors: ['High Cholesterol', 'Family History', 'Age Factor'],
      module: 'CardioRisk Predictor'
    },
    {
      disease: 'Diabetes',
      risk: 'High',
      confidence: 82,
      contributingFactors: ['High Blood Sugar', 'BMI > 30', 'Sedentary Lifestyle'],
      module: 'GlucoAnalyzer'
    },
    {
      disease: 'Cancer Risk',
      risk: 'Low',
      confidence: 15,
      contributingFactors: ['No significant markers'],
      module: 'OncoAI'
    }
  ]);

  const translations = {
    en: {
      title: 'Patient Health Dashboard',
      welcome: 'Welcome back',
      comprehensive: 'Comprehensive Health Score',
      predictions: 'AI Health Predictions',
      recent: 'Recent Activity',
      appointments: 'Upcoming Appointments',
      viewDetails: 'View Details',
      checkup: 'Annual Checkup',
      followup: 'Follow-up Consultation',
      healthTip: 'Health Tip of the Day'
    },
    hi: {
      title: 'रोगी स्वास्थ्य डैशबोर्ड',
      welcome: 'वापस स्वागत है',
      comprehensive: 'व्यापक स्वास्थ्य स्कोर',
      predictions: 'एआई स्वास्थ्य भविष्यवाणियां',
      recent: 'हाल की गतिविधि',
      appointments: 'आगामी अपॉइंटमेंट',
      viewDetails: 'विवरण देखें',
      checkup: 'वार्षिक जांच',
      followup: 'फॉलो-अप परामर्श',
      healthTip: 'आज का स्वास्थ्य टिप'
    },
    te: {
      title: 'రోగి ఆరోగ్య డాష్‌బోర్డ్',
      welcome: 'తిరిగి స్వాగతం',
      comprehensive: 'సమగ్ర ఆరోగ్య స్కోర్',
      predictions: 'AI ఆరోగ్య అంచనాలు',
      recent: 'ఇటీవలి కార్యాచరణ',
      appointments: 'రాబోయే అపాయింట్‌మెంట్‌లు',
      viewDetails: 'వివరాలు చూడండి',
      checkup: 'వార్షిక తనిఖీ',
      followup: 'ఫాలో-అప్ సంప్రదింపు',
      healthTip: 'నేటి ఆరోగ్య చిట్కా'
    }
  };

  const t = translations[language];

  const overallRisk = Math.round(
    predictions.reduce((acc, pred) => acc + pred.confidence, 0) / predictions.length
  );

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-gray-900 mb-1">{t.title}</h1>
          <p className="text-gray-600">{t.welcome}, John Doe 👋</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="relative p-3 hover:bg-gray-100 rounded-xl transition-colors group"
        >
          <Bell className="w-6 h-6 text-gray-600 group-hover:text-blue-600 transition-colors" />
          <motion.span
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full shadow-lg"
          ></motion.span>
        </motion.button>
      </motion.div>

      {/* Comprehensive Health Score - Hero Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.1 }}
        whileHover={{ scale: 1.02 }}
        className="relative group"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-3xl blur-2xl group-hover:blur-3xl transition-all"></div>
        <div className="relative bg-gradient-to-br from-blue-500 via-blue-600 to-purple-600 rounded-3xl p-8 text-white shadow-2xl overflow-hidden">
          {/* Decorative Elements */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-purple-500/30 rounded-full blur-2xl"></div>
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-5 h-5 text-blue-200" />
                  <p className="text-blue-100">{t.comprehensive}</p>
                </div>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.3, type: 'spring' }}
                  className="text-7xl mb-2"
                >
                  {overallRisk}
                  <span className="text-4xl text-blue-200">%</span>
                </motion.div>
                <p className="text-blue-100">Ensemble Model Analysis</p>
              </div>
              <motion.div
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
                className="bg-white/20 backdrop-blur-xl p-4 rounded-2xl shadow-xl"
              >
                <TrendingUp className="w-8 h-8" />
              </motion.div>
            </div>
            <ConfidenceMeter value={overallRisk} color="white" />
          </div>
        </div>
      </motion.div>

      {/* AI Predictions Grid */}
      <div>
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="flex items-center gap-3 mb-4"
        >
          <div className="w-1 h-8 bg-gradient-to-b from-blue-500 to-purple-600 rounded-full"></div>
          <h2 className="text-gray-900">{t.predictions}</h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {predictions.map((prediction, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
            >
              <PredictionCard
                prediction={prediction}
                icon={
                  prediction.disease === 'Heart Disease' ? (
                    <Heart className="w-6 h-6" />
                  ) : prediction.disease === 'Diabetes' ? (
                    <Droplet className="w-6 h-6" />
                  ) : (
                    <AlertTriangle className="w-6 h-6" />
                  )
                }
                language={language}
              />
            </motion.div>
          ))}
        </div>
      </div>

      {/* Health Tip Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        whileHover={{ scale: 1.02 }}
        className="relative group"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all"></div>
        <div className="relative bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-start gap-4">
            <div className="bg-white/20 p-3 rounded-xl">
              <Sparkles className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="text-xl mb-2">{t.healthTip}</h3>
              <p className="text-green-50">
                Regular physical activity for 30 minutes daily can reduce your diabetes risk by up to 40%. 
                Consider starting with a brisk walk after dinner.
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Activity & Appointments Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7 }}
          whileHover={{ scale: 1.02 }}
          className="bg-white/80 backdrop-blur-xl border border-gray-200/50 rounded-2xl p-6 shadow-xl"
        >
          <div className="text-gray-900 mb-4 flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <h3>{t.recent}</h3>
          </div>
          <div className="space-y-3">
            {[
              { action: 'Lab Report Uploaded', time: '2 hours ago', status: 'success', icon: FileText },
              { action: 'BP Reading: 128/82 mmHg', time: '5 hours ago', status: 'normal', icon: Heart },
              { action: 'AI Analysis Completed', time: '1 day ago', status: 'info', icon: Sparkles }
            ].map((activity, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 + idx * 0.1 }}
                whileHover={{ x: 5 }}
                className="flex items-center gap-4 p-3 rounded-xl hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  activity.status === 'success' ? 'bg-green-100' :
                  activity.status === 'normal' ? 'bg-blue-100' : 'bg-purple-100'
                }`}>
                  <activity.icon className={`w-5 h-5 ${
                    activity.status === 'success' ? 'text-green-600' :
                    activity.status === 'normal' ? 'text-blue-600' : 'text-purple-600'
                  }`} />
                </div>
                <div className="flex-1">
                  <p className="text-gray-900">{activity.action}</p>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Clock className="w-3 h-3" />
                    {activity.time}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Upcoming Appointments */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7 }}
          whileHover={{ scale: 1.02 }}
          className="bg-white/80 backdrop-blur-xl border border-gray-200/50 rounded-2xl p-6 shadow-xl"
        >
          <div className="text-gray-900 mb-4 flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-white" />
            </div>
            <h3>{t.appointments}</h3>
          </div>
          <div className="space-y-3">
            {[
              { type: t.checkup, doctor: 'Dr. Sarah Johnson', date: 'Nov 5, 2025', time: '10:00 AM', color: 'blue' },
              { type: t.followup, doctor: 'Dr. Michael Chen', date: 'Nov 12, 2025', time: '2:30 PM', color: 'purple' }
            ].map((appointment, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9 + idx * 0.1 }}
                whileHover={{ scale: 1.03 }}
                className={`bg-gradient-to-br ${
                  appointment.color === 'blue' 
                    ? 'from-blue-50 to-blue-100/50' 
                    : 'from-purple-50 to-purple-100/50'
                } border ${
                  appointment.color === 'blue'
                    ? 'border-blue-200'
                    : 'border-purple-200'
                } rounded-xl p-4 cursor-pointer`}
              >
                <p className="text-gray-900 mb-2">{appointment.type}</p>
                <p className="text-gray-600 text-sm mb-1">{appointment.doctor}</p>
                <div className="flex items-center gap-2 text-gray-500 text-sm">
                  <Calendar className="w-3 h-3" />
                  {appointment.date}
                  <span>•</span>
                  <Clock className="w-3 h-3" />
                  {appointment.time}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
