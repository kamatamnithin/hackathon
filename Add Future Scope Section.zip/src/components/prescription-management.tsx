import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  FileText, Plus, Calendar, Clock, Bell, Check, 
  AlertTriangle, Pill, User, Download, Share2, QrCode
} from 'lucide-react';

interface Prescription {
  id: string;
  doctorName: string;
  date: string;
  medications: Medication[];
  diagnosis: string;
  validUntil: string;
  status: 'active' | 'expired' | 'completed';
}

interface Medication {
  name: string;
  dosage: string;
  frequency: string;
  duration: string;
  timings: string[];
  withFood: boolean;
  nextDose?: string;
  takenToday: boolean;
}

interface PrescriptionManagementProps {
  language: 'en' | 'hi' | 'te';
  userType: 'patient' | 'doctor';
}

export function PrescriptionManagement({ language, userType }: PrescriptionManagementProps) {
  const [prescriptions] = useState<Prescription[]>([
    {
      id: '1',
      doctorName: 'Dr. Sarah Johnson',
      date: '2025-10-28',
      diagnosis: 'Type 2 Diabetes Management',
      validUntil: '2025-12-28',
      status: 'active',
      medications: [
        {
          name: 'Metformin',
          dosage: '500mg',
          frequency: 'Twice daily',
          duration: '2 months',
          timings: ['08:00 AM', '08:00 PM'],
          withFood: true,
          nextDose: '08:00 PM',
          takenToday: true
        },
        {
          name: 'Glimepiride',
          dosage: '2mg',
          frequency: 'Once daily',
          duration: '2 months',
          timings: ['08:00 AM'],
          withFood: true,
          nextDose: 'Taken',
          takenToday: true
        }
      ]
    },
    {
      id: '2',
      doctorName: 'Dr. Michael Chen',
      date: '2025-10-15',
      diagnosis: 'Hypertension Control',
      validUntil: '2025-11-15',
      status: 'active',
      medications: [
        {
          name: 'Amlodipine',
          dosage: '5mg',
          frequency: 'Once daily',
          duration: '1 month',
          timings: ['07:00 AM'],
          withFood: false,
          nextDose: 'Tomorrow 07:00 AM',
          takenToday: true
        }
      ]
    }
  ]);

  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(prescriptions[0]);

  const translations = {
    en: {
      title: 'Prescription Management',
      activePrescriptions: 'Active Prescriptions',
      createNew: 'Create Prescription',
      medications: 'Medications',
      diagnosis: 'Diagnosis',
      prescribedBy: 'Prescribed by',
      validUntil: 'Valid until',
      dosage: 'Dosage',
      frequency: 'Frequency',
      duration: 'Duration',
      timings: 'Timings',
      nextDose: 'Next Dose',
      withFood: 'Take with food',
      markAsTaken: 'Mark as Taken',
      downloadPrescription: 'Download Prescription',
      sharePrescription: 'Share Prescription',
      viewQRCode: 'View QR Code',
      medicationReminders: 'Medication Reminders',
      upcomingDoses: 'Upcoming Doses',
      adherenceRate: 'Adherence Rate',
      takenToday: 'Taken today',
      pendingDoses: 'Pending doses',
      refillReminder: 'Refill Reminder',
      daysLeft: 'days left'
    },
    hi: {
      title: 'प्रिस्क्रिप्शन प्रबंधन',
      activePrescriptions: 'सक्रिय प्रिस्क्रिप्शन',
      createNew: 'प्रिस्क्रिप्शन बनाएं',
      medications: 'दवाइयाँ',
      diagnosis: 'निदान',
      prescribedBy: 'द्वारा निर्धारित',
      validUntil: 'तक वैध',
      dosage: 'खुराक',
      frequency: 'आवृत्ति',
      duration: 'अवधि',
      timings: 'समय',
      nextDose: 'अगली खुराक',
      withFood: 'भोजन के साथ लें',
      markAsTaken: 'ली गई के रूप में चिह्नित करें',
      downloadPrescription: 'प्रिस्क्रिप्शन डाउनलोड करें',
      sharePrescription: 'प्रिस्क्रिप्शन साझा करें',
      viewQRCode: 'QR कोड देखें',
      medicationReminders: 'दवा रिमाइंडर',
      upcomingDoses: 'आगामी खुराक',
      adherenceRate: 'पालन दर',
      takenToday: 'आज ली गई',
      pendingDoses: 'लंबित खुराक',
      refillReminder: 'रीफिल रिमाइंडर',
      daysLeft: 'दिन शेष'
    },
    te: {
      title: 'ప్రిస్క్రిప్షన్ నిర్వహణ',
      activePrescriptions: 'యాక్టివ్ ప్రిస్క్రిప్షన్‌లు',
      createNew: 'ప్రిస్క్రిప్షన్ సృష్టించండి',
      medications: 'మందులు',
      diagnosis: 'రోగ నిర్ధారణ',
      prescribedBy: 'ద్వారా సూచించబడింది',
      validUntil: 'వరకు చెల్లుబాటు అవుతుంది',
      dosage: 'డోసేజ్',
      frequency: 'ఫ్రీక్వెన్సీ',
      duration: 'వ్యవధి',
      timings: 'సమయాలు',
      nextDose: 'తదుపరి మోతాదు',
      withFood: 'ఆహారంతో తీసుకోండి',
      markAsTaken: 'తీసుకున్నట్లు గుర్తు పెట్టండి',
      downloadPrescription: 'ప్రిస్క్రిప్షన్ డౌన్‌లోడ్ చేయండి',
      sharePrescription: 'ప్రిస్క్రిప్షన్ షేర్ చేయండి',
      viewQRCode: 'QR కోడ్ చూడండి',
      medicationReminders: 'మందు రిమైండర్‌లు',
      upcomingDoses: 'రాబోయే మోతాదులు',
      adherenceRate: 'పాటించే రేటు',
      takenToday: 'ఈరోజు తీసుకున్నారు',
      pendingDoses: 'పెండింగ్ మోతాదులు',
      refillReminder: 'రీఫిల్ రిమైండర్',
      daysLeft: 'రోజులు మిగిలి ఉన్నాయి'
    }
  };

  const t = translations[language];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-700';
      case 'expired': return 'bg-red-100 text-red-700';
      case 'completed': return 'bg-gray-100 text-gray-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const adherenceRate = 92; // Mock data

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl text-gray-900">{t.title}</h2>
            <p className="text-gray-600 text-sm">Digital prescription tracking & reminders</p>
          </div>
        </div>
        {userType === 'doctor' && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-xl hover:shadow-lg transition-all"
          >
            <Plus className="w-5 h-5" />
            {t.createNew}
          </motion.button>
        )}
      </div>

      {/* Stats Cards */}
      {userType === 'patient' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-xl p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <Check className="w-8 h-8 text-green-600" />
              <span className="text-3xl text-gray-900">{adherenceRate}%</span>
            </div>
            <p className="text-gray-700">{t.adherenceRate}</p>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            className="bg-gradient-to-br from-blue-50 to-blue-50 border border-blue-200 rounded-xl p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <Pill className="w-8 h-8 text-blue-600" />
              <span className="text-3xl text-gray-900">4</span>
            </div>
            <p className="text-gray-700">{t.takenToday}</p>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            className="bg-gradient-to-br from-orange-50 to-orange-50 border border-orange-200 rounded-xl p-4"
          >
            <div className="flex items-center justify-between mb-2">
              <Bell className="w-8 h-8 text-orange-600" />
              <span className="text-3xl text-gray-900">2</span>
            </div>
            <p className="text-gray-700">{t.pendingDoses}</p>
          </motion.div>
        </div>
      )}

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Prescriptions List */}
        <div className="lg:col-span-1 space-y-3">
          <h3 className="text-lg text-gray-900 mb-3">{t.activePrescriptions}</h3>
          {prescriptions.map((prescription) => (
            <motion.div
              key={prescription.id}
              whileHover={{ scale: 1.02, x: 5 }}
              onClick={() => setSelectedPrescription(prescription)}
              className={`bg-white border-2 rounded-xl p-4 cursor-pointer transition-all ${
                selectedPrescription?.id === prescription.id
                  ? 'border-indigo-500 shadow-lg'
                  : 'border-gray-200 hover:border-indigo-300'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="text-gray-900 mb-1">{prescription.diagnosis}</h4>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <User className="w-4 h-4" />
                    {prescription.doctorName}
                  </div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(prescription.status)}`}>
                  {prescription.status}
                </span>
              </div>
              <div className="flex items-center gap-3 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {prescription.date}
                </div>
                <div className="flex items-center gap-1">
                  <Pill className="w-4 h-4" />
                  {prescription.medications.length}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Prescription Details */}
        <div className="lg:col-span-2">
          {selectedPrescription ? (
            <div className="space-y-4">
              {/* Header Card */}
              <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-6 text-white">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-2xl mb-2">{selectedPrescription.diagnosis}</h3>
                    <div className="space-y-1 text-indigo-100">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        {t.prescribedBy}: {selectedPrescription.doctorName}
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        {selectedPrescription.date}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {t.validUntil}: {selectedPrescription.validUntil}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-lg flex items-center justify-center transition-colors"
                    >
                      <Download className="w-5 h-5" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-lg flex items-center justify-center transition-colors"
                    >
                      <Share2 className="w-5 h-5" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-lg flex items-center justify-center transition-colors"
                    >
                      <QrCode className="w-5 h-5" />
                    </motion.button>
                  </div>
                </div>
              </div>

              {/* Medications */}
              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                <div className="p-4 border-b border-gray-200 bg-gray-50">
                  <h4 className="text-gray-900">{t.medications}</h4>
                </div>
                <div className="p-4 space-y-4">
                  {selectedPrescription.medications.map((med, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="bg-gradient-to-br from-gray-50 to-blue-50 border border-gray-200 rounded-xl p-4"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-start gap-3">
                          <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                            <Pill className="w-6 h-6 text-indigo-600" />
                          </div>
                          <div>
                            <h5 className="text-gray-900 mb-1">{med.name}</h5>
                            <p className="text-sm text-gray-600">{med.dosage} • {med.frequency}</p>
                          </div>
                        </div>
                        {med.takenToday ? (
                          <div className="flex items-center gap-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                            <Check className="w-4 h-4" />
                            {t.takenToday}
                          </div>
                        ) : (
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            className="px-3 py-1 bg-indigo-500 text-white rounded-full text-sm hover:bg-indigo-600 transition-colors"
                          >
                            {t.markAsTaken}
                          </motion.button>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600 mb-1">{t.timings}</p>
                          <div className="flex flex-wrap gap-2">
                            {med.timings.map((time, i) => (
                              <span key={i} className="px-2 py-1 bg-white border border-gray-200 rounded-lg text-gray-900">
                                {time}
                              </span>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">{t.nextDose}</p>
                          <p className="text-gray-900">{med.nextDose}</p>
                        </div>
                      </div>

                      {med.withFood && (
                        <div className="mt-3 flex items-center gap-2 text-sm text-orange-600">
                          <AlertTriangle className="w-4 h-4" />
                          {t.withFood}
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Refill Reminder */}
              {userType === 'patient' && (
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-4"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center">
                      <Bell className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-gray-900 mb-1">{t.refillReminder}</h4>
                      <p className="text-sm text-gray-600">15 {t.daysLeft} for Metformin</p>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          ) : (
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-12 text-center">
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Select a prescription to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
