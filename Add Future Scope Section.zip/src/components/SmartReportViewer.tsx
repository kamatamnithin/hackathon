import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { FileText, Download, Share2, Eye } from 'lucide-react';
import { Badge } from './ui/badge';

interface Report {
  id: string;
  type: string;
  date: string;
  status: 'normal' | 'abnormal' | 'critical';
  findings: string[];
}

const mockReports: Report[] = [
  {
    id: '1',
    type: 'Blood Test',
    date: '2025-10-28',
    status: 'abnormal',
    findings: [
      'Glucose: 145 mg/dL (High)',
      'Cholesterol: 220 mg/dL (Borderline High)',
      'HbA1c: 6.2% (Pre-diabetic range)'
    ]
  },
  {
    id: '2',
    type: 'ECG Report',
    date: '2025-10-25',
    status: 'normal',
    findings: [
      'Heart Rate: 72 bpm (Normal)',
      'Rhythm: Regular sinus rhythm',
      'No ST segment abnormalities'
    ]
  },
  {
    id: '3',
    type: 'Chest X-Ray',
    date: '2025-10-20',
    status: 'normal',
    findings: [
      'Lungs: Clear, no infiltrates',
      'Heart size: Normal',
      'No pleural effusion'
    ]
  }
];

export function SmartReportViewer() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'normal': return 'bg-green-100 text-green-800 border-green-200';
      case 'abnormal': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-500" />
            <div>
              <CardTitle>Medical Reports</CardTitle>
              <CardDescription>View and download patient lab reports</CardDescription>
            </div>
          </div>
          <Button variant="outline" size="sm">
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">All Reports</TabsTrigger>
            <TabsTrigger value="recent">Recent</TabsTrigger>
            <TabsTrigger value="abnormal">Abnormal</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="space-y-3 mt-4">
            {mockReports.map((report) => (
              <div key={report.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="text-gray-900">{report.type}</h4>
                    <p className="text-sm text-gray-500">Date: {new Date(report.date).toLocaleDateString()}</p>
                  </div>
                  <Badge className={getStatusColor(report.status)}>
                    {report.status.toUpperCase()}
                  </Badge>
                </div>
                
                <div className="space-y-1 mb-3">
                  <p className="text-sm text-gray-700">Key Findings:</p>
                  <ul className="space-y-1 ml-4">
                    {report.findings.map((finding, idx) => (
                      <li key={idx} className="text-sm text-gray-600 list-disc">{finding}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <Eye className="w-4 h-4 mr-1" />
                    View Full Report
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-1" />
                    Download PDF
                  </Button>
                </div>
              </div>
            ))}
          </TabsContent>
          
          <TabsContent value="recent" className="mt-4">
            <p className="text-sm text-gray-600">Showing reports from the last 7 days</p>
          </TabsContent>
          
          <TabsContent value="abnormal" className="mt-4">
            <p className="text-sm text-gray-600">Showing only abnormal and critical reports</p>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
