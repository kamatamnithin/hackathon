import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Video, VideoOff, Mic, MicOff, Phone, Monitor, 
  MessageSquare, Users, Clock, Calendar, AlertCircle,
  FileText, Camera, Share2, Settings
} from 'lucide-react';

interface TelemedicineProps {
  language: 'en' | 'hi' | 'te';
  userType: 'patient' | 'doctor';
}

export function Telemedicine({ language, userType }: TelemedicineProps) {
  const [isInCall, setIsInCall] = useState(false);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [screenSharing, setScreenSharing] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [chatMessages, setChatMessages] = useState([
    { sender: 'Dr. Sarah Johnson', message: 'Hello! How can I help you today?', time: '10:30 AM', isDoctor: true },
    { sender: 'You', message: 'I have been experiencing chest pain', time: '10:31 AM', isDoctor: false }
  ]);

  const translations = {
    en: {
      title: 'Telemedicine Consultation',
      startCall: 'Start Video Call',
      endCall: 'End Call',
      upcomingConsultations: 'Upcoming Consultations',
      joinCall: 'Join Call',
      scheduled: 'Scheduled',
      duration: 'Duration',
      chat: 'Chat',
      shareScreen: 'Share Screen',
      participants: 'Participants',
      sendMessage: 'Type a message...',
      noUpcoming: 'No upcoming consultations',
      bookNow: 'Book Consultation',
      callDuration: 'Call Duration',
      prescriptionShared: 'Prescription shared',
      labReportShared: 'Lab report shared'
    },
    hi: {
      title: 'टेलीमेडिसिन परामर्श',
      startCall: 'वीडियो कॉल शुरू करें',
      endCall: 'कॉल समाप्त करें',
      upcomingConsultations: 'आगामी परामर्श',
      joinCall: 'कॉल में शामिल हों',
      scheduled: 'निर्धारित',
      duration: 'अवधि',
      chat: 'चैट',
      shareScreen: 'स्क्रीन साझा करें',
      participants: 'प्रतिभागी',
      sendMessage: 'संदेश टाइप करें...',
      noUpcoming: 'कोई आगामी परामर्श नहीं',
      bookNow: 'परामर्श बुक करें',
      callDuration: 'कॉल अवधि',
      prescriptionShared: 'प्रिस्क्रिप्शन साझा किया गया',
      labReportShared: 'लैब रिपोर्ट साझा की गई'
    },
    te: {
      title: 'టెలిమెడిసిన్ సంప్రదింపు',
      startCall: 'వీడియో కాల్ ప్రారంభించండి',
      endCall: 'కాల్ ముగించు',
      upcomingConsultations: 'రాబోయే సంప్రదింపులు',
      joinCall: 'కాల్‌లో చేరండి',
      scheduled: 'షెడ్యూల్ చేసినది',
      duration: 'వ్యవధి',
      chat: 'చాట్',
      shareScreen: 'స్క్రీన్ షేర్ చేయండి',
      participants: 'పాల్గొనేవారు',
      sendMessage: 'సందేశం టైప్ చేయండి...',
      noUpcoming: 'రాబోయే సంప్రదింపులు లేవు',
      bookNow: 'సంప్రదింపు బుక్ చేయండి',
      callDuration: 'కాల్ వ్యవధి',
      prescriptionShared: 'ప్రిస్క్రిప్షన్ షేర్ చేసారు',
      labReportShared: 'ల్యాబ్ రిపోర్ట్ షేర్ చేసారు'
    }
  };

  const t = translations[language];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isInCall) {
      interval = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isInCall]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const upcomingCalls = [
    {
      id: 1,
      name: userType === 'patient' ? 'Dr. Sarah Johnson' : 'John Doe',
      specialty: 'Cardiologist',
      date: '2025-11-01',
      time: '10:00 AM',
      duration: '30 min',
      status: 'upcoming'
    },
    {
      id: 2,
      name: userType === 'patient' ? 'Dr. Michael Chen' : 'Priya Sharma',
      specialty: 'Endocrinologist',
      date: '2025-11-03',
      time: '2:30 PM',
      duration: '45 min',
      status: 'upcoming'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
            <Video className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl text-gray-900">{t.title}</h2>
            <p className="text-gray-600 text-sm">Real-time video consultations</p>
          </div>
        </div>
      </div>

      {!isInCall ? (
        <>
          {/* Upcoming Consultations */}
          <div className="bg-white border border-gray-200 rounded-xl p-6">
            <h3 className="text-lg text-gray-900 mb-4">{t.upcomingConsultations}</h3>
            <div className="space-y-3">
              {upcomingCalls.map((call) => (
                <motion.div
                  key={call.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  whileHover={{ scale: 1.02 }}
                  className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-xl"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xl">
                      {call.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="text-gray-900">{call.name}</h4>
                      <p className="text-sm text-gray-600">{call.specialty}</p>
                      <div className="flex items-center gap-3 mt-1 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {call.date}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {call.time}
                        </div>
                        <span className="text-gray-400">•</span>
                        <span>{call.duration}</span>
                      </div>
                    </div>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setIsInCall(true)}
                    className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl hover:shadow-lg transition-all"
                  >
                    <Video className="w-5 h-5" />
                    {t.joinCall}
                  </motion.button>
                </motion.div>
              ))}
            </div>
          </div>
        </>
      ) : (
        // In-Call Interface
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Video Area */}
          <div className="lg:col-span-3 space-y-4">
            {/* Main Video */}
            <div className="relative bg-gray-900 rounded-2xl overflow-hidden aspect-video">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-4xl mx-auto mb-4">
                    {userType === 'patient' ? 'DJ' : 'P'}
                  </div>
                  <h3 className="text-white text-xl mb-2">
                    {userType === 'patient' ? 'Dr. Sarah Johnson' : 'Patient'}
                  </h3>
                  <div className="flex items-center justify-center gap-2 text-gray-300">
                    <Clock className="w-4 h-4" />
                    {formatDuration(callDuration)}
                  </div>
                </div>
              </div>

              {/* Self Video (Picture-in-Picture) */}
              <div className="absolute top-4 right-4 w-48 h-36 bg-gray-800 rounded-xl overflow-hidden border-2 border-white shadow-xl">
                <div className="w-full h-full flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-white text-xl">
                    You
                  </div>
                </div>
              </div>

              {/* Status Indicators */}
              <div className="absolute top-4 left-4 flex gap-2">
                <div className="px-3 py-1 bg-red-500 text-white rounded-full text-sm flex items-center gap-2">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  LIVE
                </div>
                <div className="px-3 py-1 bg-black/50 backdrop-blur-sm text-white rounded-full text-sm">
                  {formatDuration(callDuration)}
                </div>
              </div>

              {screenSharing && (
                <div className="absolute bottom-20 left-1/2 -translate-x-1/2 px-4 py-2 bg-blue-500 text-white rounded-full text-sm flex items-center gap-2">
                  <Monitor className="w-4 h-4" />
                  Screen Sharing Active
                </div>
              )}
            </div>

            {/* Call Controls */}
            <div className="flex items-center justify-center gap-4 p-6 bg-white border border-gray-200 rounded-2xl">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setVideoEnabled(!videoEnabled)}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                  videoEnabled 
                    ? 'bg-gray-100 hover:bg-gray-200 text-gray-700' 
                    : 'bg-red-500 text-white'
                }`}
              >
                {videoEnabled ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setAudioEnabled(!audioEnabled)}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                  audioEnabled 
                    ? 'bg-gray-100 hover:bg-gray-200 text-gray-700' 
                    : 'bg-red-500 text-white'
                }`}
              >
                {audioEnabled ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setScreenSharing(!screenSharing)}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                  screenSharing 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                }`}
              >
                <Monitor className="w-6 h-6" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="w-14 h-14 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-700 flex items-center justify-center transition-all"
              >
                <Camera className="w-6 h-6" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="w-14 h-14 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-700 flex items-center justify-center transition-all"
              >
                <Settings className="w-6 h-6" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => {
                  setIsInCall(false);
                  setCallDuration(0);
                }}
                className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center transition-all shadow-lg"
              >
                <Phone className="w-7 h-7 rotate-135" />
              </motion.button>
            </div>
          </div>

          {/* Sidebar - Chat & Participants */}
          <div className="lg:col-span-1 space-y-4">
            {/* Participants */}
            <div className="bg-white border border-gray-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-4">
                <Users className="w-5 h-5 text-gray-600" />
                <h4 className="text-gray-900">{t.participants} (2)</h4>
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white">
                    D
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">Dr. Sarah Johnson</p>
                    <p className="text-xs text-gray-500">Host</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center text-white">
                    Y
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">You</p>
                    <p className="text-xs text-gray-500">Patient</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Chat */}
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden flex flex-col h-96">
              <div className="flex items-center gap-2 p-4 border-b border-gray-200">
                <MessageSquare className="w-5 h-5 text-gray-600" />
                <h4 className="text-gray-900">{t.chat}</h4>
              </div>
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {chatMessages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.isDoctor ? 'justify-start' : 'justify-end'}`}>
                    <div className={`max-w-xs rounded-lg p-3 ${
                      msg.isDoctor 
                        ? 'bg-gray-100 text-gray-900' 
                        : 'bg-blue-500 text-white'
                    }`}>
                      <p className="text-xs opacity-75 mb-1">{msg.sender}</p>
                      <p className="text-sm">{msg.message}</p>
                      <p className="text-xs opacity-75 mt-1">{msg.time}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-4 border-t border-gray-200">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder={t.sendMessage}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    Send
                  </motion.button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
