import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const regionalData = [
  { region: 'North', diabetes: 245, cardio: 189, cancer: 67 },
  { region: 'South', diabetes: 312, cardio: 234, cancer: 89 },
  { region: 'East', diabetes: 198, cardio: 156, cancer: 54 },
  { region: 'West', diabetes: 278, cardio: 201, cancer: 71 },
];

const ageWiseData = [
  { ageGroup: '18-30', risk: 15 },
  { ageGroup: '31-45', risk: 35 },
  { ageGroup: '46-60', risk: 58 },
  { ageGroup: '61+', risk: 72 },
];

const lifestyleData = [
  { name: 'Sedentary', value: 42 },
  { name: 'Moderate', value: 35 },
  { name: 'Active', value: 23 },
];

const COLORS = ['#ef4444', '#f59e0b', '#10b981'];

export function DiseaseAnalytics() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-gray-900 mb-2">Disease Trend Analytics</h2>
        <p className="text-gray-600">Real-time insights from aggregated anonymized patient data</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Regional Disease Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Regional Disease Distribution</CardTitle>
            <CardDescription>Cases by geographic region</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={regionalData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="region" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="diabetes" fill="#3b82f6" name="Diabetes" />
                <Bar dataKey="cardio" fill="#ef4444" name="Cardiovascular" />
                <Bar dataKey="cancer" fill="#8b5cf6" name="Cancer" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Age-wise Risk Pattern */}
        <Card>
          <CardHeader>
            <CardTitle>Age-wise Risk Pattern</CardTitle>
            <CardDescription>Average disease risk by age group</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={ageWiseData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="ageGroup" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="risk" stroke="#8b5cf6" strokeWidth={2} name="Risk %" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Lifestyle Correlation */}
        <Card>
          <CardHeader>
            <CardTitle>Lifestyle vs Disease Correlation</CardTitle>
            <CardDescription>Patient activity levels distribution</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={lifestyleData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {lifestyleData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Key Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Key Insights</CardTitle>
            <CardDescription>AI-generated health trends</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800">
                <strong>Trending Up:</strong> Diabetes cases increased by 12% in South region this quarter
              </p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg border border-green-200">
              <p className="text-sm text-green-800">
                <strong>Positive Trend:</strong> Active lifestyle groups show 45% lower disease risk
              </p>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <p className="text-sm text-yellow-800">
                <strong>Alert:</strong> Cardiovascular risk peaks in 61+ age group - preventive care recommended
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
