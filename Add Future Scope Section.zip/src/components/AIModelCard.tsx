import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { ConfidenceMeter } from './ConfidenceMeter';
import { Activity, Droplet, AlertTriangle } from 'lucide-react';

interface AIModelCardProps {
  modelType: 'cardio' | 'gluco' | 'onco';
  prediction: number;
  riskLevel: 'low' | 'medium' | 'high';
  lastUpdated: string;
  topFactors: string[];
}

export function AIModelCard({ modelType, prediction, riskLevel, lastUpdated, topFactors }: AIModelCardProps) {
  const modelConfig = {
    cardio: {
      title: 'CardioRisk Predictor',
      description: 'AI-powered heart disease risk assessment',
      icon: Activity,
      color: 'text-red-500'
    },
    gluco: {
      title: 'GlucoAnalyzer',
      description: 'Diabetes detection and monitoring',
      icon: Droplet,
      color: 'text-blue-500'
    },
    onco: {
      title: 'OncoAI',
      description: 'Cancer risk detection system',
      icon: AlertTriangle,
      color: 'text-purple-500'
    }
  };

  const config = modelConfig[modelType];
  const Icon = config.icon;

  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className={`p-3 rounded-lg bg-gray-100 ${config.color}`}>
            <Icon className="w-6 h-6" />
          </div>
          <div>
            <CardTitle>{config.title}</CardTitle>
            <CardDescription>{config.description}</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <ConfidenceMeter 
          value={prediction} 
          label="Risk Assessment" 
          riskLevel={riskLevel}
        />
        
        <div className="pt-3 border-t border-gray-200">
          <p className="text-sm text-gray-600 mb-2">Key Contributing Factors:</p>
          <ul className="space-y-1">
            {topFactors.map((factor, idx) => (
              <li key={idx} className="text-sm text-gray-700 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-gray-400"></span>
                {factor}
              </li>
            ))}
          </ul>
        </div>
        
        <p className="text-xs text-gray-500 pt-2">
          Last updated: {lastUpdated}
        </p>
      </CardContent>
    </Card>
  );
}
