import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

interface AnimatedStatsProps {
  value: number;
  label: string;
  suffix?: string;
  icon: React.ReactNode;
  color: string;
  delay?: number;
}

export function AnimatedStats({ value, label, suffix = '', icon, color, delay = 0 }: AnimatedStatsProps) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const duration = 2000;
    const steps = 60;
    const increment = value / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [value]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.8 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ scale: 1.05, y: -5 }}
      className="relative group"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-300"></div>
      <div className="relative bg-white/80 backdrop-blur-xl border border-white/20 rounded-2xl p-8 shadow-xl">
        <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-4 shadow-lg`}>
          {icon}
        </div>
        <div className="text-4xl mb-2 bg-gradient-to-br from-gray-900 to-gray-600 bg-clip-text text-transparent">
          {count}{suffix}
        </div>
        <p className="text-gray-600">{label}</p>
      </div>
    </motion.div>
  );
}
