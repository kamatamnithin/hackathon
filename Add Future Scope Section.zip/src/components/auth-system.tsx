import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Mail, Lock, Phone, Calendar, MapPin, Shield, Eye, EyeOff, UserPlus, LogIn } from 'lucide-react';

interface AuthSystemProps {
  onLogin: (userType: 'patient' | 'doctor', userData: any) => void;
  language: 'en' | 'hi' | 'te';
}

export function AuthSystem({ onLogin, language }: AuthSystemProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [userType, setUserType] = useState<'patient' | 'doctor'>('patient');
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    phone: '',
    dateOfBirth: '',
    address: '',
    medicalLicense: '',
    specialization: ''
  });

  const translations = {
    en: {
      welcome: 'Welcome to HealthAI',
      login: 'Sign In',
      register: 'Create Account',
      email: 'Email Address',
      password: 'Password',
      fullName: 'Full Name',
      phone: 'Phone Number',
      dateOfBirth: 'Date of Birth',
      address: 'Address',
      medicalLicense: 'Medical License Number',
      specialization: 'Specialization',
      patient: 'Patient',
      doctor: 'Doctor',
      switchToRegister: "Don't have an account? Sign up",
      switchToLogin: 'Already have an account? Sign in',
      continueAs: 'Continue as',
      secureLogin: 'Secure Login with ABDM Integration',
      demoNote: 'Demo Mode: Click any button to continue'
    },
    hi: {
      welcome: 'HealthAI में आपका स्वागत है',
      login: 'साइन इन करें',
      register: 'खाता बनाएं',
      email: 'ईमेल पता',
      password: 'पासवर्ड',
      fullName: 'पूरा नाम',
      phone: 'फोन नंबर',
      dateOfBirth: 'जन्म तिथि',
      address: 'पता',
      medicalLicense: 'मेडिकल लाइसेंस नंबर',
      specialization: 'विशेषज्ञता',
      patient: 'रोगी',
      doctor: 'डॉक्टर',
      switchToRegister: 'खाता नहीं है? साइन अप करें',
      switchToLogin: 'पहले से खाता है? साइन इन करें',
      continueAs: 'जारी रखें',
      secureLogin: 'ABDM एकीकरण के साथ सुरक्षित लॉगिन',
      demoNote: 'डेमो मोड: जारी रखने के लिए किसी भी बटन पर क्लिक करें'
    },
    te: {
      welcome: 'HealthAIకి స్వాగతం',
      login: 'సైన్ ఇన్',
      register: 'ఖాతా సృష్టించండి',
      email: 'ఇమెయిల్ చిరునామా',
      password: 'పాస్‌వర్డ్',
      fullName: 'పూర్తి పేరు',
      phone: 'ఫోన్ నంబర్',
      dateOfBirth: 'పుట్టిన తేదీ',
      address: 'చిరునామా',
      medicalLicense: 'మెడికల్ లైసెన్స్ నంబర్',
      specialization: 'ప్రత్యేకత',
      patient: 'రోగి',
      doctor: 'వైద్యుడు',
      switchToRegister: 'ఖాతా లేదా? సైన్ అప్ చేయండి',
      switchToLogin: 'ఇప్పటికే ఖాతా ఉందా? సైన్ ఇన్ చేయండి',
      continueAs: 'కొనసాగించు',
      secureLogin: 'ABDM ఇంటిగ్రేషన్‌తో సురక్షిత లాగిన్',
      demoNote: 'డెమో మోడ్: కొనసాగించడానికి ఏదైనా బటన్ క్లిక్ చేయండి'
    }
  };

  const t = translations[language];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Demo mode - simulate login
    onLogin(userType, {
      name: formData.fullName || 'Demo User',
      email: formData.email || 'demo@healthai.com',
      userType: userType
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 flex items-center justify-center p-6">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-500/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-5xl"
      >
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Side - Info */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="hidden lg:flex flex-col justify-center text-white space-y-6"
          >
            <h1 className="text-5xl mb-4">{t.welcome}</h1>
            <p className="text-xl text-gray-300 leading-relaxed">
              Advanced AI-powered healthcare platform for disease prediction, patient management, and real-time health monitoring.
            </p>
            
            <div className="space-y-4 mt-8">
              {[
                { icon: Shield, text: 'HIPAA & ABDM Compliant' },
                { icon: User, text: '50,000+ Active Users' },
                { icon: Calendar, text: '24/7 Healthcare Access' }
              ].map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + idx * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-xl flex items-center justify-center">
                    <item.icon className="w-6 h-6 text-blue-300" />
                  </div>
                  <span className="text-gray-200">{item.text}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Side - Auth Form */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-3xl blur-2xl"></div>
            <div className="relative bg-white/10 backdrop-blur-2xl border border-white/20 rounded-3xl p-8 shadow-2xl">
              {/* User Type Toggle */}
              <div className="flex gap-2 p-1 bg-white/5 rounded-xl mb-6">
                <button
                  onClick={() => setUserType('patient')}
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg transition-all ${
                    userType === 'patient'
                      ? 'bg-blue-500 text-white shadow-lg'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  <User className="w-5 h-5" />
                  {t.patient}
                </button>
                <button
                  onClick={() => setUserType('doctor')}
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg transition-all ${
                    userType === 'doctor'
                      ? 'bg-purple-500 text-white shadow-lg'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  <Shield className="w-5 h-5" />
                  {t.doctor}
                </button>
              </div>

              {/* Login/Register Toggle */}
              <div className="text-center mb-6">
                <h2 className="text-2xl text-white mb-2">
                  {isLogin ? t.login : t.register}
                </h2>
                <p className="text-gray-300 text-sm">{t.secureLogin}</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <AnimatePresence mode="wait">
                  {!isLogin && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="space-y-4"
                    >
                      {/* Full Name */}
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          placeholder={t.fullName}
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
                        />
                      </div>

                      {/* Phone */}
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="tel"
                          placeholder={t.phone}
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
                        />
                      </div>

                      {/* Date of Birth */}
                      <div className="relative">
                        <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="date"
                          placeholder={t.dateOfBirth}
                          value={formData.dateOfBirth}
                          onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
                        />
                      </div>

                      {userType === 'doctor' && (
                        <>
                          {/* Medical License */}
                          <div className="relative">
                            <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                              type="text"
                              placeholder={t.medicalLicense}
                              value={formData.medicalLicense}
                              onChange={(e) => setFormData({ ...formData, medicalLicense: e.target.value })}
                              className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
                            />
                          </div>

                          {/* Specialization */}
                          <div className="relative">
                            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <select
                              value={formData.specialization}
                              onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                              className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-blue-400 transition-colors"
                            >
                              <option value="" className="bg-gray-900">{t.specialization}</option>
                              <option value="cardiology" className="bg-gray-900">Cardiology</option>
                              <option value="endocrinology" className="bg-gray-900">Endocrinology</option>
                              <option value="oncology" className="bg-gray-900">Oncology</option>
                              <option value="general" className="bg-gray-900">General Medicine</option>
                            </select>
                          </div>
                        </>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Email */}
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    placeholder={t.email}
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
                  />
                </div>

                {/* Password */}
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder={t.password}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="w-full pl-12 pr-12 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>

                {/* Submit Button */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                >
                  {isLogin ? <LogIn className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
                  {isLogin ? t.login : t.register}
                </motion.button>

                {/* Toggle Auth Mode */}
                <button
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className="w-full text-center text-gray-300 hover:text-white transition-colors text-sm"
                >
                  {isLogin ? t.switchToRegister : t.switchToLogin}
                </button>

                {/* Demo Note */}
                <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl">
                  <p className="text-yellow-300 text-sm text-center">{t.demoNote}</p>
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
