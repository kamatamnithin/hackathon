import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Shield, FileText, DollarSign, Clock, Check, X, 
  Upload, AlertCircle, TrendingUp, Download, Eye,
  Calendar, CreditCard, Building
} from 'lucide-react';

interface InsuranceClaim {
  id: string;
  claimNumber: string;
  date: string;
  type: 'hospitalization' | 'consultation' | 'lab_test' | 'pharmacy';
  amount: number;
  status: 'pending' | 'approved' | 'rejected' | 'processing';
  provider: string;
  documents: string[];
  approvedAmount?: number;
  remarks?: string;
}

interface InsurancePolicy {
  provider: string;
  policyNumber: string;
  coverage: number;
  used: number;
  expiryDate: string;
  premium: number;
}

interface InsuranceClaimsProps {
  language: 'en' | 'hi' | 'te';
  userType: 'patient' | 'doctor';
}

export function InsuranceClaims({ language, userType }: InsuranceClaimsProps) {
  const [selectedClaim, setSelectedClaim] = useState<InsuranceClaim | null>(null);

  const policy: InsurancePolicy = {
    provider: 'Star Health Insurance',
    policyNumber: 'SH-2025-789456',
    coverage: 500000,
    used: 125000,
    expiryDate: '2026-03-31',
    premium: 15000
  };

  const claims: InsuranceClaim[] = [
    {
      id: '1',
      claimNumber: 'CLM-2025-1234',
      date: '2025-10-28',
      type: 'hospitalization',
      amount: 85000,
      status: 'approved',
      provider: 'Apollo Hospital',
      documents: ['Hospital Bill', 'Discharge Summary', 'Doctor Certificate'],
      approvedAmount: 82000,
      remarks: 'Approved with standard deductible'
    },
    {
      id: '2',
      claimNumber: 'CLM-2025-1235',
      date: '2025-10-25',
      type: 'lab_test',
      amount: 3500,
      status: 'processing',
      provider: 'Pathology Lab',
      documents: ['Lab Invoice', 'Test Reports']
    },
    {
      id: '3',
      claimNumber: 'CLM-2025-1236',
      date: '2025-10-20',
      type: 'pharmacy',
      amount: 2400,
      status: 'pending',
      provider: 'Apollo Pharmacy',
      documents: ['Pharmacy Bill', 'Prescription']
    },
    {
      id: '4',
      claimNumber: 'CLM-2025-1237',
      date: '2025-10-15',
      type: 'consultation',
      amount: 1500,
      status: 'rejected',
      provider: 'Dr. Sarah Johnson',
      documents: ['Consultation Bill'],
      remarks: 'Not covered under policy terms'
    }
  ];

  const translations = {
    en: {
      title: 'Insurance & Claims',
      yourPolicy: 'Your Insurance Policy',
      coverage: 'Total Coverage',
      used: 'Amount Used',
      available: 'Available',
      premium: 'Annual Premium',
      policyNumber: 'Policy Number',
      expiryDate: 'Expires on',
      recentClaims: 'Recent Claims',
      fileNewClaim: 'File New Claim',
      claimStatus: 'Claim Status',
      claimAmount: 'Claim Amount',
      approvedAmount: 'Approved Amount',
      claimDate: 'Claim Date',
      provider: 'Provider',
      documents: 'Documents',
      remarks: 'Remarks',
      viewDetails: 'View Details',
      download: 'Download',
      hospitalization: 'Hospitalization',
      consultation: 'Consultation',
      labTest: 'Lab Test',
      pharmacy: 'Pharmacy',
      pending: 'Pending',
      approved: 'Approved',
      rejected: 'Rejected',
      processing: 'Processing',
      claimHistory: 'Claim History',
      autoClaimFiling: 'Auto Claim Filing with ABDM'
    },
    hi: {
      title: 'बीमा और दावे',
      yourPolicy: 'आपकी बीमा पॉलिसी',
      coverage: 'कुल कवरेज',
      used: 'उपयोग की गई राशि',
      available: 'उपलब्ध',
      premium: 'वार्षिक प्रीमियम',
      policyNumber: 'पॉलिसी नंबर',
      expiryDate: 'समाप्त होती है',
      recentClaims: 'हालिया दावे',
      fileNewClaim: 'नया दावा दायर करें',
      claimStatus: 'दावे की स्थिति',
      claimAmount: 'दावे की राशि',
      approvedAmount: 'स्वीकृत राशि',
      claimDate: 'दावे की तारीख',
      provider: 'प्रदाता',
      documents: 'दस्तावेज़',
      remarks: 'टिप्पणियाँ',
      viewDetails: 'विवरण देखें',
      download: 'डाउनलोड',
      hospitalization: 'अस्पताल में भर्ती',
      consultation: 'परामर्श',
      labTest: 'लैब टेस्ट',
      pharmacy: 'फार्मेसी',
      pending: 'लंबित',
      approved: 'स्वीकृत',
      rejected: 'अस्वीकृत',
      processing: 'प्रसंस्करण',
      claimHistory: 'दावा इतिहास',
      autoClaimFiling: 'ABDM के साथ ऑटो क्लेम फाइलिंग'
    },
    te: {
      title: 'బీమా & క్లెయిమ్‌లు',
      yourPolicy: 'మీ బీమా పాలసీ',
      coverage: 'మొత్తం కవరేజీ',
      used: 'ఉపయోగించిన మొత్తం',
      available: 'అందుబాటులో',
      premium: 'వార్షిక ప్రీమియం',
      policyNumber: 'పాలసీ నంబర్',
      expiryDate: 'గడువు ముగిసేది',
      recentClaims: 'ఇటీవలి క్లెయిమ్‌లు',
      fileNewClaim: 'క్రొత్త క్లెయిమ్ ఫైల్ చేయండి',
      claimStatus: 'క్లెయిమ్ స్థితి',
      claimAmount: 'క్లెయిమ్ మొత్తం',
      approvedAmount: 'ఆమోదించిన మొత్తం',
      claimDate: 'క్లెయిమ్ తేదీ',
      provider: 'ప్రొవైడర్',
      documents: 'డాక్యుమెంట్‌లు',
      remarks: 'వ్యాఖ్యలు',
      viewDetails: 'వివరాలు చూడండి',
      download: 'డౌన్‌లోడ్',
      hospitalization: 'ఆసుపత్రిలో చేరడం',
      consultation: 'సంప్రదింపు',
      labTest: 'ల్యాబ్ టెస్ట్',
      pharmacy: 'ఫార్మసీ',
      pending: 'పెండింగ్',
      approved: 'ఆమోదించబడింది',
      rejected: 'తిరస్కరించబడింది',
      processing: 'ప్రాసెసింగ్',
      claimHistory: 'క్లెయిమ్ చరిత్ర',
      autoClaimFiling: 'ABDMతో ఆటో క్లెయిమ్ ఫైలింగ్'
    }
  };

  const t = translations[language];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-700 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-700 border-red-200';
      case 'processing': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'pending': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <Check className="w-4 h-4" />;
      case 'rejected': return <X className="w-4 h-4" />;
      case 'processing': return <Clock className="w-4 h-4 animate-spin" />;
      case 'pending': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'hospitalization': return t.hospitalization;
      case 'consultation': return t.consultation;
      case 'lab_test': return t.labTest;
      case 'pharmacy': return t.pharmacy;
      default: return type;
    }
  };

  const available = policy.coverage - policy.used;
  const usagePercent = (policy.used / policy.coverage) * 100;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl text-gray-900">{t.title}</h2>
            <p className="text-gray-600 text-sm">{t.autoClaimFiling}</p>
          </div>
        </div>
        {userType === 'patient' && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl hover:shadow-lg transition-all"
          >
            <Upload className="w-5 h-5" />
            {t.fileNewClaim}
          </motion.button>
        )}
      </div>

      {/* Policy Overview Card */}
      <div className="bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-purple-500/30 rounded-full blur-2xl"></div>
        
        <div className="relative z-10">
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Building className="w-5 h-5 text-blue-200" />
                <p className="text-blue-100">{t.yourPolicy}</p>
              </div>
              <h3 className="text-3xl mb-2">{policy.provider}</h3>
              <div className="flex items-center gap-4 text-blue-100 text-sm">
                <div className="flex items-center gap-1">
                  <CreditCard className="w-4 h-4" />
                  {t.policyNumber}: {policy.policyNumber}
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {t.expiryDate}: {policy.expiryDate}
                </div>
              </div>
            </div>
            <div className="bg-white/20 backdrop-blur-xl px-4 py-2 rounded-xl">
              <p className="text-sm text-blue-100">{t.premium}</p>
              <p className="text-xl">₹{policy.premium.toLocaleString()}</p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white/10 backdrop-blur-xl rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-blue-200" />
                <p className="text-sm text-blue-100">{t.coverage}</p>
              </div>
              <p className="text-2xl">₹{(policy.coverage / 100000).toFixed(1)}L</p>
            </div>

            <div className="bg-white/10 backdrop-blur-xl rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-blue-200" />
                <p className="text-sm text-blue-100">{t.used}</p>
              </div>
              <p className="text-2xl">₹{(policy.used / 100000).toFixed(1)}L</p>
            </div>

            <div className="bg-white/10 backdrop-blur-xl rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-5 h-5 text-blue-200" />
                <p className="text-sm text-blue-100">{t.available}</p>
              </div>
              <p className="text-2xl">₹{(available / 100000).toFixed(1)}L</p>
            </div>
          </div>

          {/* Usage Progress Bar */}
          <div className="mt-4">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-blue-100">Coverage Utilization</span>
              <span>{usagePercent.toFixed(0)}%</span>
            </div>
            <div className="w-full bg-white/20 rounded-full h-3 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${usagePercent}%` }}
                transition={{ duration: 1, delay: 0.5 }}
                className="h-full bg-gradient-to-r from-yellow-300 to-green-300 rounded-full"
              ></motion.div>
            </div>
          </div>
        </div>
      </div>

      {/* Claims Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Claims List */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-lg text-gray-900">{t.recentClaims}</h3>
          {claims.map((claim) => (
            <motion.div
              key={claim.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.02, x: 5 }}
              onClick={() => setSelectedClaim(claim)}
              className={`bg-white border-2 rounded-xl p-4 cursor-pointer transition-all ${
                selectedClaim?.id === claim.id
                  ? 'border-blue-500 shadow-lg'
                  : 'border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="text-gray-900">{claim.claimNumber}</h4>
                    <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full border ${getStatusColor(claim.status)}`}>
                      {getStatusIcon(claim.status)}
                      {t[claim.status as keyof typeof t]}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{getTypeLabel(claim.type)}</p>
                </div>
                <div className="text-right">
                  <p className="text-xl text-gray-900">₹{claim.amount.toLocaleString()}</p>
                  {claim.approvedAmount && (
                    <p className="text-sm text-green-600">₹{claim.approvedAmount.toLocaleString()} approved</p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  {claim.date}
                </div>
                <div className="flex items-center gap-1">
                  <Building className="w-4 h-4" />
                  {claim.provider}
                </div>
                <div className="flex items-center gap-1">
                  <FileText className="w-4 h-4" />
                  {claim.documents.length} docs
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Claim Details Sidebar */}
        <div className="lg:col-span-1">
          {selectedClaim ? (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white border border-gray-200 rounded-xl p-6 sticky top-6 space-y-4"
            >
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-lg text-gray-900">{t.viewDetails}</h4>
                <button onClick={() => setSelectedClaim(null)}>
                  <X className="w-5 h-5 text-gray-400 hover:text-gray-600" />
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{t.claimStatus}</p>
                  <span className={`inline-flex items-center gap-1 text-sm px-3 py-1 rounded-full border ${getStatusColor(selectedClaim.status)}`}>
                    {getStatusIcon(selectedClaim.status)}
                    {t[selectedClaim.status as keyof typeof t]}
                  </span>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-1">{t.claimAmount}</p>
                  <p className="text-2xl text-gray-900">₹{selectedClaim.amount.toLocaleString()}</p>
                </div>

                {selectedClaim.approvedAmount && (
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{t.approvedAmount}</p>
                    <p className="text-xl text-green-600">₹{selectedClaim.approvedAmount.toLocaleString()}</p>
                  </div>
                )}

                <div>
                  <p className="text-sm text-gray-600 mb-1">{t.claimDate}</p>
                  <p className="text-gray-900">{selectedClaim.date}</p>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-1">{t.provider}</p>
                  <p className="text-gray-900">{selectedClaim.provider}</p>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-2">{t.documents}</p>
                  <div className="space-y-2">
                    {selectedClaim.documents.map((doc, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between p-2 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-gray-600" />
                          <span className="text-sm text-gray-900">{doc}</span>
                        </div>
                        <div className="flex gap-1">
                          <button className="p-1 hover:bg-gray-200 rounded">
                            <Eye className="w-4 h-4 text-gray-600" />
                          </button>
                          <button className="p-1 hover:bg-gray-200 rounded">
                            <Download className="w-4 h-4 text-gray-600" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {selectedClaim.remarks && (
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{t.remarks}</p>
                    <p className="text-sm text-gray-900 bg-gray-50 p-3 rounded-lg">
                      {selectedClaim.remarks}
                    </p>
                  </div>
                )}
              </div>
            </motion.div>
          ) : (
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-8 text-center sticky top-6">
              <Shield className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600">Select a claim to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
