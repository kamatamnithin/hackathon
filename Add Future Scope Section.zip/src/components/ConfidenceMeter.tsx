import { Progress } from './ui/progress';

interface ConfidenceMeterProps {
  value: number;
  label: string;
  riskLevel: 'low' | 'medium' | 'high';
}

export function ConfidenceMeter({ value, label, riskLevel }: ConfidenceMeterProps) {
  const getColor = () => {
    switch (riskLevel) {
      case 'low': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'high': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getRiskText = () => {
    switch (riskLevel) {
      case 'low': return 'Low Risk';
      case 'medium': return 'Moderate Risk';
      case 'high': return 'High Risk';
      default: return 'Unknown';
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-gray-700">{label}</span>
        <span className={`px-3 py-1 rounded-full text-white ${getColor()}`}>
          {value}% - {getRiskText()}
        </span>
      </div>
      <div className="relative h-3 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className={`h-full ${getColor()} transition-all duration-500`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}
