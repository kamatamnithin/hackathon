import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Bell, Clock, AlertCircle, CheckCircle } from 'lucide-react';
import { Badge } from './ui/badge';

interface Notification {
  id: string;
  type: 'alert' | 'reminder' | 'info' | 'success';
  title: string;
  message: string;
  time: string;
  read: boolean;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'alert',
    title: 'High Risk Alert',
    message: 'Patient John Doe shows elevated cardiovascular risk (78%). Immediate consultation recommended.',
    time: '5 min ago',
    read: false
  },
  {
    id: '2',
    type: 'reminder',
    title: 'Medication Reminder',
    message: 'Time to take your morning medication - Metformin 500mg',
    time: '1 hour ago',
    read: false
  },
  {
    id: '3',
    type: 'success',
    title: 'Lab Results Ready',
    message: 'Blood test results for Patient Sarah Smith are now available for review.',
    time: '2 hours ago',
    read: true
  },
  {
    id: '4',
    type: 'info',
    title: 'Checkup Reminder',
    message: 'Your quarterly health checkup is scheduled for Nov 5, 2025 at 10:00 AM',
    time: '1 day ago',
    read: true
  }
];

export function NotificationPanel() {
  const getIcon = (type: string) => {
    switch (type) {
      case 'alert': return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'reminder': return <Clock className="w-5 h-5 text-blue-500" />;
      case 'success': return <CheckCircle className="w-5 h-5 text-green-500" />;
      default: return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  const unreadCount = mockNotifications.filter(n => !n.read).length;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5" />
          <CardTitle>Notifications</CardTitle>
        </div>
        {unreadCount > 0 && (
          <Badge variant="destructive">{unreadCount} new</Badge>
        )}
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {mockNotifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-3 rounded-lg border transition-colors ${
                notification.read 
                  ? 'bg-white border-gray-200' 
                  : 'bg-blue-50 border-blue-200'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  {getIcon(notification.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <p className="text-sm text-gray-900">{notification.title}</p>
                    <span className="text-xs text-gray-500 whitespace-nowrap">{notification.time}</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
