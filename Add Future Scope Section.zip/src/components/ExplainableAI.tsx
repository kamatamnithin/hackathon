import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Info } from 'lucide-react';

interface ExplainableAIProps {
  modelType: string;
  patientName: string;
}

export function ExplainableAI({ modelType, patientName }: ExplainableAIProps) {
  // SHAP-like feature importance visualization
  const featureImportance = [
    { feature: 'Age', impact: 0.34, direction: 'increases' },
    { feature: 'Blood Pressure', impact: 0.28, direction: 'increases' },
    { feature: 'Cholesterol', impact: 0.22, direction: 'increases' },
    { feature: 'BMI', impact: 0.18, direction: 'increases' },
    { feature: 'Exercise Frequency', impact: -0.15, direction: 'decreases' },
    { feature: 'Diet Quality', impact: -0.12, direction: 'decreases' },
  ];

  const chartData = featureImportance.map(f => ({
    feature: f.feature,
    impact: Math.abs(f.impact * 100),
    fill: f.impact > 0 ? '#ef4444' : '#10b981'
  }));

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Info className="w-5 h-5 text-blue-500" />
          <div>
            <CardTitle>AI Explainability Dashboard</CardTitle>
            <CardDescription>
              SHAP analysis for {patientName}'s {modelType} prediction
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-sm text-blue-900">
            This visualization shows which parameters contributed most to the disease prediction.
            Red bars indicate factors that increase risk, green bars decrease risk.
          </p>
        </div>

        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis type="number" label={{ value: 'Impact %', position: 'bottom' }} />
            <YAxis type="category" dataKey="feature" width={120} />
            <Tooltip />
            <Bar dataKey="impact" radius={[0, 8, 8, 0]}>
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.fill} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>

        <div className="space-y-2">
          <p className="text-sm text-gray-700">Top Contributing Factors:</p>
          <div className="space-y-2">
            {featureImportance.slice(0, 3).map((item, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <span className="text-sm">{item.feature}</span>
                <span className={`text-sm ${item.impact > 0 ? 'text-red-600' : 'text-green-600'}`}>
                  {item.impact > 0 ? '+' : ''}{(item.impact * 100).toFixed(1)}% {item.direction} risk
                </span>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
