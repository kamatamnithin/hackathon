import { useState } from 'react';
import { motion } from 'motion/react';
import { 
  FileText, Upload, Download, Eye, Trash2, Calendar, 
  User, Heart, Activity, FileCheck, Plus, Search 
} from 'lucide-react';

interface MedicalDocument {
  id: string;
  name: string;
  type: 'prescription' | 'lab_report' | 'scan' | 'insurance' | 'other';
  date: string;
  doctor: string;
  fileSize: string;
  aiAnalysis?: {
    summary: string;
    keyFindings: string[];
    riskLevel: 'low' | 'medium' | 'high';
  };
}

interface EHRSystemProps {
  language: 'en' | 'hi' | 'te';
  userType: 'patient' | 'doctor';
}

export function EHRSystem({ language, userType }: EHRSystemProps) {
  const [documents, setDocuments] = useState<MedicalDocument[]>([
    {
      id: '1',
      name: 'Blood Test Results',
      type: 'lab_report',
      date: '2025-10-28',
      doctor: 'Dr. Sarah Johnson',
      fileSize: '2.4 MB',
      aiAnalysis: {
        summary: 'Blood glucose levels elevated. HbA1c at 6.8% indicates pre-diabetic condition.',
        keyFindings: ['High blood glucose', 'Elevated HbA1c', 'Low vitamin D'],
        riskLevel: 'medium'
      }
    },
    {
      id: '2',
      name: 'ECG Report',
      type: 'scan',
      date: '2025-10-25',
      doctor: 'Dr. Michael Chen',
      fileSize: '1.8 MB',
      aiAnalysis: {
        summary: 'Normal sinus rhythm detected. No significant abnormalities.',
        keyFindings: ['Normal heart rate', 'Regular rhythm', 'No ST changes'],
        riskLevel: 'low'
      }
    },
    {
      id: '3',
      name: 'Diabetes Medication',
      type: 'prescription',
      date: '2025-10-20',
      doctor: 'Dr. Priya Sharma',
      fileSize: '0.5 MB'
    },
    {
      id: '4',
      name: 'Health Insurance Card',
      type: 'insurance',
      date: '2025-01-15',
      doctor: 'N/A',
      fileSize: '0.3 MB'
    }
  ]);

  const [selectedDoc, setSelectedDoc] = useState<MedicalDocument | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const translations = {
    en: {
      title: 'Electronic Health Records',
      upload: 'Upload Document',
      search: 'Search documents...',
      allDocuments: 'All Documents',
      prescriptions: 'Prescriptions',
      labReports: 'Lab Reports',
      scans: 'Medical Scans',
      insurance: 'Insurance',
      documentName: 'Document Name',
      type: 'Type',
      date: 'Date',
      doctor: 'Doctor',
      actions: 'Actions',
      view: 'View',
      download: 'Download',
      delete: 'Delete',
      aiAnalysis: 'AI Analysis',
      summary: 'Summary',
      keyFindings: 'Key Findings',
      riskLevel: 'Risk Level',
      low: 'Low Risk',
      medium: 'Medium Risk',
      high: 'High Risk',
      abdmSync: 'Sync with ABDM',
      shareWithDoctor: 'Share with Doctor'
    },
    hi: {
      title: 'इलेक्ट्रॉनिक स्वास्थ्य रिकॉर्ड',
      upload: 'दस्तावेज़ अपलोड करें',
      search: 'दस्तावेज़ खोजें...',
      allDocuments: 'सभी दस्तावेज़',
      prescriptions: 'प्रिस्क्रिप्शन',
      labReports: 'लैब रिपोर्ट',
      scans: 'मेडिकल स्कैन',
      insurance: 'बीमा',
      documentName: 'दस्तावेज़ का नाम',
      type: 'प्रकार',
      date: 'तारीख',
      doctor: 'डॉक्टर',
      actions: 'कार्रवाई',
      view: 'देखें',
      download: 'डाउनलोड',
      delete: 'हटाएं',
      aiAnalysis: 'AI विश्लेषण',
      summary: 'सारांश',
      keyFindings: 'मुख्य निष्कर्ष',
      riskLevel: 'जोखिम स्तर',
      low: 'कम जोखिम',
      medium: 'मध्यम जोखिम',
      high: 'उच्च जोखिम',
      abdmSync: 'ABDM के साथ सिंक करें',
      shareWithDoctor: 'डॉक्टर के साथ साझा करें'
    },
    te: {
      title: 'ఎలక్ట్రానిక్ హెల్త్ రికార్డులు',
      upload: 'డాక్యుమెంట్ అప్‌లోడ్ చేయండి',
      search: 'డాక్యుమెంట్‌లను శోధించండి...',
      allDocuments: 'అన్ని డాక్యుమెంట్‌లు',
      prescriptions: 'ప్రిస్క్రిప్షన్‌లు',
      labReports: 'ల్యాబ్ రిపోర్ట్‌లు',
      scans: 'మెడికల్ స్కాన్‌లు',
      insurance: 'బీమా',
      documentName: 'డాక్యుమెంట్ పేరు',
      type: 'రకం',
      date: 'తేదీ',
      doctor: 'వైద్యుడు',
      actions: 'చర్యలు',
      view: 'వీక్షించండి',
      download: 'డౌన్‌లోడ్',
      delete: 'తొలగించు',
      aiAnalysis: 'AI విశ్లేషణ',
      summary: 'సారాంశం',
      keyFindings: 'ముఖ్య అన్వేషణలు',
      riskLevel: 'ప్రమాద స్థాయి',
      low: 'తక్కువ ప్రమాదం',
      medium: 'మధ్యస్థ ప్రమాదం',
      high: 'అధిక ప్రమాదం',
      abdmSync: 'ABDMతో సింక్ చేయండి',
      shareWithDoctor: 'వైద్యునితో భాగస్వామ్యం చేయండి'
    }
  };

  const t = translations[language];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'prescription': return FileText;
      case 'lab_report': return Activity;
      case 'scan': return Heart;
      case 'insurance': return FileCheck;
      default: return FileText;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'prescription': return 'bg-blue-100 text-blue-600';
      case 'lab_report': return 'bg-green-100 text-green-600';
      case 'scan': return 'bg-purple-100 text-purple-600';
      case 'insurance': return 'bg-orange-100 text-orange-600';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  const getRiskBadge = (level: string) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-700';
      case 'medium': return 'bg-yellow-100 text-yellow-700';
      case 'high': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const filteredDocuments = documents.filter(doc =>
    doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.doctor.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
            <FileText className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl text-gray-900">{t.title}</h2>
            <p className="text-gray-600 text-sm">Powered by ABDM Integration</p>
          </div>
        </div>
        <div className="flex gap-3">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors"
          >
            <FileCheck className="w-5 h-5" />
            {t.abdmSync}
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:shadow-lg transition-all"
          >
            <Upload className="w-5 h-5" />
            {t.upload}
          </motion.button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder={t.search}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Documents List */}
        <div className="lg:col-span-2 space-y-3">
          {filteredDocuments.map((doc) => {
            const IconComponent = getTypeIcon(doc.type);
            return (
              <motion.div
                key={doc.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ scale: 1.02, x: 5 }}
                onClick={() => setSelectedDoc(doc)}
                className={`bg-white border-2 rounded-xl p-4 cursor-pointer transition-all ${
                  selectedDoc?.id === doc.id ? 'border-blue-500 shadow-lg' : 'border-gray-200 hover:border-blue-300'
                }`}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getTypeColor(doc.type)}`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-gray-900 mb-1 truncate">{doc.name}</h3>
                    <div className="flex items-center gap-3 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {doc.date}
                      </div>
                      <div className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        {doc.doctor}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs text-gray-500">{doc.fileSize}</span>
                      {doc.aiAnalysis && (
                        <span className={`text-xs px-2 py-1 rounded-full ${getRiskBadge(doc.aiAnalysis.riskLevel)}`}>
                          AI Analyzed
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <Eye className="w-5 h-5 text-gray-600" />
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                      <Download className="w-5 h-5 text-gray-600" />
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* AI Analysis Panel */}
        <div className="lg:col-span-1">
          {selectedDoc?.aiAnalysis ? (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gradient-to-br from-blue-50 to-purple-50 border border-blue-200 rounded-xl p-6 sticky top-6"
            >
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-lg bg-blue-500 flex items-center justify-center">
                  <Activity className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-lg text-gray-900">{t.aiAnalysis}</h3>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{t.summary}</p>
                  <p className="text-gray-900">{selectedDoc.aiAnalysis.summary}</p>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-2">{t.keyFindings}</p>
                  <div className="space-y-2">
                    {selectedDoc.aiAnalysis.keyFindings.map((finding, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2"></div>
                        <p className="text-gray-900 text-sm">{finding}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <p className="text-sm text-gray-600 mb-2">{t.riskLevel}</p>
                  <span className={`inline-block px-3 py-1 rounded-full ${getRiskBadge(selectedDoc.aiAnalysis.riskLevel)}`}>
                    {selectedDoc.aiAnalysis.riskLevel === 'low' ? t.low : 
                     selectedDoc.aiAnalysis.riskLevel === 'medium' ? t.medium : t.high}
                  </span>
                </div>
              </div>

              {userType === 'patient' && (
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full mt-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl shadow-lg hover:shadow-xl transition-all"
                >
                  {t.shareWithDoctor}
                </motion.button>
              )}
            </motion.div>
          ) : (
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-6 text-center sticky top-6">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600">Select a document to view AI analysis</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
