import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Mail, Lock, Phone, Calendar, Shield, Eye, EyeOff, 
  UserPlus, LogIn, X, Stethoscope, MapPin, Building, CreditCard
} from 'lucide-react';

interface AuthModalProps {
  portalType: 'patient' | 'doctor';
  onLogin: (type: 'patient' | 'doctor', userData: any) => void;
  onClose: () => void;
  language: 'en' | 'hi' | 'te';
}

export function AuthModal({ portalType, onLogin, onClose, language }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    phone: '',
    dateOfBirth: '',
    address: '',
    medicalLicense: '',
    specialization: '',
    hospitalName: '',
    experience: '',
    bloodGroup: '',
    emergencyContact: ''
  });

  const translations = {
    en: {
      patient: {
        login: 'Patient Sign In',
        register: 'Create Patient Account',
        subtitle: 'Access your health records and AI predictions'
      },
      doctor: {
        login: 'Doctor Sign In',
        register: 'Create Doctor Account',
        subtitle: 'Manage patients and view analytics'
      },
      email: 'Email Address',
      password: 'Password',
      fullName: 'Full Name',
      phone: 'Phone Number',
      dateOfBirth: 'Date of Birth',
      address: 'Address',
      bloodGroup: 'Blood Group',
      emergencyContact: 'Emergency Contact',
      medicalLicense: 'Medical License Number',
      specialization: 'Specialization',
      hospitalName: 'Hospital/Clinic Name',
      experience: 'Years of Experience',
      loginButton: 'Sign In',
      registerButton: 'Create Account',
      switchToRegister: "Don't have an account? Sign up",
      switchToLogin: 'Already have an account? Sign in',
      demoNote: 'Demo Mode: Any credentials work for testing',
      secureAuth: 'Secure Authentication with ABDM'
    },
    hi: {
      patient: {
        login: 'रोगी साइन इन',
        register: 'रोगी खाता बनाएं',
        subtitle: 'अपने स्वास्थ्य रिकॉर्ड और AI भविष्यवाणियां देखें'
      },
      doctor: {
        login: 'डॉक्टर साइन इन',
        register: 'डॉक्टर खाता बनाएं',
        subtitle: 'रोगियों का प्रबंधन करें और विश्लेषण देखें'
      },
      email: 'ईमेल पता',
      password: 'पासवर्ड',
      fullName: 'पूरा नाम',
      phone: 'फोन नंबर',
      dateOfBirth: 'जन्म तिथि',
      address: 'पता',
      bloodGroup: 'रक्त समूह',
      emergencyContact: 'आपातकालीन संपर्क',
      medicalLicense: 'मेडिकल लाइसेंस नंबर',
      specialization: 'विशेषज्ञता',
      hospitalName: 'अस्पताल/क्लिनिक नाम',
      experience: 'अनुभव के वर्ष',
      loginButton: 'साइन इन करें',
      registerButton: 'खाता बनाएं',
      switchToRegister: 'खाता नहीं है? साइन अप करें',
      switchToLogin: 'पहले से खाता है? साइन इन करें',
      demoNote: 'डेमो मोड: परीक्षण के लिए कोई भी क्रेडेंशियल काम करता है',
      secureAuth: 'ABDM के साथ सुरक्षित प्रमाणीकरण'
    },
    te: {
      patient: {
        login: 'రోగి సైన్ ఇన్',
        register: 'రోగి ఖాతా సృష్టించండి',
        subtitle: 'మీ ఆరోగ్య రికార్డులు మరియు AI అంచనాలను యాక్సెస్ చేయండి'
      },
      doctor: {
        login: 'వైద్యుడు సైన్ ఇన్',
        register: 'వైద్యుడు ఖాతా సృష్టించండి',
        subtitle: 'రోగులను నిర్వహించండి మరియు విశ్లేషణలను చూడండి'
      },
      email: 'ఇమెయిల్ చిరునామా',
      password: 'పాస్‌వర్డ్',
      fullName: 'పూర్తి పేరు',
      phone: 'ఫోన్ నంబర్',
      dateOfBirth: 'పుట్టిన తేదీ',
      address: 'చిరునామా',
      bloodGroup: 'బ్లడ్ గ్రూప్',
      emergencyContact: 'అత్యవసర సంప్రదింపు',
      medicalLicense: 'మెడికల్ లైసెన్స్ నంబర్',
      specialization: 'ప్రత్యేకత',
      hospitalName: 'ఆసుపత్రి/క్లినిక్ పేరు',
      experience: 'అనుభవం సంవత్సరాలు',
      loginButton: 'సైన్ ఇన్',
      registerButton: 'ఖాతా సృష్టించండి',
      switchToRegister: 'ఖాతా లేదా? సైన్ అప్ చేయండి',
      switchToLogin: 'ఇప్పటికే ఖాతా ఉందా? సైన్ ఇన్ చేయండి',
      demoNote: 'డెమో మోడ్: పరీక్ష కోసం ఏదైనా ఆధారాలు పనిచేస్తాయి',
      secureAuth: 'ABDMతో సురక్షిత ప్రామాణీకరణ'
    }
  };

  const t = translations[language];
  const portalText = t[portalType];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Demo mode - simulate successful authentication
    onLogin(portalType, {
      name: formData.fullName || 'Demo User',
      email: formData.email || `demo@${portalType}.com`,
      userType: portalType,
      ...formData
    });
  };

  const specializations = [
    'Cardiology',
    'Endocrinology', 
    'Oncology',
    'Neurology',
    'Pediatrics',
    'Orthopedics',
    'Dermatology',
    'General Medicine'
  ];

  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

  return (
    <div className="relative">
      {/* Glow Effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-3xl blur-2xl"></div>
      
      {/* Modal Content */}
      <div className="relative bg-white/95 backdrop-blur-2xl rounded-3xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className={`p-6 bg-gradient-to-r ${
          portalType === 'patient' 
            ? 'from-blue-500 to-blue-600' 
            : 'from-purple-500 to-purple-600'
        }`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-xl flex items-center justify-center">
                {portalType === 'patient' ? (
                  <User className="w-6 h-6 text-white" />
                ) : (
                  <Stethoscope className="w-6 h-6 text-white" />
                )}
              </div>
              <div>
                <h2 className="text-2xl text-white">
                  {isLogin ? portalText.login : portalText.register}
                </h2>
                <p className="text-white/80 text-sm">{portalText.subtitle}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-xl bg-white/20 hover:bg-white/30 flex items-center justify-center transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          <AnimatePresence mode="wait">
            {!isLogin && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-4"
              >
                {/* Full Name */}
                <div>
                  <label className="block text-gray-700 text-sm mb-2">{t.fullName}</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      placeholder={t.fullName}
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-gray-700 text-sm mb-2">{t.phone}</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="tel"
                      placeholder={t.phone}
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                {/* Date of Birth */}
                <div>
                  <label className="block text-gray-700 text-sm mb-2">{t.dateOfBirth}</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                      className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
                    />
                  </div>
                </div>

                {portalType === 'patient' ? (
                  <>
                    {/* Blood Group */}
                    <div>
                      <label className="block text-gray-700 text-sm mb-2">{t.bloodGroup}</label>
                      <div className="relative">
                        <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <select
                          value={formData.bloodGroup}
                          onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
                        >
                          <option value="">{t.bloodGroup}</option>
                          {bloodGroups.map(group => (
                            <option key={group} value={group}>{group}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Emergency Contact */}
                    <div>
                      <label className="block text-gray-700 text-sm mb-2">{t.emergencyContact}</label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="tel"
                          placeholder={t.emergencyContact}
                          value={formData.emergencyContact}
                          onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
                        />
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Medical License */}
                    <div>
                      <label className="block text-gray-700 text-sm mb-2">{t.medicalLicense}</label>
                      <div className="relative">
                        <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          placeholder={t.medicalLicense}
                          value={formData.medicalLicense}
                          onChange={(e) => setFormData({ ...formData, medicalLicense: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
                        />
                      </div>
                    </div>

                    {/* Specialization */}
                    <div>
                      <label className="block text-gray-700 text-sm mb-2">{t.specialization}</label>
                      <div className="relative">
                        <Stethoscope className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <select
                          value={formData.specialization}
                          onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
                        >
                          <option value="">{t.specialization}</option>
                          {specializations.map(spec => (
                            <option key={spec} value={spec}>{spec}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Hospital Name */}
                    <div>
                      <label className="block text-gray-700 text-sm mb-2">{t.hospitalName}</label>
                      <div className="relative">
                        <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="text"
                          placeholder={t.hospitalName}
                          value={formData.hospitalName}
                          onChange={(e) => setFormData({ ...formData, hospitalName: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
                        />
                      </div>
                    </div>

                    {/* Experience */}
                    <div>
                      <label className="block text-gray-700 text-sm mb-2">{t.experience}</label>
                      <div className="relative">
                        <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                          type="number"
                          placeholder={t.experience}
                          value={formData.experience}
                          onChange={(e) => setFormData({ ...formData, experience: e.target.value })}
                          className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
                        />
                      </div>
                    </div>
                  </>
                )}

                {/* Address */}
                <div>
                  <label className="block text-gray-700 text-sm mb-2">{t.address}</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <textarea
                      placeholder={t.address}
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      rows={2}
                      className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all resize-none"
                    />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Email */}
          <div>
            <label className="block text-gray-700 text-sm mb-2">{t.email}</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="email"
                placeholder={t.email}
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-gray-700 text-sm mb-2">{t.password}</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder={t.password}
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full pl-12 pr-12 py-3 bg-gray-50 border border-gray-200 rounded-xl text-gray-900 placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            className={`w-full py-3 bg-gradient-to-r ${
              portalType === 'patient'
                ? 'from-blue-500 to-blue-600'
                : 'from-purple-500 to-purple-600'
            } text-white rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2`}
          >
            {isLogin ? <LogIn className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
            {isLogin ? t.loginButton : t.registerButton}
          </motion.button>

          {/* Toggle Auth Mode */}
          <button
            type="button"
            onClick={() => setIsLogin(!isLogin)}
            className="w-full text-center text-gray-600 hover:text-gray-900 transition-colors text-sm"
          >
            {isLogin ? t.switchToRegister : t.switchToLogin}
          </button>

          {/* Demo Note */}
          <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-xl">
            <p className="text-yellow-700 text-sm text-center flex items-center justify-center gap-2">
              <Shield className="w-4 h-4" />
              {t.demoNote}
            </p>
          </div>

          {/* ABDM Badge */}
          <div className="text-center">
            <p className="text-gray-500 text-xs">{t.secureAuth}</p>
          </div>
        </form>
      </div>
    </div>
  );
}
