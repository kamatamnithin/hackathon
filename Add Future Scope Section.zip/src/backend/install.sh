#!/bin/bash

# ============================================
# HealthAI Backend Installation Script
# ============================================

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color

echo -e "${MAGENTA}"
echo "╔═══════════════════════════════════════════╗"
echo "║   HealthAI Backend Installation Script   ║"
echo "╚═══════════════════════════════════════════╝"
echo -e "${NC}"

# Check if we're in the backend directory
if [ ! -f "package.json" ]; then
    echo -e "${RED}❌ Error: Please run this script from the backend directory${NC}"
    echo -e "${YELLOW}   cd backend && bash install.sh${NC}"
    exit 1
fi

# Step 1: Check Node.js
echo -e "\n${BLUE}📦 Step 1: Checking Node.js...${NC}"
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v)
    echo -e "${GREEN}✅ Node.js is installed: ${NODE_VERSION}${NC}"
else
    echo -e "${RED}❌ Node.js is not installed${NC}"
    echo -e "${YELLOW}   Please install Node.js v16 or higher from https://nodejs.org${NC}"
    exit 1
fi

# Step 2: Check npm
echo -e "\n${BLUE}📦 Step 2: Checking npm...${NC}"
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm -v)
    echo -e "${GREEN}✅ npm is installed: ${NPM_VERSION}${NC}"
else
    echo -e "${RED}❌ npm is not installed${NC}"
    exit 1
fi

# Step 3: Check MySQL
echo -e "\n${BLUE}🗄️  Step 3: Checking MySQL...${NC}"
if command -v mysql &> /dev/null; then
    MYSQL_VERSION=$(mysql --version)
    echo -e "${GREEN}✅ MySQL is installed: ${MYSQL_VERSION}${NC}"
else
    echo -e "${YELLOW}⚠️  MySQL not found in PATH${NC}"
    echo -e "${YELLOW}   Trying to check if MySQL service is running...${NC}"
fi

# Step 4: Install npm dependencies
echo -e "\n${BLUE}📚 Step 4: Installing npm dependencies...${NC}"
npm install
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Dependencies installed successfully${NC}"
else
    echo -e "${RED}❌ Failed to install dependencies${NC}"
    exit 1
fi

# Step 5: Check .env file
echo -e "\n${BLUE}⚙️  Step 5: Checking environment configuration...${NC}"
if [ -f ".env" ]; then
    echo -e "${GREEN}✅ .env file exists${NC}"
else
    echo -e "${YELLOW}⚠️  .env file not found${NC}"
    if [ -f ".env.example" ]; then
        echo -e "${YELLOW}   Creating .env from .env.example...${NC}"
        cp .env.example .env
        echo -e "${GREEN}✅ .env file created${NC}"
        echo -e "${YELLOW}   ⚠️  Please update the credentials in .env file${NC}"
    fi
fi

# Step 6: Test MySQL connection
echo -e "\n${BLUE}🔌 Step 6: Testing MySQL connection...${NC}"
mysql -u UDHAY -pTeja@7586 -e "SELECT 1;" 2>/dev/null
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ MySQL connection successful${NC}"
else
    echo -e "${YELLOW}⚠️  Could not connect to MySQL with provided credentials${NC}"
    echo -e "${YELLOW}   This might be normal if MySQL requires a different authentication method${NC}"
    echo -e "${YELLOW}   The setup script will try again with better error handling${NC}"
fi

# Step 7: Setup database
echo -e "\n${BLUE}🗄️  Step 7: Setting up database...${NC}"
echo -e "${YELLOW}   This will create the database and all tables...${NC}"
read -p "   Do you want to run the database setup now? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    npm run setup-db
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ Database setup completed${NC}"
    else
        echo -e "${RED}❌ Database setup failed${NC}"
        echo -e "${YELLOW}   You can run it manually later with: npm run setup-db${NC}"
    fi
else
    echo -e "${YELLOW}⏭️  Skipping database setup${NC}"
    echo -e "${YELLOW}   You can run it later with: npm run setup-db${NC}"
fi

# Step 8: Summary
echo -e "\n${MAGENTA}"
echo "╔═══════════════════════════════════════════╗"
echo "║       Installation Complete! 🎉           ║"
echo "╚═══════════════════════════════════════════╝"
echo -e "${NC}"

echo -e "${GREEN}✅ Backend installation successful!${NC}\n"

echo -e "${BLUE}📋 Next Steps:${NC}"
echo -e "   1. Verify database credentials in .env file"
echo -e "   2. Run database setup: ${YELLOW}npm run setup-db${NC}"
echo -e "   3. Start the server: ${YELLOW}npm run dev${NC}"
echo -e "   4. Test the API: ${YELLOW}curl http://localhost:5000/health${NC}"
echo ""

echo -e "${BLUE}📚 Documentation:${NC}"
echo -e "   • Setup Guide: ../MYSQL_SETUP_GUIDE.md"
echo -e "   • Quick Reference: ../QUICK_REFERENCE.md"
echo -e "   • API Docs: README.md"
echo ""

echo -e "${BLUE}🔐 Demo Accounts (after setup):${NC}"
echo -e "   • Patient: patient@demo.com / patient123"
echo -e "   • Doctor: doctor@demo.com / doctor123"
echo ""

echo -e "${GREEN}Ready to transform healthcare! 🏥💙${NC}\n"
