const express = require('express');
const router = express.Router();
const { authenticateToken, isDoctor } = require('../middleware/auth');
const { promisePool } = require('../config/database');

// Get doctor profile
router.get('/profile', authenticateToken, isDoctor, async (req, res) => {
  try {
    const [profiles] = await promisePool.execute(
      'SELECT * FROM doctor_profiles WHERE user_id = ?',
      [req.user.userId]
    );
    res.json({ success: true, data: profiles[0] || null });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Update doctor profile
router.put('/profile', authenticateToken, isDoctor, async (req, res) => {
  try {
    const { fullName, phone, specialization, hospitalName, consultationFee } = req.body;
    await promisePool.execute(
      `UPDATE doctor_profiles SET 
       full_name = COALESCE(?, full_name),
       phone = COALESCE(?, phone),
       specialization = COALESCE(?, specialization),
       hospital_name = COALESCE(?, hospital_name),
       consultation_fee = COALESCE(?, consultation_fee)
       WHERE user_id = ?`,
      [fullName, phone, specialization, hospitalName, consultationFee, req.user.userId]
    );
    res.json({ success: true, message: 'Profile updated' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get doctor's patients
router.get('/patients', authenticateToken, isDoctor, async (req, res) => {
  try {
    const [doctor] = await promisePool.execute(
      'SELECT doctor_id FROM doctor_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const [patients] = await promisePool.execute(
      `SELECT DISTINCT p.*, COUNT(a.appointment_id) as total_appointments
       FROM patient_profiles p
       JOIN appointments a ON p.patient_id = a.patient_id
       WHERE a.doctor_id = ?
       GROUP BY p.patient_id
       ORDER BY a.appointment_date DESC`,
      [doctor[0].doctor_id]
    );

    res.json({ success: true, data: patients });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
