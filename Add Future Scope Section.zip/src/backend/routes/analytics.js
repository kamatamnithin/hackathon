const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { promisePool } = require('../config/database');

router.get('/disease-trends', authenticateToken, async (req, res) => {
  try {
    const [stats] = await promisePool.execute(
      'SELECT * FROM disease_statistics ORDER BY period_start DESC LIMIT 100'
    );
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/predictions-summary', authenticateToken, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );
    const [summary] = await promisePool.execute(
      `SELECT disease_type, COUNT(*) as count, AVG(confidence_score) as avg_confidence
       FROM ai_predictions
       WHERE patient_id = ?
       GROUP BY disease_type`,
      [profile[0].patient_id]
    );
    res.json({ success: true, data: summary });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
