const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { promisePool } = require('../config/database');

// Create new AI prediction
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { modelName, diseaseType, riskLevel, confidenceScore, predictionResult, inputParameters, explainabilityData, recommendations } = req.body;
    
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const [result] = await promisePool.execute(
      `INSERT INTO ai_predictions (patient_id, model_name, disease_type, risk_level, confidence_score, prediction_result, input_parameters, explainability_data, recommendations)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [profile[0].patient_id, modelName, diseaseType, riskLevel, confidenceScore, predictionResult, JSON.stringify(inputParameters), JSON.stringify(explainabilityData), recommendations]
    );

    res.status(201).json({ success: true, data: { predictionId: result.insertId } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get patient's predictions
router.get('/patient', authenticateToken, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const [predictions] = await promisePool.execute(
      'SELECT * FROM ai_predictions WHERE patient_id = ? ORDER BY prediction_date DESC',
      [profile[0].patient_id]
    );

    res.json({ success: true, data: predictions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get prediction by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const [predictions] = await promisePool.execute(
      'SELECT * FROM ai_predictions WHERE prediction_id = ?',
      [req.params.id]
    );

    if (predictions.length === 0) {
      return res.status(404).json({ success: false, message: 'Prediction not found' });
    }

    res.json({ success: true, data: predictions[0] });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
