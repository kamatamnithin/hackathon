const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { promisePool } = require('../config/database');

router.post('/alert', authenticateToken, async (req, res) => {
  try {
    const { latitude, longitude, address, alertType } = req.body;
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );
    const [result] = await promisePool.execute(
      'INSERT INTO emergency_alerts (patient_id, location_latitude, location_longitude, location_address, alert_type) VALUES (?, ?, ?, ?, ?)',
      [profile[0].patient_id, latitude, longitude, address, alertType]
    );
    res.status(201).json({ success: true, data: { alertId: result.insertId } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/alerts', authenticateToken, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );
    const [alerts] = await promisePool.execute(
      'SELECT * FROM emergency_alerts WHERE patient_id = ? ORDER BY created_at DESC',
      [profile[0].patient_id]
    );
    res.json({ success: true, data: alerts });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
