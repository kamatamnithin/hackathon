const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { promisePool } = require('../config/database');

// ============================================
// REGISTER - Create new user account
// ============================================
router.post('/register',
  [
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 6 }),
    body('userType').isIn(['patient', 'doctor']),
    body('fullName').trim().notEmpty(),
    body('phone').optional().trim()
  ],
  async (req, res) => {
    try {
      // Validate input
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }

      const { 
        email, password, userType, fullName, phone, dateOfBirth, 
        bloodGroup, emergencyContact, medicalLicense, specialization,
        hospitalName, experience, address
      } = req.body;

      // Check if user already exists
      const [existingUsers] = await promisePool.execute(
        'SELECT email FROM users WHERE email = ?',
        [email]
      );

      if (existingUsers.length > 0) {
        return res.status(409).json({ 
          success: false, 
          message: 'Email already registered' 
        });
      }

      // Hash password
      const passwordHash = await bcrypt.hash(password, 10);

      // Start transaction
      const connection = await promisePool.getConnection();
      await connection.beginTransaction();

      try {
        // Insert user
        const [userResult] = await connection.execute(
          'INSERT INTO users (email, password_hash, user_type) VALUES (?, ?, ?)',
          [email, passwordHash, userType]
        );

        const userId = userResult.insertId;

        // Insert profile based on user type
        if (userType === 'patient') {
          await connection.execute(
            `INSERT INTO patient_profiles 
            (user_id, full_name, phone, date_of_birth, blood_group, emergency_contact_phone, address) 
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [userId, fullName, phone, dateOfBirth, bloodGroup, emergencyContact, address]
          );
        } else if (userType === 'doctor') {
          await connection.execute(
            `INSERT INTO doctor_profiles 
            (user_id, full_name, phone, date_of_birth, medical_license_number, specialization, hospital_name, experience_years, address) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [userId, fullName, phone, dateOfBirth, medicalLicense || `ML${Date.now()}`, specialization, hospitalName, experience, address]
          );
        }

        await connection.commit();
        connection.release();

        // Generate JWT token
        const token = jwt.sign(
          { userId, email, userType },
          process.env.JWT_SECRET,
          { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
        );

        res.status(201).json({
          success: true,
          message: 'Registration successful',
          data: {
            token,
            user: {
              userId,
              email,
              userType,
              fullName
            }
          }
        });

      } catch (error) {
        await connection.rollback();
        connection.release();
        throw error;
      }

    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Registration failed',
        error: error.message 
      });
    }
  }
);

// ============================================
// LOGIN - Authenticate user
// ============================================
router.post('/login',
  [
    body('email').isEmail().normalizeEmail(),
    body('password').notEmpty()
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, errors: errors.array() });
      }

      const { email, password } = req.body;

      // Get user
      const [users] = await promisePool.execute(
        'SELECT user_id, email, password_hash, user_type, is_active FROM users WHERE email = ?',
        [email]
      );

      if (users.length === 0) {
        return res.status(401).json({ 
          success: false, 
          message: 'Invalid email or password' 
        });
      }

      const user = users[0];

      // Check if account is active
      if (!user.is_active) {
        return res.status(403).json({ 
          success: false, 
          message: 'Account is deactivated' 
        });
      }

      // Verify password
      const isPasswordValid = await bcrypt.compare(password, user.password_hash);

      if (!isPasswordValid) {
        return res.status(401).json({ 
          success: false, 
          message: 'Invalid email or password' 
        });
      }

      // Update last login
      await promisePool.execute(
        'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE user_id = ?',
        [user.user_id]
      );

      // Get profile data
      let profileData = {};
      if (user.user_type === 'patient') {
        const [profiles] = await promisePool.execute(
          'SELECT patient_id, full_name, phone FROM patient_profiles WHERE user_id = ?',
          [user.user_id]
        );
        profileData = profiles[0] || {};
      } else if (user.user_type === 'doctor') {
        const [profiles] = await promisePool.execute(
          'SELECT doctor_id, full_name, phone, specialization FROM doctor_profiles WHERE user_id = ?',
          [user.user_id]
        );
        profileData = profiles[0] || {};
      }

      // Generate JWT token
      const token = jwt.sign(
        { 
          userId: user.user_id, 
          email: user.email, 
          userType: user.user_type 
        },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
      );

      res.json({
        success: true,
        message: 'Login successful',
        data: {
          token,
          user: {
            userId: user.user_id,
            email: user.email,
            userType: user.user_type,
            ...profileData
          }
        }
      });

    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Login failed',
        error: error.message 
      });
    }
  }
);

// ============================================
// VERIFY TOKEN - Check if token is valid
// ============================================
router.get('/verify', async (req, res) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      return res.status(401).json({ 
        success: false, 
        message: 'No token provided' 
      });
    }

    jwt.verify(token, process.env.JWT_SECRET, async (err, decoded) => {
      if (err) {
        return res.status(403).json({ 
          success: false, 
          message: 'Invalid token' 
        });
      }

      // Get user data
      const [users] = await promisePool.execute(
        'SELECT user_id, email, user_type, is_active FROM users WHERE user_id = ?',
        [decoded.userId]
      );

      if (users.length === 0 || !users[0].is_active) {
        return res.status(404).json({ 
          success: false, 
          message: 'User not found' 
        });
      }

      res.json({
        success: true,
        data: {
          userId: decoded.userId,
          email: decoded.email,
          userType: decoded.userType
        }
      });
    });

  } catch (error) {
    console.error('Token verification error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Verification failed' 
    });
  }
});

module.exports = router;
