const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { promisePool } = require('../config/database');

// Get health records
router.get('/', authenticateToken, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const [records] = await promisePool.execute(
      'SELECT * FROM health_records WHERE patient_id = ? ORDER BY record_date DESC',
      [profile[0].patient_id]
    );

    res.json({ success: true, data: records });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Create health record
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { recordType, recordTitle, recordDescription, recordDate, fileUrl } = req.body;
    
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const [result] = await promisePool.execute(
      'INSERT INTO health_records (patient_id, record_type, record_title, record_description, record_date, file_url) VALUES (?, ?, ?, ?, ?, ?)',
      [profile[0].patient_id, recordType, recordTitle, recordDescription, recordDate, fileUrl]
    );

    res.status(201).json({ success: true, data: { recordId: result.insertId } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
