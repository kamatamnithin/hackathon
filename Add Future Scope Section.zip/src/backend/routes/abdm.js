const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { promisePool } = require('../config/database');

router.get('/consents', authenticateToken, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );
    const [consents] = await promisePool.execute(
      'SELECT * FROM abdm_consents WHERE patient_id = ? ORDER BY requested_at DESC',
      [profile[0].patient_id]
    );
    res.json({ success: true, data: consents });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/link-health-id', authenticateToken, async (req, res) => {
  try {
    const { healthId } = req.body;
    await promisePool.execute(
      'UPDATE patient_profiles SET abdm_health_id = ? WHERE user_id = ?',
      [healthId, req.user.userId]
    );
    res.json({ success: true, message: 'Health ID linked successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
