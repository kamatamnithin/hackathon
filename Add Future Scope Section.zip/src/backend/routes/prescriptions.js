const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { promisePool } = require('../config/database');

// Get prescriptions
router.get('/', authenticateToken, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const [prescriptions] = await promisePool.execute(
      `SELECT p.*, d.full_name as doctor_name, d.specialization 
       FROM prescriptions p
       JOIN doctor_profiles d ON p.doctor_id = d.doctor_id
       WHERE p.patient_id = ?
       ORDER BY p.prescription_date DESC`,
      [profile[0].patient_id]
    );

    res.json({ success: true, data: prescriptions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get prescription medications
router.get('/:id/medications', authenticateToken, async (req, res) => {
  try {
    const [medications] = await promisePool.execute(
      'SELECT * FROM prescription_medications WHERE prescription_id = ?',
      [req.params.id]
    );

    res.json({ success: true, data: medications });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
