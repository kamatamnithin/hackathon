const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { promisePool } = require('../config/database');

// Get IoT devices
router.get('/devices', authenticateToken, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const [devices] = await promisePool.execute(
      'SELECT * FROM iot_devices WHERE patient_id = ?',
      [profile[0].patient_id]
    );

    res.json({ success: true, data: devices });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get IoT readings
router.get('/readings', authenticateToken, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const limit = req.query.limit || 100;
    const [readings] = await promisePool.execute(
      'SELECT * FROM iot_readings WHERE patient_id = ? ORDER BY reading_timestamp DESC LIMIT ?',
      [profile[0].patient_id, parseInt(limit)]
    );

    res.json({ success: true, data: readings });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Add IoT reading
router.post('/readings', authenticateToken, async (req, res) => {
  try {
    const { deviceId, readingType, readingValue, unit } = req.body;
    
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const [result] = await promisePool.execute(
      'INSERT INTO iot_readings (device_id, patient_id, reading_type, reading_value, unit) VALUES (?, ?, ?, ?, ?)',
      [deviceId, profile[0].patient_id, readingType, readingValue, unit]
    );

    res.status(201).json({ success: true, data: { readingId: result.insertId } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
