const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { promisePool } = require('../config/database');

router.get('/', authenticateToken, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );
    const [claims] = await promisePool.execute(
      'SELECT * FROM insurance_claims WHERE patient_id = ? ORDER BY submitted_at DESC',
      [profile[0].patient_id]
    );
    res.json({ success: true, data: claims });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/', authenticateToken, async (req, res) => {
  try {
    const { policyNumber, insuranceProvider, claimType, claimAmount, treatmentDate, diagnosis } = req.body;
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );
    const [result] = await promisePool.execute(
      'INSERT INTO insurance_claims (patient_id, policy_number, insurance_provider, claim_type, claim_amount, claim_date, treatment_date, diagnosis) VALUES (?, ?, ?, ?, ?, CURDATE(), ?, ?)',
      [profile[0].patient_id, policyNumber, insuranceProvider, claimType, claimAmount, treatmentDate, diagnosis]
    );
    res.status(201).json({ success: true, data: { claimId: result.insertId } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
