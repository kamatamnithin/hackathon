const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const { promisePool } = require('../config/database');

// Get appointments
router.get('/', authenticateToken, async (req, res) => {
  try {
    let query, params;
    
    if (req.user.userType === 'patient') {
      const [profile] = await promisePool.execute(
        'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
        [req.user.userId]
      );
      query = `SELECT a.*, d.full_name as doctor_name, d.specialization 
               FROM appointments a
               JOIN doctor_profiles d ON a.doctor_id = d.doctor_id
               WHERE a.patient_id = ?
               ORDER BY a.appointment_date DESC, a.appointment_time DESC`;
      params = [profile[0].patient_id];
    } else {
      const [profile] = await promisePool.execute(
        'SELECT doctor_id FROM doctor_profiles WHERE user_id = ?',
        [req.user.userId]
      );
      query = `SELECT a.*, p.full_name as patient_name 
               FROM appointments a
               JOIN patient_profiles p ON a.patient_id = p.patient_id
               WHERE a.doctor_id = ?
               ORDER BY a.appointment_date DESC, a.appointment_time DESC`;
      params = [profile[0].doctor_id];
    }

    const [appointments] = await promisePool.execute(query, params);
    res.json({ success: true, data: appointments });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Create appointment
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { doctorId, appointmentDate, appointmentTime, appointmentType, chiefComplaint } = req.body;
    
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    const [result] = await promisePool.execute(
      'INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, appointment_type, chief_complaint) VALUES (?, ?, ?, ?, ?, ?)',
      [profile[0].patient_id, doctorId, appointmentDate, appointmentTime, appointmentType, chiefComplaint]
    );

    res.status(201).json({ success: true, data: { appointmentId: result.insertId } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
