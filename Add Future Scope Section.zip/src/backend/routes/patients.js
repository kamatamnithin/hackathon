const express = require('express');
const router = express.Router();
const { authenticateToken, isPatient } = require('../middleware/auth');
const { promisePool } = require('../config/database');

// Get patient profile
router.get('/profile', authenticateToken, isPatient, async (req, res) => {
  try {
    const [profiles] = await promisePool.execute(
      `SELECT p.*, u.email, u.created_at as registered_date
       FROM patient_profiles p
       JOIN users u ON p.user_id = u.user_id
       WHERE p.user_id = ?`,
      [req.user.userId]
    );

    if (profiles.length === 0) {
      return res.status(404).json({ success: false, message: 'Profile not found' });
    }

    res.json({ success: true, data: profiles[0] });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Update patient profile
router.put('/profile', authenticateToken, isPatient, async (req, res) => {
  try {
    const { fullName, phone, dateOfBirth, gender, bloodGroup, height, weight, address, city, state, pincode } = req.body;

    await promisePool.execute(
      `UPDATE patient_profiles SET 
       full_name = COALESCE(?, full_name),
       phone = COALESCE(?, phone),
       date_of_birth = COALESCE(?, date_of_birth),
       gender = COALESCE(?, gender),
       blood_group = COALESCE(?, blood_group),
       height_cm = COALESCE(?, height_cm),
       weight_kg = COALESCE(?, weight_kg),
       address = COALESCE(?, address),
       city = COALESCE(?, city),
       state = COALESCE(?, state),
       pincode = COALESCE(?, pincode)
       WHERE user_id = ?`,
      [fullName, phone, dateOfBirth, gender, bloodGroup, height, weight, address, city, state, pincode, req.user.userId]
    );

    res.json({ success: true, message: 'Profile updated successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get patient dashboard stats
router.get('/dashboard', authenticateToken, isPatient, async (req, res) => {
  try {
    const [profile] = await promisePool.execute(
      'SELECT patient_id FROM patient_profiles WHERE user_id = ?',
      [req.user.userId]
    );

    if (profile.length === 0) {
      return res.status(404).json({ success: false, message: 'Profile not found' });
    }

    const patientId = profile[0].patient_id;

    // Get counts
    const [predictions] = await promisePool.execute(
      'SELECT COUNT(*) as count FROM ai_predictions WHERE patient_id = ?',
      [patientId]
    );

    const [appointments] = await promisePool.execute(
      'SELECT COUNT(*) as count FROM appointments WHERE patient_id = ? AND status != "cancelled"',
      [patientId]
    );

    const [prescriptions] = await promisePool.execute(
      'SELECT COUNT(*) as count FROM prescriptions WHERE patient_id = ? AND is_active = TRUE',
      [patientId]
    );

    const [healthRecords] = await promisePool.execute(
      'SELECT COUNT(*) as count FROM health_records WHERE patient_id = ?',
      [patientId]
    );

    res.json({
      success: true,
      data: {
        totalPredictions: predictions[0].count,
        totalAppointments: appointments[0].count,
        activePrescriptions: prescriptions[0].count,
        healthRecords: healthRecords[0].count
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
