const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function setupDatabase() {
  console.log('🔧 HealthAI Database Setup Script\n');
  console.log('=====================================');

  let connection;

  try {
    // Connect to MySQL server (without database)
    console.log('📡 Connecting to MySQL server...');
    connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'UDHAY',
      password: process.env.DB_PASSWORD || 'Teja@7586',
      port: process.env.DB_PORT || 3306
    });

    console.log('✅ Connected to MySQL server');

    // Create database if it doesn't exist
    const dbName = process.env.DB_NAME || 'healthcare';
    console.log(`\n📊 Creating database: ${dbName}`);
    
    await connection.query(`CREATE DATABASE IF NOT EXISTS ${dbName}`);
    console.log(`✅ Database '${dbName}' created/verified`);

    // Use the database
    await connection.query(`USE ${dbName}`);
    console.log(`✅ Using database '${dbName}'`);

    // Read and execute schema file
    console.log('\n📄 Reading schema file...');
    const schemaPath = path.join(__dirname, '../database/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');

    // Split schema into individual statements
    const statements = schema
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0 && !stmt.startsWith('--'));

    console.log(`📝 Found ${statements.length} SQL statements to execute\n`);

    // Execute each statement
    for (let i = 0; i < statements.length; i++) {
      try {
        await connection.query(statements[i]);
        process.stdout.write(`\r⏳ Executing statements: ${i + 1}/${statements.length}`);
      } catch (error) {
        // Ignore errors for statements that might already exist
        if (!error.message.includes('already exists')) {
          console.error(`\n❌ Error in statement ${i + 1}:`, error.message);
        }
      }
    }

    console.log('\n✅ All statements executed successfully');

    // Verify tables
    console.log('\n🔍 Verifying tables...');
    const [tables] = await connection.query('SHOW TABLES');
    console.log(`✅ Found ${tables.length} tables:`);
    tables.forEach((table, index) => {
      const tableName = Object.values(table)[0];
      console.log(`   ${index + 1}. ${tableName}`);
    });

    // Create sample admin user (optional)
    console.log('\n👤 Creating sample users...');
    
    const bcrypt = require('bcryptjs');
    const patientPassword = await bcrypt.hash('patient123', 10);
    const doctorPassword = await bcrypt.hash('doctor123', 10);

    try {
      // Insert sample patient
      const [patientUser] = await connection.query(
        `INSERT INTO users (email, password_hash, user_type, email_verified) 
         VALUES ('patient@demo.com', ?, 'patient', TRUE)
         ON DUPLICATE KEY UPDATE email=email`,
        [patientPassword]
      );

      if (patientUser.insertId) {
        await connection.query(
          `INSERT INTO patient_profiles (user_id, full_name, phone, blood_group) 
           VALUES (?, 'Demo Patient', '1234567890', 'O+')`,
          [patientUser.insertId]
        );
        console.log('✅ Created demo patient: patient@demo.com / patient123');
      }

      // Insert sample doctor
      const [doctorUser] = await connection.query(
        `INSERT INTO users (email, password_hash, user_type, email_verified) 
         VALUES ('doctor@demo.com', ?, 'doctor', TRUE)
         ON DUPLICATE KEY UPDATE email=email`,
        [doctorPassword]
      );

      if (doctorUser.insertId) {
        await connection.query(
          `INSERT INTO doctor_profiles (user_id, full_name, phone, medical_license_number, specialization, hospital_name) 
           VALUES (?, 'Demo Doctor', '0987654321', ?, 'Cardiology', 'City Hospital')`,
          [doctorUser.insertId, `ML${Date.now()}`]
        );
        console.log('✅ Created demo doctor: doctor@demo.com / doctor123');
      }
    } catch (error) {
      if (error.code !== 'ER_DUP_ENTRY') {
        console.log('⚠️  Sample users might already exist');
      }
    }

    console.log('\n=====================================');
    console.log('🎉 Database setup completed successfully!');
    console.log('=====================================\n');
    console.log('📋 Summary:');
    console.log(`   - Database: ${dbName}`);
    console.log(`   - Tables: ${tables.length}`);
    console.log(`   - Host: ${process.env.DB_HOST || 'localhost'}`);
    console.log(`   - User: ${process.env.DB_USER || 'UDHAY'}`);
    console.log('\n🚀 You can now start the server with:');
    console.log('   npm start   or   npm run dev\n');
    console.log('🔐 Demo Accounts:');
    console.log('   Patient: patient@demo.com / patient123');
    console.log('   Doctor: doctor@demo.com / doctor123\n');

  } catch (error) {
    console.error('\n❌ Database setup failed:', error.message);
    console.error('\n📝 Please check:');
    console.error('   1. MySQL server is running');
    console.error('   2. Credentials in .env file are correct');
    console.error('   3. User has permission to create databases');
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
      console.log('🔌 Database connection closed\n');
    }
  }
}

// Run the setup
setupDatabase();
