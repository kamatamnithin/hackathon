#!/usr/bin/env node

/**
 * HealthAI API Test Script
 * Tests all major endpoints to ensure everything is working
 */

const http = require('http');

const API_BASE = 'http://localhost:5000';
let authToken = '';

// Colors for terminal output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

// Make API request
function makeRequest(path, method = 'GET', data = null, useAuth = false) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, API_BASE);
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json'
      }
    };

    if (useAuth && authToken) {
      options.headers['Authorization'] = `Bearer ${authToken}`;
    }

    const req = http.request(url, options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const response = JSON.parse(body);
          resolve({ status: res.statusCode, data: response });
        } catch (e) {
          resolve({ status: res.statusCode, data: body });
        }
      });
    });

    req.on('error', reject);

    if (data) {
      req.write(JSON.stringify(data));
    }

    req.end();
  });
}

// Test functions
async function testHealthCheck() {
  log('\n🔍 Testing Health Check...', 'blue');
  try {
    const response = await makeRequest('/health');
    if (response.status === 200 && response.data.status === 'ok') {
      log('✅ Health check passed', 'green');
      return true;
    } else {
      log('❌ Health check failed', 'red');
      return false;
    }
  } catch (error) {
    log(`❌ Health check error: ${error.message}`, 'red');
    return false;
  }
}

async function testRegistration() {
  log('\n🔍 Testing User Registration...', 'blue');
  try {
    const testUser = {
      email: `test${Date.now()}@example.com`,
      password: 'test123456',
      userType: 'patient',
      fullName: 'Test Patient',
      phone: '1234567890'
    };

    const response = await makeRequest('/api/auth/register', 'POST', testUser);
    
    if (response.status === 201 && response.data.success) {
      authToken = response.data.data.token;
      log('✅ Registration successful', 'green');
      log(`   Email: ${testUser.email}`, 'yellow');
      log(`   Token: ${authToken.substring(0, 20)}...`, 'yellow');
      return true;
    } else {
      log('❌ Registration failed', 'red');
      log(`   Response: ${JSON.stringify(response.data)}`, 'yellow');
      return false;
    }
  } catch (error) {
    log(`❌ Registration error: ${error.message}`, 'red');
    return false;
  }
}

async function testLogin() {
  log('\n🔍 Testing User Login...', 'blue');
  try {
    const credentials = {
      email: 'patient@demo.com',
      password: 'patient123'
    };

    const response = await makeRequest('/api/auth/login', 'POST', credentials);
    
    if (response.status === 200 && response.data.success) {
      authToken = response.data.data.token;
      log('✅ Login successful', 'green');
      log(`   User: ${response.data.data.user.email}`, 'yellow');
      return true;
    } else {
      log('❌ Login failed', 'red');
      return false;
    }
  } catch (error) {
    log(`❌ Login error: ${error.message}`, 'red');
    return false;
  }
}

async function testTokenVerification() {
  log('\n🔍 Testing Token Verification...', 'blue');
  try {
    const response = await makeRequest('/api/auth/verify', 'GET', null, true);
    
    if (response.status === 200 && response.data.success) {
      log('✅ Token verification successful', 'green');
      return true;
    } else {
      log('❌ Token verification failed', 'red');
      return false;
    }
  } catch (error) {
    log(`❌ Token verification error: ${error.message}`, 'red');
    return false;
  }
}

async function testPatientProfile() {
  log('\n🔍 Testing Patient Profile...', 'blue');
  try {
    const response = await makeRequest('/api/patients/profile', 'GET', null, true);
    
    if (response.status === 200 && response.data.success) {
      log('✅ Patient profile retrieved', 'green');
      log(`   Name: ${response.data.data.full_name}`, 'yellow');
      return true;
    } else {
      log('❌ Patient profile failed', 'red');
      return false;
    }
  } catch (error) {
    log(`❌ Patient profile error: ${error.message}`, 'red');
    return false;
  }
}

async function testPatientDashboard() {
  log('\n🔍 Testing Patient Dashboard...', 'blue');
  try {
    const response = await makeRequest('/api/patients/dashboard', 'GET', null, true);
    
    if (response.status === 200 && response.data.success) {
      log('✅ Dashboard stats retrieved', 'green');
      log(`   Predictions: ${response.data.data.totalPredictions}`, 'yellow');
      log(`   Appointments: ${response.data.data.totalAppointments}`, 'yellow');
      return true;
    } else {
      log('❌ Dashboard stats failed', 'red');
      return false;
    }
  } catch (error) {
    log(`❌ Dashboard error: ${error.message}`, 'red');
    return false;
  }
}

async function testPredictionCreation() {
  log('\n🔍 Testing AI Prediction Creation...', 'blue');
  try {
    const prediction = {
      modelName: 'CardioRisk',
      diseaseType: 'heart_disease',
      riskLevel: 'medium',
      confidenceScore: 85.5,
      predictionResult: 'Moderate cardiovascular risk detected',
      inputParameters: {
        age: 45,
        bloodPressure: 140,
        cholesterol: 220,
        heartRate: 75
      },
      explainabilityData: {
        topFactors: ['Age', 'Blood Pressure', 'Cholesterol']
      },
      recommendations: 'Lifestyle modifications and regular monitoring recommended'
    };

    const response = await makeRequest('/api/predictions', 'POST', prediction, true);
    
    if (response.status === 201 && response.data.success) {
      log('✅ Prediction created successfully', 'green');
      log(`   Prediction ID: ${response.data.data.predictionId}`, 'yellow');
      return true;
    } else {
      log('❌ Prediction creation failed', 'red');
      return false;
    }
  } catch (error) {
    log(`❌ Prediction creation error: ${error.message}`, 'red');
    return false;
  }
}

async function testNotifications() {
  log('\n🔍 Testing Notifications...', 'blue');
  try {
    const response = await makeRequest('/api/notifications', 'GET', null, true);
    
    if (response.status === 200 && response.data.success) {
      log('✅ Notifications retrieved', 'green');
      log(`   Count: ${response.data.data.length}`, 'yellow');
      return true;
    } else {
      log('❌ Notifications failed', 'red');
      return false;
    }
  } catch (error) {
    log(`❌ Notifications error: ${error.message}`, 'red');
    return false;
  }
}

// Main test runner
async function runTests() {
  log('\n╔═══════════════════════════════════════════╗', 'magenta');
  log('║   HealthAI API Test Suite                ║', 'magenta');
  log('╚═══════════════════════════════════════════╝', 'magenta');

  const results = {
    passed: 0,
    failed: 0,
    total: 0
  };

  const tests = [
    { name: 'Health Check', fn: testHealthCheck },
    { name: 'User Registration', fn: testRegistration },
    { name: 'User Login', fn: testLogin },
    { name: 'Token Verification', fn: testTokenVerification },
    { name: 'Patient Profile', fn: testPatientProfile },
    { name: 'Patient Dashboard', fn: testPatientDashboard },
    { name: 'AI Prediction', fn: testPredictionCreation },
    { name: 'Notifications', fn: testNotifications }
  ];

  for (const test of tests) {
    results.total++;
    const passed = await test.fn();
    if (passed) {
      results.passed++;
    } else {
      results.failed++;
    }
  }

  // Print summary
  log('\n╔═══════════════════════════════════════════╗', 'magenta');
  log('║          Test Results Summary             ║', 'magenta');
  log('╚═══════════════════════════════════════════╝', 'magenta');
  log(`\n📊 Total Tests: ${results.total}`, 'blue');
  log(`✅ Passed: ${results.passed}`, 'green');
  log(`❌ Failed: ${results.failed}`, 'red');
  log(`📈 Success Rate: ${((results.passed / results.total) * 100).toFixed(1)}%`, 'yellow');

  if (results.failed === 0) {
    log('\n🎉 All tests passed! Your API is working perfectly!', 'green');
  } else {
    log('\n⚠️  Some tests failed. Please check the logs above.', 'yellow');
  }

  log('\n');
  process.exit(results.failed === 0 ? 0 : 1);
}

// Check if server is running
async function checkServer() {
  try {
    await makeRequest('/health');
    return true;
  } catch (error) {
    log('\n❌ Cannot connect to server!', 'red');
    log(`   Make sure the backend server is running on ${API_BASE}`, 'yellow');
    log('   Run: cd backend && npm run dev', 'yellow');
    return false;
  }
}

// Start tests
checkServer().then(isRunning => {
  if (isRunning) {
    runTests();
  } else {
    process.exit(1);
  }
});
