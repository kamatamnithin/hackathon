# HealthAI Platform - Backend Setup Guide

## 📋 Overview
This is the Node.js/Express backend for the HealthAI Platform with MySQL database integration.

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- MySQL Server (v8.0 or higher)
- npm or yarn package manager

### Step 1: Database Setup

1. **Start MySQL Server**
   ```bash
   # Make sure MySQL is running on localhost:3306
   # You can verify with:
   mysql -u UDHAY -pTeja@7586
   ```

2. **Create Database** (if not exists)
   ```sql
   CREATE DATABASE IF NOT EXISTS healthcare;
   ```

3. **Import Database Schema**
   ```bash
   # From the backend directory
   mysql -u UDHAY -pTeja@7586 healthcare < database/schema.sql
   ```

   Or manually:
   ```bash
   mysql -u UDHAY -pTeja@7586
   USE healthcare;
   SOURCE database/schema.sql;
   ```

4. **Verify Tables Created**
   ```sql
   USE healthcare;
   SHOW TABLES;
   # Should show 14 tables
   ```

### Step 2: Backend Setup

1. **Install Dependencies**
   ```bash
   cd backend
   npm install
   ```

2. **Environment Configuration**
   ```bash
   # Copy the example environment file
   cp .env.example .env
   ```

   The `.env` file is already configured with your credentials:
   ```env
   PORT=5000
   DB_HOST=localhost
   DB_USER=UDHAY
   DB_PASSWORD=Teja@7586
   DB_NAME=healthcare
   JWT_SECRET=your_super_secret_jwt_key_change_this
   ```

3. **Start the Server**
   ```bash
   # Development mode (with auto-reload)
   npm run dev

   # Or production mode
   npm start
   ```

4. **Verify Server Running**
   - Server should start on: `http://localhost:5000`
   - Health check: `http://localhost:5000/health`
   - API documentation: `http://localhost:5000/`

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/verify` - Verify JWT token

### Patients
- `GET /api/patients/profile` - Get patient profile
- `PUT /api/patients/profile` - Update patient profile
- `GET /api/patients/dashboard` - Get dashboard stats

### Doctors
- `GET /api/doctors/profile` - Get doctor profile
- `PUT /api/doctors/profile` - Update doctor profile
- `GET /api/doctors/patients` - Get doctor's patients

### AI Predictions
- `POST /api/predictions` - Create AI prediction
- `GET /api/predictions/patient` - Get patient predictions
- `GET /api/predictions/:id` - Get prediction by ID

### Electronic Health Records (EHR)
- `GET /api/ehr` - Get health records
- `POST /api/ehr` - Create health record

### Prescriptions
- `GET /api/prescriptions` - Get prescriptions
- `GET /api/prescriptions/:id/medications` - Get medications

### Appointments
- `GET /api/appointments` - Get appointments
- `POST /api/appointments` - Create appointment

### IoT Wearables
- `GET /api/iot/devices` - Get devices
- `GET /api/iot/readings` - Get readings
- `POST /api/iot/readings` - Add reading

### Insurance Claims
- `GET /api/insurance` - Get claims
- `POST /api/insurance` - Submit claim

### ABDM Integration
- `GET /api/abdm/consents` - Get consents
- `POST /api/abdm/link-health-id` - Link health ID

### Notifications
- `GET /api/notifications` - Get notifications
- `PUT /api/notifications/:id/read` - Mark as read

### Emergency
- `POST /api/emergency/alert` - Send emergency alert
- `GET /api/emergency/alerts` - Get alerts

### Analytics
- `GET /api/analytics/disease-trends` - Get disease trends
- `GET /api/analytics/predictions-summary` - Get predictions summary

## 🔐 Authentication

All protected endpoints require a JWT token in the Authorization header:

```javascript
headers: {
  'Authorization': 'Bearer YOUR_JWT_TOKEN'
}
```

### Getting a Token

1. **Register** a new user:
   ```bash
   curl -X POST http://localhost:5000/api/auth/register \
     -H "Content-Type: application/json" \
     -d '{
       "email": "patient@example.com",
       "password": "password123",
       "userType": "patient",
       "fullName": "John Doe",
       "phone": "1234567890"
     }'
   ```

2. **Login** to get token:
   ```bash
   curl -X POST http://localhost:5000/api/auth/login \
     -H "Content-Type: application/json" \
     -d '{
       "email": "patient@example.com",
       "password": "password123"
     }'
   ```

3. Use the returned `token` in subsequent requests.

## 🎨 Frontend Integration

### Step 1: Install Environment Variables

Create a `.env` file in your frontend root:

```env
VITE_API_URL=http://localhost:5000/api
```

### Step 2: Update AuthModal Component

Update `/components/auth-modal.tsx` to use real API:

```typescript
import api from '../services/api';

// In handleSubmit function:
const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  
  try {
    const response = isLogin 
      ? await api.auth.login(formData.email, formData.password)
      : await api.auth.register({
          email: formData.email,
          password: formData.password,
          userType: portalType,
          fullName: formData.fullName,
          phone: formData.phone,
          dateOfBirth: formData.dateOfBirth,
          bloodGroup: formData.bloodGroup,
          emergencyContact: formData.emergencyContact,
          medicalLicense: formData.medicalLicense,
          specialization: formData.specialization,
          hospitalName: formData.hospitalName,
          experience: parseInt(formData.experience) || undefined,
          address: formData.address
        });

    if (response.success) {
      onLogin(portalType, response.data?.user);
    } else {
      alert(response.error || 'Authentication failed');
    }
  } catch (error) {
    console.error('Auth error:', error);
    alert('Authentication failed. Please try again.');
  }
};
```

### Step 3: Use API in Components

Example - Get patient profile:

```typescript
import api from '../services/api';

// In your component
useEffect(() => {
  async function loadProfile() {
    const response = await api.patient.getProfile();
    if (response.success) {
      setProfile(response.data);
    }
  }
  loadProfile();
}, []);
```

## 📊 Database Tables

The schema includes 14 tables:
1. `users` - User authentication
2. `patient_profiles` - Patient information
3. `doctor_profiles` - Doctor information
4. `health_records` - EHR data
5. `ai_predictions` - AI prediction results
6. `prescriptions` - Prescription records
7. `prescription_medications` - Medication details
8. `appointments` - Appointment bookings
9. `iot_devices` - Wearable devices
10. `iot_readings` - Device readings
11. `insurance_claims` - Insurance claims
12. `abdm_consents` - ABDM consent management
13. `notifications` - User notifications
14. `emergency_alerts` - Emergency SOS alerts

## 🛠️ Troubleshooting

### Database Connection Issues

```bash
# Check if MySQL is running
sudo systemctl status mysql

# Or on Windows
net start MySQL

# Test connection
mysql -u UDHAY -pTeja@7586 -e "SHOW DATABASES;"
```

### Port Already in Use

```bash
# Change PORT in .env file
PORT=5001

# Or kill process on port 5000
# Linux/Mac:
lsof -ti:5000 | xargs kill -9

# Windows:
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

### CORS Issues

Add your frontend URL to `.env`:
```env
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173,http://localhost:5174
```

## 🔒 Security Notes

### For Production Deployment:

1. **Change JWT Secret**
   ```env
   JWT_SECRET=use_a_very_long_random_string_here
   ```

2. **Use Environment Variables** (never commit .env)
   
3. **Enable HTTPS**

4. **Use Stronger Password Hashing** (current: bcrypt with 10 rounds)

5. **Implement Rate Limiting** (already included)

6. **Add Input Validation** (already included via express-validator)

7. **Set up Database Backups**
   ```bash
   # Backup command
   mysqldump -u UDHAY -pTeja@7586 healthcare > backup_$(date +%Y%m%d).sql
   ```

## 📦 Project Structure

```
backend/
├── config/
│   └── database.js          # MySQL connection config
├── database/
│   └── schema.sql            # Database schema
├── middleware/
│   └── auth.js              # JWT authentication
├── routes/
│   ├── auth.js              # Authentication routes
│   ├── patients.js          # Patient endpoints
│   ├── doctors.js           # Doctor endpoints
│   ├── predictions.js       # AI predictions
│   ├── ehr.js               # Health records
│   ├── prescriptions.js     # Prescriptions
│   ├── appointments.js      # Appointments
│   ├── iot.js               # IoT devices
│   ├── insurance.js         # Insurance claims
│   ├── abdm.js              # ABDM integration
│   ├── notifications.js     # Notifications
│   ├── emergency.js         # Emergency alerts
│   └── analytics.js         # Analytics
├── server.js                # Express server
├── package.json             # Dependencies
├── .env.example             # Environment template
└── README.md                # This file
```

## 🚀 Next Steps

1. ✅ Database schema created
2. ✅ Backend API running
3. ⏳ Connect frontend to API
4. ⏳ Test all endpoints
5. ⏳ Add data validation
6. ⏳ Implement file upload for reports
7. ⏳ Add email notifications
8. ⏳ Integrate ABDM API
9. ⏳ Deploy to production

## 📞 Support

For issues or questions:
- Check the troubleshooting section
- Review API endpoint documentation
- Verify database connection
- Check server logs for errors

## 📝 License

MIT License - See LICENSE file for details

---

**Built with ❤️ for HealthAI Platform**
