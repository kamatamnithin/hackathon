const jwt = require('jsonwebtoken');
const { promisePool } = require('../config/database');

// Verify JWT token middleware
const authenticateToken = async (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({ 
        success: false, 
        message: 'Access token required' 
      });
    }

    // Verify token
    jwt.verify(token, process.env.JWT_SECRET, async (err, decoded) => {
      if (err) {
        return res.status(403).json({ 
          success: false, 
          message: 'Invalid or expired token' 
        });
      }

      // Check if user still exists
      const [users] = await promisePool.execute(
        'SELECT user_id, email, user_type, is_active FROM users WHERE user_id = ?',
        [decoded.userId]
      );

      if (users.length === 0) {
        return res.status(404).json({ 
          success: false, 
          message: 'User not found' 
        });
      }

      if (!users[0].is_active) {
        return res.status(403).json({ 
          success: false, 
          message: 'Account is deactivated' 
        });
      }

      // Attach user info to request
      req.user = {
        userId: decoded.userId,
        email: decoded.email,
        userType: decoded.userType
      };

      next();
    });
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Authentication error' 
    });
  }
};

// Check if user is patient
const isPatient = (req, res, next) => {
  if (req.user.userType !== 'patient') {
    return res.status(403).json({ 
      success: false, 
      message: 'Access denied. Patient access required.' 
    });
  }
  next();
};

// Check if user is doctor
const isDoctor = (req, res, next) => {
  if (req.user.userType !== 'doctor') {
    return res.status(403).json({ 
      success: false, 
      message: 'Access denied. Doctor access required.' 
    });
  }
  next();
};

// Check if user is patient or doctor (any authenticated user)
const isAuthenticated = authenticateToken;

module.exports = {
  authenticateToken,
  isPatient,
  isDoctor,
  isAuthenticated
};
