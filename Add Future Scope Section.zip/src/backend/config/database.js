const mysql = require('mysql2');
require('dotenv').config();

// Create MySQL connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'UDHAY',
  password: process.env.DB_PASSWORD || 'Teja@7586',
  database: process.env.DB_NAME || 'healthcare',
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: process.env.DB_CONNECTION_LIMIT || 10,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0
});

// Get promise-based pool
const promisePool = pool.promise();

// Test database connection
async function testConnection() {
  try {
    const [rows] = await promisePool.query('SELECT 1 + 1 AS result');
    console.log('✅ MySQL Database connected successfully');
    console.log(`📊 Database: ${process.env.DB_NAME}`);
    return true;
  } catch (error) {
    console.error('❌ MySQL Database connection failed:', error.message);
    return false;
  }
}

// Get connection from pool
async function getConnection() {
  return await promisePool.getConnection();
}

// Execute query with error handling
async function executeQuery(sql, params = []) {
  try {
    const [results] = await promisePool.execute(sql, params);
    return { success: true, data: results };
  } catch (error) {
    console.error('Query error:', error.message);
    return { success: false, error: error.message };
  }
}

// Transaction helper
async function executeTransaction(queries) {
  const connection = await getConnection();
  try {
    await connection.beginTransaction();
    
    const results = [];
    for (const { sql, params } of queries) {
      const [result] = await connection.execute(sql, params);
      results.push(result);
    }
    
    await connection.commit();
    return { success: true, data: results };
  } catch (error) {
    await connection.rollback();
    console.error('Transaction error:', error.message);
    return { success: false, error: error.message };
  } finally {
    connection.release();
  }
}

// Close pool gracefully
function closePool() {
  return new Promise((resolve, reject) => {
    pool.end((err) => {
      if (err) {
        console.error('Error closing database pool:', err);
        reject(err);
      } else {
        console.log('✅ Database pool closed');
        resolve();
      }
    });
  });
}

module.exports = {
  pool,
  promisePool,
  testConnection,
  getConnection,
  executeQuery,
  executeTransaction,
  closePool
};
