-- ============================================
-- HealthAI Platform - MySQL Database Schema
-- ============================================
-- Database: healthcare
-- This schema supports the complete HealthAI platform including:
-- Authentication, EHR, Telemedicine, Prescriptions, IoT, Insurance, ABDM
-- ============================================

USE healthcare;

-- ============================================
-- 1. USERS & AUTHENTICATION
-- ============================================

-- Main users table for authentication
CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    user_type ENUM('patient', 'doctor') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_email (email),
    INDEX idx_user_type (user_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 2. PATIENT PROFILES
-- ============================================

CREATE TABLE IF NOT EXISTS patient_profiles (
    patient_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    date_of_birth DATE,
    gender ENUM('male', 'female', 'other'),
    blood_group VARCHAR(5),
    height_cm DECIMAL(5,2),
    weight_kg DECIMAL(5,2),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(10),
    emergency_contact_name VARCHAR(255),
    emergency_contact_phone VARCHAR(20),
    emergency_contact_relation VARCHAR(50),
    abdm_health_id VARCHAR(100) UNIQUE,
    profile_picture_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_abdm_health_id (abdm_health_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 3. DOCTOR PROFILES
-- ============================================

CREATE TABLE IF NOT EXISTS doctor_profiles (
    doctor_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    date_of_birth DATE,
    gender ENUM('male', 'female', 'other'),
    medical_license_number VARCHAR(100) UNIQUE NOT NULL,
    specialization VARCHAR(100),
    sub_specialization VARCHAR(100),
    qualification TEXT,
    experience_years INT,
    hospital_name VARCHAR(255),
    clinic_name VARCHAR(255),
    consultation_fee DECIMAL(10,2),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(10),
    available_for_telemedicine BOOLEAN DEFAULT TRUE,
    profile_picture_url TEXT,
    signature_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_specialization (specialization),
    INDEX idx_medical_license (medical_license_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 4. HEALTH RECORDS (EHR)
-- ============================================

CREATE TABLE IF NOT EXISTS health_records (
    record_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    record_type ENUM('vitals', 'diagnosis', 'lab_report', 'imaging', 'vaccination', 'allergy', 'surgery', 'other') NOT NULL,
    record_title VARCHAR(255) NOT NULL,
    record_description TEXT,
    recorded_by_doctor_id INT,
    record_date DATE NOT NULL,
    file_url TEXT,
    file_type VARCHAR(50),
    metadata JSON,
    is_shared BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patient_profiles(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by_doctor_id) REFERENCES doctor_profiles(doctor_id) ON DELETE SET NULL,
    INDEX idx_patient_id (patient_id),
    INDEX idx_record_type (record_type),
    INDEX idx_record_date (record_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 5. AI PREDICTIONS
-- ============================================

CREATE TABLE IF NOT EXISTS ai_predictions (
    prediction_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    model_name VARCHAR(100) NOT NULL,
    disease_type ENUM('heart_disease', 'diabetes', 'cancer', 'other') NOT NULL,
    risk_level ENUM('low', 'medium', high', 'critical') NOT NULL,
    confidence_score DECIMAL(5,2) NOT NULL,
    prediction_result TEXT NOT NULL,
    input_parameters JSON NOT NULL,
    explainability_data JSON,
    recommendations TEXT,
    reviewed_by_doctor_id INT,
    doctor_notes TEXT,
    prediction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patient_profiles(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (reviewed_by_doctor_id) REFERENCES doctor_profiles(doctor_id) ON DELETE SET NULL,
    INDEX idx_patient_id (patient_id),
    INDEX idx_model_name (model_name),
    INDEX idx_disease_type (disease_type),
    INDEX idx_prediction_date (prediction_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 6. PRESCRIPTIONS
-- ============================================

CREATE TABLE IF NOT EXISTS prescriptions (
    prescription_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    prescription_date DATE NOT NULL,
    diagnosis TEXT,
    symptoms TEXT,
    notes TEXT,
    follow_up_date DATE,
    prescription_pdf_url TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patient_profiles(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctor_profiles(doctor_id) ON DELETE CASCADE,
    INDEX idx_patient_id (patient_id),
    INDEX idx_doctor_id (doctor_id),
    INDEX idx_prescription_date (prescription_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Prescription medications (line items)
CREATE TABLE IF NOT EXISTS prescription_medications (
    medication_id INT PRIMARY KEY AUTO_INCREMENT,
    prescription_id INT NOT NULL,
    medicine_name VARCHAR(255) NOT NULL,
    dosage VARCHAR(100) NOT NULL,
    frequency VARCHAR(100) NOT NULL,
    duration VARCHAR(100) NOT NULL,
    timing VARCHAR(100),
    instructions TEXT,
    FOREIGN KEY (prescription_id) REFERENCES prescriptions(prescription_id) ON DELETE CASCADE,
    INDEX idx_prescription_id (prescription_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 7. APPOINTMENTS & TELEMEDICINE
-- ============================================

CREATE TABLE IF NOT EXISTS appointments (
    appointment_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_type ENUM('in-person', 'telemedicine', 'emergency') NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    duration_minutes INT DEFAULT 30,
    status ENUM('scheduled', 'confirmed', 'in-progress', 'completed', 'cancelled', 'no-show') DEFAULT 'scheduled',
    chief_complaint TEXT,
    patient_notes TEXT,
    doctor_notes TEXT,
    video_room_id VARCHAR(255),
    video_recording_url TEXT,
    consultation_fee DECIMAL(10,2),
    payment_status ENUM('pending', 'paid', 'refunded') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patient_profiles(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctor_profiles(doctor_id) ON DELETE CASCADE,
    INDEX idx_patient_id (patient_id),
    INDEX idx_doctor_id (doctor_id),
    INDEX idx_appointment_date (appointment_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 8. IoT WEARABLE DEVICES DATA
-- ============================================

CREATE TABLE IF NOT EXISTS iot_devices (
    device_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    device_type VARCHAR(100) NOT NULL,
    device_name VARCHAR(255) NOT NULL,
    device_identifier VARCHAR(255) UNIQUE NOT NULL,
    manufacturer VARCHAR(100),
    model VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    last_sync TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patient_profiles(patient_id) ON DELETE CASCADE,
    INDEX idx_patient_id (patient_id),
    INDEX idx_device_type (device_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- IoT readings/measurements
CREATE TABLE IF NOT EXISTS iot_readings (
    reading_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    device_id INT NOT NULL,
    patient_id INT NOT NULL,
    reading_type VARCHAR(50) NOT NULL,
    reading_value DECIMAL(10,2) NOT NULL,
    unit VARCHAR(20) NOT NULL,
    reading_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSON,
    alert_triggered BOOLEAN DEFAULT FALSE,
    alert_level ENUM('normal', 'warning', 'critical'),
    FOREIGN KEY (device_id) REFERENCES iot_devices(device_id) ON DELETE CASCADE,
    FOREIGN KEY (patient_id) REFERENCES patient_profiles(patient_id) ON DELETE CASCADE,
    INDEX idx_device_id (device_id),
    INDEX idx_patient_id (patient_id),
    INDEX idx_reading_type (reading_type),
    INDEX idx_reading_timestamp (reading_timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 9. INSURANCE CLAIMS
-- ============================================

CREATE TABLE IF NOT EXISTS insurance_claims (
    claim_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    policy_number VARCHAR(100) NOT NULL,
    insurance_provider VARCHAR(255) NOT NULL,
    claim_type VARCHAR(100) NOT NULL,
    claim_amount DECIMAL(12,2) NOT NULL,
    approved_amount DECIMAL(12,2),
    claim_date DATE NOT NULL,
    treatment_date DATE NOT NULL,
    diagnosis TEXT,
    hospital_name VARCHAR(255),
    doctor_id INT,
    documents_url JSON,
    status ENUM('submitted', 'under-review', 'approved', 'rejected', 'paid') DEFAULT 'submitted',
    status_notes TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patient_profiles(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctor_profiles(doctor_id) ON DELETE SET NULL,
    INDEX idx_patient_id (patient_id),
    INDEX idx_policy_number (policy_number),
    INDEX idx_status (status),
    INDEX idx_claim_date (claim_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 10. ABDM INTEGRATION
-- ============================================

CREATE TABLE IF NOT EXISTS abdm_consents (
    consent_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    consent_request_id VARCHAR(255) UNIQUE NOT NULL,
    purpose VARCHAR(255) NOT NULL,
    requester_id VARCHAR(255) NOT NULL,
    requester_type ENUM('doctor', 'hospital', 'insurance', 'research') NOT NULL,
    data_types JSON NOT NULL,
    date_range_from DATE NOT NULL,
    date_range_to DATE NOT NULL,
    status ENUM('requested', 'granted', 'denied', 'revoked', 'expired') DEFAULT 'requested',
    consent_artifact JSON,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    responded_at TIMESTAMP NULL,
    expires_at TIMESTAMP NULL,
    FOREIGN KEY (patient_id) REFERENCES patient_profiles(patient_id) ON DELETE CASCADE,
    INDEX idx_patient_id (patient_id),
    INDEX idx_status (status),
    INDEX idx_consent_request_id (consent_request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 11. NOTIFICATIONS
-- ============================================

CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    notification_type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    link_url TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 12. EMERGENCY SOS
-- ============================================

CREATE TABLE IF NOT EXISTS emergency_alerts (
    alert_id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    location_latitude DECIMAL(10, 8),
    location_longitude DECIMAL(11, 8),
    location_address TEXT,
    alert_type VARCHAR(50) NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'critical',
    status ENUM('active', 'responded', 'resolved', 'cancelled') DEFAULT 'active',
    responders JSON,
    response_time_seconds INT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (patient_id) REFERENCES patient_profiles(patient_id) ON DELETE CASCADE,
    INDEX idx_patient_id (patient_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 13. AUDIT LOGS
-- ============================================

CREATE TABLE IF NOT EXISTS audit_logs (
    log_id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 14. ANALYTICS & TRENDS
-- ============================================

CREATE TABLE IF NOT EXISTS disease_statistics (
    stat_id INT PRIMARY KEY AUTO_INCREMENT,
    disease_type VARCHAR(100) NOT NULL,
    region VARCHAR(100),
    age_group VARCHAR(20),
    gender ENUM('male', 'female', 'other', 'all'),
    case_count INT NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    severity_distribution JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_disease_type (disease_type),
    INDEX idx_region (region),
    INDEX idx_period (period_start, period_end)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================

-- Additional composite indexes for common queries
CREATE INDEX idx_patient_appointments ON appointments(patient_id, appointment_date, status);
CREATE INDEX idx_doctor_appointments ON appointments(doctor_id, appointment_date, status);
CREATE INDEX idx_patient_predictions ON ai_predictions(patient_id, prediction_date);
CREATE INDEX idx_patient_readings ON iot_readings(patient_id, reading_timestamp);

-- ============================================
-- INITIAL DATA / DEMO DATA (Optional)
-- ============================================

-- You can add sample data here for testing
-- Example:
-- INSERT INTO users (email, password_hash, user_type) VALUES 
-- ('patient@demo.com', '$2b$10$...', 'patient'),
-- ('doctor@demo.com', '$2b$10$...', 'doctor');

-- ============================================
-- END OF SCHEMA
-- ============================================

-- To verify all tables were created:
-- SHOW TABLES;

-- To check table structure:
-- DESCRIBE users;
-- DESCRIBE patient_profiles;
-- etc.
